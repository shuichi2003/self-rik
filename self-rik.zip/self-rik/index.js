// SC DARI MASTAH HEXAGON
// DI RECODE AMA NGERIKMENSEDIH
//MAKASIH DAH PAKE 
const
	{
		WAConnection: _WAConnection,
		MessageType,
		Presence,
		MessageOptions,
		Mimetype,
		WALocationMessage,
		WA_MESSAGE_STUB_TYPES,
		WA_DEFAULT_EPHEMERAL,
		ReconnectMode,
		ProxyAgent,
		GroupSettingChange,
		waChatKey,
		mentionedJid,
		processTime,
	} = require("@adiwajshing/baileys")
const simple = require('./lib/simple')
let WAConnection = simple.WAConnection(_WAConnection)
const qrcode = require("qrcode-terminal")
const moment = require("moment-timezone")
const speed = require('performance-now')
const request = require('request');
const hx = require('hxz-api')
const { spawn, exec, execSync } = require("child_process")
let erik = new WAConnection()
const fs = require("fs")
const fse = require("fs-extra");
const axios = require("axios")
const ffmpeg = require('fluent-ffmpeg')
const { EmojiAPI } = require("emoji-api");
const tik = require('tiktok-scraper-without-watermark')
const ig = require('insta-fetcher')
const emoji = new EmojiAPI()
const fetch = require('node-fetch');
const Fb = require('fb-video-downloader');
const twitterGetUrl = require("twitter-url-direct")
const translate = require('@vitalets/google-translate-api')
const phoneNum = require('awesome-phonenumber')
const gis = require('g-i-s');
const got = require("got");
const imageToBase64 = require('image-to-base64');
const ID3Writer = require('browser-id3-writer');		
const brainly = require('brainly-scraper')
const yts = require( 'yt-search')
const ms = require('parse-ms')
const toMs = require('ms')
const { error } = require("qrcode-terminal")
const { getBuffer, h2k, generateMessageID, getGroupAdmins, getRandom, banner, start, info, success, close } = require('./lib/functions')
const { color, bgcolor } = require('./lib/color')
const { cmdadd } = require('./lib/totalcmd.js')
const { fetchJson, getBase64, kyun, createExif } = require('./lib/fetcher')
const { yta, ytv, igdl, upload, formatDate } = require('./lib/ytdl')
const { webp2mp4File} = require('./lib/webp2mp4')
const time = moment().tz('Asia/Jakarta').format("HH:mm:ss")
const afk = JSON.parse(fs.readFileSync('./database/off.json'))
const { sleep, isAfk, cekafk, addafk } = require('./lib/offline')
const samih = JSON.parse(fs.readFileSync('./database/simi.json'))
const nsfw = JSON.parse(fs.readFileSync('./database/nsfw.json'))
const mute = JSON.parse(fs.readFileSync('./database/mute.json'));
const banchatt = JSON.parse(fs.readFileSync('./database/banchatt.json'))
const welkom = JSON.parse(fs.readFileSync('./database/welkom.json'));
let _scommand = JSON.parse(fs.readFileSync('./database/scommand.json'))
const voting = JSON.parse(fse.readFileSync('./database/voting.json'))
const setiker = JSON.parse(fs.readFileSync('./database/stick.json'))
const { addVote, delVote } = require('./lib/vote')
const { jadibot, stopjadibot, listjadibot } = require('./lib/jadibot')
const { validmove, setGame } = require("./lib/tictactoe");
const game = require("./lib/game");
const fetish = require('./lib/fetish')
const setting = JSON.parse(fs.readFileSync('./database/settings.json'))
const Nekos = require('nekos.life')
const neko = new Nekos();

//******************** ex ********************\\
const Exif = require('./lib/exif');
const exif = new Exif();


//SETTING
banChats = false
offline = false
targetpc = '6282130301023'
owner = '6282130301023'
ownername = 'ǀtz.me/Erick'
fake = 'ㅤ\nㅤ'
jtroli = '0'
motivasi = '-'
LolKey = 'RuiTachibanaChan'
XKey = 'TierMikuZ'
VhKey = 'TierKunGanz'
zeks= 'ZayBotWea'
numbernye = '0'
waktu = '-'
alasan = '-'
r = '```'
//=================================================//

//******************** Prefix ********************\\
let multi = true
let nopref = false
let single = false
let prefa = '.'

//******************** 》Game《 ********************\\
let tebakgambar = [];
let family100 = [];
let mtk = [];

//********************* time ************************\\
let {    
    gamewaktu,
} = require('./database/settings')

//******************** Advance ********************\\

function monospace(string) {
return '```' + string + '```'
}   
function jsonformat(string) {
return JSON.stringify(string, null, 2)
}
function randomNomor(angka){
return Math.floor(Math.random() * angka) + 1
}
const nebal = (angka) => {
return Math.floor(angka)
}


//test auto read
//erik.chatRead(from, "read")

const time2 = moment().tz('Asia/Jakarta').format('HH:mm:ss')
if(time2 < "23:59:00"){
var ucapanWaktu = 'Konbanwa'
                                        }
if(time2 < "19:00:00"){
var ucapanWaktu = 'Konichiwa'
                                         }
if(time2 < "15:00:00"){
var ucapanWaktu = 'Konichiwa'
                                         }
if(time2 < "11:00:00"){
var ucapanWaktu = 'Ohayou'
                                         }
         
         // Sticker Cmd
const addCmd = (id, command) => {
    const obj = { id: id, chats: command }
    _scommand.push(obj)
    fse.writeFileSync('./database/scommand.json', JSON.stringify(_scommand))
}

const getCommandPosition = (id) => {
    let position = null
    Object.keys(_scommand).forEach((i) => {
        if (_scommand[i].id === id) {
            position = i
        }
    })
    if (position !== null) {
        return position
    }
}

const getCmd = (id) => {
    let position = null
    Object.keys(_scommand).forEach((i) => {
        if (_scommand[i].id === id) {
            position = i
        }
    })
    if (position !== null) {
        return _scommand[position].chats
    }
}


const checkSCommand = (id) => {
    let status = false
    Object.keys(_scommand).forEach((i) => {
        if (_scommand[i].id === id) {
            status = true
        }
    })
    return status
}

module.exports = erik = async (erik, mek) => {
	try {
        if (!mek.hasNewMessage) return
        mek = mek.messages.all()[0]
		if (!mek.message) return
		if (mek.key && mek.key.remoteJid == 'status@broadcast') return
		global.blocked
        	mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message
            m = simple.smsg(erik, mek)
        	const content = JSON.stringify(mek.message)
		const from = mek.key.remoteJid
		const { text, extendedText, contact, location, liveLocation, image, video, sticker, document, audio, product } = MessageType
		const time = moment.tz('Asia/Jakarta').format('DD/MM HH:mm:ss')
                const type = Object.keys(mek.message)[0]        
                const cmd = (type === 'conversation' && mek.message.conversation) ? mek.message.conversation : (type == 'imageMessage') && mek.message.imageMessage.caption ? mek.message.imageMessage.caption : (type == 'videoMessage') && mek.message.videoMessage.caption ? mek.message.videoMessage.caption : (type == 'extendedTextMessage') && mek.message.extendedTextMessage.text ? mek.message.extendedTextMessage.text : ''.slice(1).trim().split(/ +/).shift().toLowerCase()
                if (multi){
		    var prefix = /^[°•π÷×¶∆£¢€¥®™=|~!#$%^&.?/\\©^z+@,;]/.test(cmd) ? cmd.match(/^[°•π÷×¶∆£¢€¥®™=|~!#$%^&.?/\\©^z+@,;]/gi) : '#'
             } else {
            if (nopref){
            prefix = ''
             } else {
            if(single){
            prefix = prefa
            }
          }
        }
        	body = (type === 'conversation' && mek.message.conversation.startsWith(prefix)) ? mek.message.conversation : (type == 'imageMessage') && mek.message[type].caption.startsWith(prefix) ? mek.message[type].caption : (type == 'videoMessage') && mek.message[type].caption.startsWith(prefix) ? mek.message[type].caption : (type == 'extendedTextMessage') && mek.message[type].text.startsWith(prefix) ? mek.message[type].text : (type == 'listResponseMessage') && mek.message[type].singleSelectReply.selectedRowId ? mek.message[type].singleSelectReply.selectedRowId : (type == 'buttonsResponseMessage') && mek.message[type].selectedButtonId ? mek.message[type].selectedButtonId : (type == 'stickerMessage') && (getCmd(mek.message[type].fileSha256.toString('base64')) !== null && getCmd(mek.message[type].fileSha256.toString('base64')) !== undefined) ? getCmd(mek.message[type].fileSha256.toString('base64')) : ""
		budy = (type === 'conversation') ? mek.message.conversation : (type === 'extendedTextMessage') ? mek.message.extendedTextMessage.text : ''
		const messagesC = body.slice(0).trim()
		const command = body.slice(1).trim().split(/ +/).shift().toLowerCase()		
		chats = (type === 'conversation') ? mek.message.conversation : (type === 'extendedTextMessage') ? mek.message.extendedTextMessage.text : ''
		const args = body.trim().split(/ +/).slice(1)
		const argss = body.split(/ +/g)
		const isCmd = body.startsWith(prefix)
		const cmnd = ["help","sticker","say"]
		const q = args.join(' ')
		const OwnerNumber = [`${6282130301023}@s.whatsapp.net`]
		const botNumber = erik.user.jid
		const botNumberss = erik.user.jid + '@c.us'
		const isGroup = from.endsWith('@g.us')
		let sender = isGroup ? mek.participant : mek.key.remoteJid
		const senderNumber = sender.split("@")[0]
		// const isSelfNumber = config.NomorSELF
		// const isOwner = sender.id === isSelfNumber
		const ownerNumber = ['6282130301023@s.whatsapp.net','6282120502996@s.whatsapp.net','0@s.whatsapp.net']
		const totalchat = await erik.chats.all()
		const groupMetadata = isGroup ? await erik.groupMetadata(from) : ''
		const groupName = isGroup ? groupMetadata.subject : ''
		const groupId = isGroup ? groupMetadata.jid : ''
		const groupMembers = isGroup ? groupMetadata.participants : ''
		const groupDesc = isGroup ? groupMetadata.desc : ''
		const groupOwner = isGroup ? groupMetadata.owner : ''
		const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ''
		const isBotGroupAdmins = groupAdmins.includes(botNumber) || false
		const isGroupAdmins = groupAdmins.includes(sender) || false
		const isOwner = ownerNumber.includes(sender)
		const isSimi = isGroup ? samih.includes(from) : false
		const isNsfw = isGroup ? nsfw.includes(from) : false;
		const isMuted = isGroup ? mute.includes(from) : false
		const isBanchatt = isGroup ? banchatt.includes(from) : false
         const isWelkom = isGroup ? welkom.includes(from) : false;
         const isVote = isGroup ? voting.includes(from) : false
        const conts = mek.key.fromMe ? erik.user.jid : erik.contacts[sender] || { notify: jid.replace(/@.+/, '') }
        const pushname = mek.key.fromMe ? erik.user.name : conts.notify || conts.vname || conts.name || '-'

         // DATABASE
        const vcard = 'BEGIN:VCARD\n' + 'VERSION:3.0\n' + 'FN:Insect Number\n' + 'ORG:WhatsApp\n' + 'TEL;type=CELL;type=VOICE;waid=0:0\n' + 'END:VCARD';
        const vcard1 = 'BEGIN:VCARD\n' + 'VERSION:3.0\n' + 'FN:NgErikMenSediH\n' + 'ORG:Owner \n' + 'TEL;type=CELL;type=VOICE;waid=6282130301023:+62 821-3030-1023\n' + 'END:VCARD';
        
  
        //MESS
		mess = {
			wait: '```Wait!```',
			success: 'Berhasil!',
			dl: '```Downloading!```',
			wrongFormat: 'Format salah, coba liat lagi di menu',
			error: {
				stick: 'Pastikan kalo itu sticker :v',
				Iv: 'Linknya error:v'
			},
			only: {
				group: "❌```Perintah ini hanya bisa di gunakan dalam group!```❌\n\n❌```This command can only be used in groups!```❌",
					ownerG: "❌```Perintah ini hanya bisa di gunakan oleh owner group!```❌\n\n❌```This command can only be used by the group owner!```❌",
					ownerB: "❌```Hanya Untuk Owner```❌\n\n❌```Only For Owner ```❌",
					admin: "❌```Perintah ini hanya bisa di gunakan oleh admin group!```❌\n\n```This command can only be used by group admins!```❌",
					Badmin: "❌```Perintah ini hanya bisa di gunakan ketika bot menjadi admin!```❌\n\n❌```This command can only be used when the bot is admin!```❌",
					nsfw: '```Nsfw is not register```',
					regist: "\`\`\`can't use bots for group\`\`\` ${groupMetadata.subject}, \`\`\`Because this group is not registered yet\`\`\`",
			}
		}
		const isUrl = (url) => {
        return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%.+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%+.~#?&/=]*)/, 'gi'))
        }

        const reply = (teks) => {
            erik.sendMessage(from, teks, text, {quoted:mek})
        }

        const sendMess = (hehe, teks) => {
            erik.sendMessage(hehe, teks, text)
        }

        const mentions = (teks, memberr, id) => {
            (id == null || id == undefined || id == false) ? erik.sendMessage(from, teks.trim(), extendedText, { contextInfo: { "mentionedJid": memberr } }) : erik.sendMessage(from, teks.trim(), extendedText, { quoted: mek, contextInfo: { "mentionedJid": memberr } })
        }
         
        const freply = (teks) => { 
        	erik.sendMessage(from, teks, text, {
                quoted: {
                    key: { 
                          fromMe: false, 
                    participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: '16505434800@s.whatsapp.net' } : {})
                   },
                   message: { 
                   "productMessage":{
                      "product": {"productImage": {
                      "mimetype":'image/jpeg',"Thumbnail":fs.readFileSync('./stik/textimg.jpeg')}, 
                      "title": `${ucapanWaktu} ${pushname}`, 
                      "productImageCount": 1 }, 
                      "businessOwnerJid": `0@s.whatsapp.net` 
                    }
                    }
                }
            })
        }
          
        const fakestatus = (teks) => {
            erik.sendMessage(from, teks, text, {
                quoted: {
                    key: {
                        fromMe: false,
                        participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {})
                    },
                    message: {
                        "imageMessage": {
                            "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc",
                            "mimetype": "image/jpeg",
                            "caption": `*${ucapanWaktu}* 👋 *${pushname}*`,
                            "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=",
                            "fileLength": "28777",
                            "height": 1080,
                            "width": 1079,
                            "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=",
                            "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=",
                            "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69",
                            "mediaKeyTimestamp": "1610993486",
                            "jpegThumbnail": fs.readFileSync('./stik/thumb.jpeg'),
                            "scansSidecar": "1W0XhfaAcDwc7xh1R8lca6Qg/1bB4naFCSngM2LKO2NoP5RI7K+zLw=="
                        }
                    }
                }
            })
        }
        const testing = (teks) => {
            erik.sendMessage(from, teks, text, {
                quoted: {
                    key: {
                        fromMe: false,
                        participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {})
                    },
                    message: {
                        "documentMessage": {
                            "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc",
                            "mimetype": "document",
                            "title": `*ACTIVE NGAB*`,
                            "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=",
                            "fileLength": "28777",
                            "height": 1080,
                            "width": 1079,
                            "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=",
                            "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=",
                            "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69",
                            "mediaKeyTimestamp": "1610993486",
                            "jpegThumbnail": fs.readFileSync('./stik/textimg.jpeg'),
                            "scansSidecar": "1W0XhfaAcDwc7xh1R8lca6Qg/1bB4naFCSngM2LKO2NoP5RI7K+zLw=="
                        }
                    }
                }
            })
        }
const fakelink  = (teks) => {
erik.sendMessage(from, teks, text,{contextInfo :{text: 'hi',
"forwardingScore": 1000000000,
isForwarded: false,
sendEphemeral: false,
"externalAdReply": {
                "title": `${ucapanWaktu} 👋 ${pushname}`,
                "body": "",
                "mimetype": "image/jpeg",
                "thumbnailUrl": "https://telegra.ph/file/bbb5eca08130920edbcb4.jpg",
                "thumbnail": fs.readFileSync('./stik/textimg.jpeg'),
                "sourceUrl": ``
},mentionedJid:[sender]}, quoted : mek})
}
        const textImg = (teks) => {
            erik.sendMessage(from, teks, text, {quoted: mek, thumbnail: fs.readFileSync('./stik/textimg.jpeg')})
        }
        const fakethumb = (teks, yes) => {
            erik.sendMessage(from, teks, image, {thumbnail:fs.readFileSync('./stik/fake.jpeg'),quoted:mek,caption:yes})
        }
        const fakegroup = (teks) => {
            erik.sendMessage(from, teks, text, {
                quoted: {
                    key: {
                        fromMe: false,
                        participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "6289523258649-1604595598@g.us" } : {})
                    },
                    message: {
                        "imageMessage": {
                            "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc",
                            "mimetype": "image/jpeg",
                            "caption": `*${ucapanWaktu}* 👋 *${pushname}*`,
                            "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=",
                            "fileLength": "28777",
                            "height": 1080,
                            "width": 1079,
                            "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=",
                            "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=",
                            "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69",
                            "mediaKeyTimestamp": "1610993486",
                            "jpegThumbnail": fs.readFileSync('./stik/thumb.jpeg'),
                            "scansSidecar": "1W0XhfaAcDwc7xh1R8lca6Qg/1bB4naFCSngM2LKO2NoP5RI7K+zLw=="
                        }
                    }
                }
            })
        }
        const fakevideo = (teks) => {
	 erik.sendMessage(from, teks, text, {
                quoted: {
                    key: {
                        fromMe: false,
                        participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "6289523258649-1604595598@g.us" } : {})
                    },
	           message: { 
                 "videoMessage": { 
                            "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc",
                            "mimetype": "video/mp4",
                            'seconds': '99999', 
                            "caption": `*${ucapanWaktu}* 👋 *${pushname}*`,
                            "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=",
                            "fileLength": "28777",
                            "height": 1080,
                            "width": 1079,
                            "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=",
                            "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=",
                            "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69",
                            "mediaKeyTimestamp": "1610993486",
                            "jpegThumbnail": fs.readFileSync('./stik/textimg.jpeg'),
                            "scansSidecar": "1W0XhfaAcDwc7xh1R8lca6Qg/1bB4naFCSngM2LKO2NoP5RI7K+zLw=="
                        }
                    }
                }
            })
        }
        const fvideo = (teks) => {
	 erik.sendMessage(from, teks, text, {
                quoted: {
                    key: {
                        fromMe: false,
                        participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "6289523258649-1604595598@g.us" } : {})
                    },
	           message: { 
                 "videoMessage": { 
                 "title":"hallo bang",
                 "h": `Hmm`, 
                 'seconds': '9999999999999999999999999', 
                 'caption': `*${ucapanWaktu}* 👋 *${pushname}*`,
                 'jpegThumbnail': fs.readFileSync('./stik/textimg.jpeg')
                        }
                    }
                }
            })
        }
        const fakedoc = (teks) => {
	 erik.sendMessage(from, teks, text, {
                quoted: {
                    key: {
                        fromMe: false,
                        participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "6289523258649-1604595598@g.us" } : {})
                    },
       message: {
                    documentMessage: {
                    'title': `*${ucapanWaktu}* 👋 *${pushname}*`,
                 'jpegThumbnail': fs.readFileSync('./stik/textimg.jpeg')
                        }
                    }
                }
            })
        }
        const fakegc = (teks) => {
	 erik.sendMessage(from, teks, text, {
                quoted: {
                    key: {
                        fromMe: false,
		"participant": "0@s.whatsapp.net",
		"remoteJid": "0@s.whatsapp.net"
	},
	"message": {
		"groupInviteMessage": {
			"groupJid": "628983583288-1620319322@g.us",
			"inviteCode": "HGkRU2CKh2nK2z92kaxgvD",
			"groupName": `${ucapanWaktu} 👋 ${pushname}`, 
"caption": `${ucapanWaktu} 👋 ${pushname}`, 
'jpegThumbnail': fs.readFileSync('./stik/textimg.jpeg')
		                        }
                    }
                }
            })
        }
        const faketroli = (teks) => {
	 erik.sendMessage(from, teks, text, {
                quoted: {

key: {

fromMe: false,

participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: 'status@broadcast' } : {})

},

message: { 

orderMessage: {

itemCount: jtroli,

status: 200, 

surface: 200,

message: `${ucapanWaktu} 👋 ${pushname}`,

orderTitle: 'TESTING', 

thumbnail: fs.readFileSync('./stik/textimg.jpeg'),

sellerJid: '0@s.whatsapp.net'
}
                    }
                }
            })
        }
        const fakemenu  = (teks) => {
erik.sendMessage(from, teks, text,{contextInfo :{text: 'hi',
"forwardingScore": 1000000000,
isForwarded: false,
sendEphemeral: false,
"externalAdReply": {
                "title": `you need to type\n${prefix}register group`,
                "body": "Itz.Me.Erick",
                "mimetype": "image/jpeg",
                "thumbnailUrl": "https://telegra.ph/file/bbb5eca08130920edbcb4.jpg",
                "thumbnail": fs.readFileSync('./stik/textimg.jpeg'),
                "sourceUrl": ``
},mentionedJid:[sender]}, quoted : mek})
}
        const otomatis = (teks) => {
erik.sendMessage(from, teks, text,{contextInfo :{text: 'hi',
"forwardingScore": 1000000000,
isForwarded: true,
sendEphemeral: true,
"externalAdReply": {
                "title": `#PESAN OTOMATIS`,
                "body": "click here for private chat",
                "mimetype": "image/jpeg",
                "thumbnailUrl": "https://telegra.ph/file/bbb5eca08130920edbcb4.jpg",
                "thumbnail": fs.readFileSync('./stik/textimg.jpeg'),
                "sourceUrl": "http://wa.me/6282130301023?text=%20permisi,%20maaf%20menggagu",
},mentionedJid:[sender]}, quoted : mek})
}
const notfound = (teks) => {
erik.sendMessage(from, teks, text,{contextInfo :{text: 'hi',
"forwardingScore": 1000000000,
isForwarded: false,
sendEphemeral: false,
"externalAdReply": {
                "title": `${ucapanWaktu} 👋 ${pushname}`,
                "body": "Not Found 404",
                "mimetype": "image/jpeg",
                "thumbnailUrl": "https://telegra.ph/file/bbb5eca08130920edbcb4.jpg",
                "thumbnail": fs.readFileSync('./stik/404.jpeg'),
                "sourceUrl": ``
},mentionedJid:[sender]}, quoted : mek})
}
const buggc = (teks) => {
async function sendBug(jid, ephemeralExpiration, opts) {
          let message = vean.prepareMessageFromContent(
                jid,
                erik.prepareDisappearingMessageSettingContent(ephemeralExpiration),
                {}
            )
            await erik.relayWAMessage(message, opts)
            return message
        }
      }
        const sendStickerFromUrl = async(to, url) => {
                var names = Date.now() / 10000;
                var download = function (uri, filename, callback) {
                    request.head(uri, function (err, res, body) {
                        request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                    });
                };
                download(url, './stik' + names + '.png', async function () {
                    console.log('selesai');
                    let filess = './stik' + names + '.png'
                    let asw = './stik' + names + '.webp'
                    exec(`ffmpeg -i ${filess} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${asw}`, (err) => {
                        let media = fs.readFileSync(asw)
                        erik.sendMessage(to, media, MessageType.sticker,{quoted:mek})
                        fs.unlinkSync(filess)
                        fs.unlinkSync(asw)
                    });
                });
            }
        const sendMediaURL = async(to, url, text="", mids=[]) =>{
                if(mids.length > 0){
                    text = normalizeMention(to, text, mids)
                }
                const fn = Date.now() / 10000;
                const filename = fn.toString()
                let mime = ""
                var download = function (uri, filename, callback) {
                    request.head(uri, function (err, res, body) {
                        mime = res.headers['content-type']
                        request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
                    });
                };
                download(url, filename, async function () {
                    console.log('done');
                    let media = fs.readFileSync(filename)
                    let type = mime.split("/")[0]+"Message"
                    if(mime === "image/gif"){
                        type = MessageType.video
                        mime = Mimetype.gif
                    }
                    if(mime.split("/")[0] === "audio"){
                        mime = Mimetype.mp4Audio
                    }
                    erik.sendMessage(to, media, type, { quoted: mek, mimetype: mime, caption: text,contextInfo: {"mentionedJid": mids}})
                    
                    fs.unlinkSync(filename)
                });
            }   


        // here button function
        selectedButton = (type == 'buttonsResponseMessage') ? mek.message.buttonsResponseMessage.selectedButtonId : ''

        responseButton = (type == 'listResponseMessage') ? mek.message.listResponseMessage.title : ''
        
// ***************  Responder Sticker *************** \\
if (setiker.includes(messagesC)){
namastc = messagesC
buffer = fs.readFileSync(`./src/stick/${namastc}.webp`)
erik.sendMessage(from, buffer, sticker, {quoted:mek })
}
// ******************** 》GAME《 ******************** \\

game.cekWaktuFam(erik, family100)
game.cekWaktuTG(erik, tebakgambar)
game.cekWaktuMtk(erik, mtk)

if (game.isMtk(from, mtk)){
if (chats.toLowerCase().includes(game.getJawabanMtk(from, mtk))){
var htgm3 = randomNomor(1000)
await reply(`*Selamat jawaban kamu benar*\n*Jawaban :* ${game.getJawabanMtk(from, mtk)}\n\nIngin bermain lagi? kirim *${prefix}math*`)
mtk.splice(game.getMtkPosi(from, mtk), 1)
}
}
			        
if (game.isTebakGambar(from, tebakgambar)){
if (chats.toLowerCase().includes(game.getJawabanTG(from, tebakgambar))){
var htgm = randomNomor(1000)
await reply(`*Selamat jawaban kamu benar*\n*Jawaban :* ${game.getJawabanTG(from, tebakgambar)}\n\nIngin bermain lagi? kirim *${prefix}tebakgambar*`)
tebakgambar.splice(game.getTGPosi(from, tebakgambar), 1)
}
}

if (game.isfam(from, family100)){
var anjuy = game.getjawaban100(from, family100)
for (let i of anjuy){
if (chats.toLowerCase().includes(i)){
var htgm1 = randomNomor(1000)
await reply(`*Jawaban benar*\n*Jawaban :* ${i}\n\n*Jawaban yang blum tertebak :* ${anjuy.length - 1}`)
var anug = anjuy.indexOf(i)
anjuy.splice(anug, 1)
}
}
if (anjuy.length < 1){
erik.sendMessage(from, `Semua jawaban sudah tertebak\nKirim *${prefix}family100* untuk bermain lagi`, text)
family100.splice(game.getfamposi(from, family100), 1)
}
}
// ***************  Tictactoe BY MRHRTZ《*************** \\
const cmde = budy.toLowerCase().split(" ")[0] || "";
let arrNum = ["1", "2", "3", "4", "5", "6", "7", "8", "9"];
if (fs.existsSync(`./lib/tictactoe/db/${from}.json`)) {
const boardnow = setGame(`${from}`);
if (budy == "Cex") return reply("why");
if (
budy.toLowerCase() == "!y" ||
budy.toLowerCase() == "!yes" ||
budy.toLowerCase() == "!ya"
) {
if (boardnow.O == sender.replace("@s.whatsapp.net", "")) {
if (boardnow.status)
return reply(`Game telah dimulai sebelumnya!`);
const matrix = boardnow._matrix;
boardnow.status = true;
fs.writeFileSync(`./lib/tictactoe/db/${from}.json`,JSON.stringify(boardnow, null, 2)
);
const chatAccept = `T I C T A C T O E  G A M E

INFO :
  Player ❎ : @${boardnow.X}
  Player ⭕ : @${boardnow.O}
               
     ${matrix[0][0]}  ${matrix[0][1]}  ${matrix[0][2]}
     ${matrix[1][0]}  ${matrix[1][1]}  ${matrix[1][2]}
     ${matrix[2][0]}  ${matrix[2][1]}  ${matrix[2][2]}
     
Giliran @${boardnow.turn == "X" ? boardnow.X : boardnow.O}

Ketik nyerah untuk Menyerah!
Ketik ${prefix}delttc untuk Menghapus sesi game!
`;
erik.sendMessage(from, monospace(chatAccept), MessageType.text, {
quoted: mek,
contextInfo: {
mentionedJid: [
boardnow.X + "@s.whatsapp.net",
boardnow.O + "@s.whatsapp.net",
],
},
});
} else {
erik.sendMessage(from,`Opsi ini hanya untuk @${boardnow.O} !`,
MessageType.text, {quoted: mek,
contextInfo: {
mentionedJid: [boardnow.O + "@s.whatsapp.net"],
},
}
);
}
} else if (
budy.toLowerCase() == "!n" ||
budy.toLowerCase() == "!no" ||
budy.toLowerCase() == "!tidak"
) {
if (boardnow.O == sender.replace("@s.whatsapp.net", "")) {
if (boardnow.status)
return reply(`Game telah dimulai sebelumnya!`);
fs.unlinkSync(`./lib/tictactoe/db/${from}.json`);
erik.sendMessage(from,`Sayangnya tantangan @${boardnow.X} ditolak ❎😕`,
MessageType.text, {quoted: mek,
contextInfo: {
mentionedJid: [boardnow.X + "@s.whatsapp.net"],
},
}
);
} else {
erik.sendMessage(from,`Opsi ini hanya untuk @${boardnow.O} !`,MessageType.text, {quoted: mek,
contextInfo: {
mentionedJid: [boardnow.O + "@s.whatsapp.net"],
},
}
);
}
}
}

if (arrNum.includes(cmde)) {
const boardnow = setGame(`${from}`);
if (!boardnow.status) return reply(`Sepertinya lawan anda belum menerima / menolak tantangan.`)
if (
(boardnow.turn == "X" ? boardnow.X : boardnow.O) !=
sender.replace("@s.whatsapp.net", "")
)
return;
const moving = validmove(Number(budy), `${from}`);
const matrix = moving._matrix;
if (moving.isWin) {
if (moving.winner == "SERI") {
const chatEqual = `*🎮 Tictactoe Game 🎳*
          
Game berakhir seri 😐
`;
reply(chatEqual);
fs.unlinkSync(`./lib/tictactoe/db/${from}.json`);
return;
}
const winnerJID = moving.winner == "O" ? moving.O : moving.X;
const looseJID = moving.winner == "O" ? moving.X : moving.O;
const limWin = Math.floor(Math.random() * 20) + 10;
const limLoose = Math.floor(Math.random() * 10) + 5;
const chatWon = `*🎮 Tictactoe Game 🎳*
          
Telah dimenangkan oleh @${winnerJID} 😎👑
`;
            //    giftLimit(winnerJID + "@s.whatsapp.net", limWin);
            //    pushLimit(looseJID + "@s.whatsapp.net", limLoose);
erik.sendMessage(from, chatWon, MessageType.text, {quoted: mek,contextInfo: {
mentionedJid: [
moving.winner == "O" ?
moving.O + "@s.whatsapp.net" :
moving.X + "@s.whatsapp.net",
],
},
});
fs.unlinkSync(`./lib/tictactoe/db/${from}.json`);
} else {
const chatMove = `T I C T A C T O E  G A M E

INFO
  Player ❎ : @${moving.X}
  Player ⭕ : @${moving.O}

     ${matrix[0][0]}  ${matrix[0][1]}  ${matrix[0][2]}
     ${matrix[1][0]}  ${matrix[1][1]}  ${matrix[1][2]}
     ${matrix[2][0]}  ${matrix[2][1]}  ${matrix[2][2]}
     
Giliran : @${moving.turn == "X" ? moving.X : moving.O}

Ketik nyerah untuk Menyerah!
Ketik ${prefix}delttc untuk Menghapus sesi game!
`;
erik.sendMessage(from, monospace(chatMove), MessageType.text, {quoted: mek,contextInfo: {
mentionedJid: [
moving.X + "@s.whatsapp.net",
moving.O + "@s.whatsapp.net",
],
},
});
}
}

if ((senderNumber) && ["Nyerah", "nyerah"].includes(budy) && !isCmd) {
orangnye = sender
teks = `@${orangnye.split("@")[0]} Menyerah\n_Yahaha cupu abiez_`
if (fs.existsSync("./lib/tictactoe/db/" + from + ".json")) {
fs.unlinkSync("./lib/tictactoe/db/" + from + ".json");
mentions(teks,[sender],true)
  } else {
reply(`Tidak ada sesi yg berlangsung`);
  }
}
      

//FUNCTION
            cekafk(afk)
            if (!mek.key.remoteJid.endsWith('@g.us') && offline){
            if (!mek.key.fromMe){
            if (isAfk(mek.key.remoteJid)) return
            addafk(mek.key.remoteJid)
            heheh = ms(Date.now() - waktu) 
            erik.sendMessage(mek.key.remoteJid,`@${owner} Sedang Offline!\n\n*Alasan :* ${alasan}\n*Sejak :* ${heheh.hours} Jam, ${heheh.minutes} Menit, ${heheh.seconds} Detik lalu\n\nSilahkan Hubungi Lagi Nanti`, MessageType.text,{contextInfo:{ mentionedJid: [`${owner}@s.whatsapp.net`],'stanzaId': "B826873620DD5947E683E3ABE663F263", 'participant': "0@s.whatsapp.net", 'remoteJid': 'status@broadcast', 'quotedMessage': {"imageMessage": {"caption": "*OFFLINE*", 'jpegThumbnail': fs.readFileSync('./stik/thumb.jpeg')}}}})
            }
            }   
        if (mek.key.remoteJid.endsWith('@g.us') && offline) {
        if (!mek.key.fromMe){
        if (mek.message.extendedTextMessage != undefined){
        if (mek.message.extendedTextMessage.contextInfo != undefined){
        if (mek.message.extendedTextMessage.contextInfo.mentionedJid != undefined){
        for (let ment of mek.message.extendedTextMessage.contextInfo.mentionedJid) {
        if (ment === `${owner}@s.whatsapp.net`){
        if (isAfk(mek.key.remoteJid)) return
        addafk(mek.key.remoteJid)
        heheh = ms(Date.now() - waktu)
        erik.sendMessage(mek.key.remoteJid,`@${owner} Sedang Offline!\n\n *Alasan :* ${alasan}\n *Sejak :* ${heheh.hours} Jam, ${heheh.minutes} Menit, ${heheh.seconds} Detik lalu\n\nSilahkan Hubungi Lagi Nanti`, MessageType.text,{contextInfo:{ mentionedJid: [`${owner}@s.whatsapp.net`],'stanzaId': "B826873620DD5947E683E3ABE663F263", 'participant': "0@s.whatsapp.net", 'remoteJid': 'status@broadcast', 'quotedMessage': {"imageMessage": {"caption": "*OFFLINE*", 'jpegThumbnail': fs.readFileSync('./stik/thumb.jpeg')}}}})
          }
        }
            }
          }
        }
      }
    }
 
    const simih = async (text) => {
	try {
		const sami = await fetch(`https://simsumi.herokuapp.com/api?text=${text}`, {method: 'GET'})
		const res = await sami.json()
		return res.success
	} catch {
		return 'Shui ga tau kamu ngomong apa, bahasa Mars?'
	}
}
    erik.on('group-participants-update', async (anu) => {
      if (!welkom.includes(anu.jid)) return;
      try {
         const mdata = await erik.groupMetadata(anu.jid);
         console.log(anu);
         if (anu.action == 'add') {
            num = anu.participants[0];
            try {
               ppimg = await erik.getProfilePicture(`${anu.participants[0].split('@')[0]}@c.us`);
            } catch {
               ppimg = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png';
            }
            teks = `woy *${ucapanWaktu}* 👋 @${num.split('@')[0]}\n selamat datang di group *${mdata.subject}*\n\n*Desc:* ${groupMetadata.desc}`;
            let buff = await getBuffer(ppimg);
            erik.sendMessage(mdata.id, buff, MessageType.image, { caption: teks, contextInfo: { mentionedJid: [num] } });
         } else if (anu.action == 'remove') {
            num = anu.participants[0];
            try {
               ppimg = await erik.getProfilePicture(`${num.split('@')[0]}@c.us`);
            } catch {
               ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg';
            }
            teks = `Sayonara 👋 @${num.split('@')[0]} semoga kita bertemu lagi`;
            let buff = await getBuffer(ppimg)
            erik.sendMessage(mdata.id, buff, MessageType.image, { caption: teks, contextInfo: { mentionedJid: [num] } });
         }
      } catch (e) {
         console.log('Error : %s', color(e, 'yellow'));
      }
   });
   
//========================================================================================================================//
		colors = ['red', 'white', 'black', 'blue', 'yellow', 'green']
		const isMedia = (type === 'imageMessage' || type === 'videoMessage')
		const isQuotedMsg = type === 'extendedTextMessage' && content.includes('Message')
		const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')
		const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')
		const isQuotedAudio = type === 'extendedTextMessage' && content.includes('audioMessage')
		const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')
		const isQuotedDocs = type === 'extendedTextMessage' && content.includes('documentMessage')
        const isQuotedLoca = type === 'extendedTextMessage' && content.includes('locationMessage')
        const isQuotedContact = type === 'extendedTextMessage' && content.includes('contactMessage')
        const isQuotedTeks = type === 'extendedTextMessage' && content.includes('quotedMessage')
        const isQuotedTag = type === 'extendedTextMessage' && content.includes('mentionedJid')
        const isQuotedReply = type === 'extendedTextMessage' && content.includes('Message')
      	if (!isGroup && isCmd) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;32mEXEC\x1b[1;37m]', time, color(command), 'from', color(sender.split('@')[0]), 'args :', color(args.length))
      	//if (!isGroup && !isCmd) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;31mTEXT\x1b[1;37m]', time, color('Message'), 'from', color(sender.split('@')[0]), 'args :', color(args.length))
     	if (isCmd && isGroup) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;32mEXEC\x1b[1;37m]', time, color(command), 'from', color(sender.split('@')[0]), 'in', color(groupName), 'args :', color(args.length))
      	//if (!isCmd && isGroup) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;31mTEXT\x1b[1;37m]', time, color('Message'), 'from', color(sender.split('@')[0]), 'in', color(groupName), 'args :', color(args.length))
		if (!mek.key.fromMe && banChats === true) return
		if(isGroup && !isVote) {
        if (budy.toLowerCase() === 'vote'){
        let vote = JSON.parse(fs.readFileSync(`./lib/${from}.json`))
        let _votes = JSON.parse(fs.readFileSync(`./lib/vote/${from}.json`))  
        let fil = vote.map(v => v.participant)
        let id_vote = sender ? sender : '6282130301023@s.whatsapp.net'
        if(fil.includes(id_vote)) {
        return mentions('@'+sender.split('@')[0]+' Anda sudah vote', fil, true)
        } else {
        vote.push({
            participant: id_vote,
            voting: '✅'
        })
        fs.writeFileSync(`./lib/${from}.json`,JSON.stringify(vote))
        let _p = []
        let _vote = '*Vote* '+ '@'+ _votes[0].votes.split('@')[0] + `\n\n*Alasan*: ${_votes[0].reason}\n*Jumlah Vote* : ${vote.length} Vote\n*Durasi* : ${_votes[0].durasi} Menit\n\n` 
        for(let i = 0; i < vote.length; i++) {
        _vote +=  `@${vote[i].participant.split('@')[0]}\n*Vote* : ${vote[i].voting}\n\n`
        _p.push(vote[i].participant)
        }  
        _p.push(_votes[0].votes)
        mentions(_vote,_p,true)   
        }
        } else if (budy.toLowerCase() === 'devote'){
        const vote = JSON.parse(fs.readFileSync(`./lib/${from}.json`))
        let _votes = JSON.parse(fs.readFileSync(`./lib/vote/${from}.json`))  
        let fil = vote.map(v => v.participant)
        let id_vote = sender ? sender : '6285751056816@s.whatsapp.net'
        if(fil.includes(id_vote)) {
        return mentions('@'+sender.split('@')[0]+' Anda sudah vote', fil, true)
        } else {
        vote.push({
            participant: id_vote,
            voting: '❌'
        })
        fs.writeFileSync(`./lib/${from}.json`,JSON.stringify(vote))
        let _p = []
        let _vote = '*Vote* '+ '@'+ _votes[0].votes.split('@')[0] + `\n\n*Alasan*: ${_votes[0].reason}\n*Jumlah Vote* : ${vote.length} Vote\n*Durasi* : ${_votes[0].durasi} Menit\n\n` 
        for(let i = 0; i < vote.length; i++) {
        _vote +=  `@${vote[i].participant.split('@')[0]}\n*Vote* : ${vote[i].voting}\n\n`
        _p.push(vote[i].participant)
        }  
        _p.push(_votes[0].votes)
        mentions(_vote,_p,true)   
        }
    }
}	


switch (command) {
	case 'jadibot':
    if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
    jadibot(reply,erik,from)
    break
    case 'stopjadibot':
    if (mek.key.fromMe)return reply('tidak bisa stopjadibot kecuali owner')
    stopjadibot(reply)
    break
    case 'listbot':
    case 'listjadibot':
    if (!mek.key.fromMe && !isOwner) return
    let tekss = '「 *LIST JADIBOT* 」\n'
    for(let i of listjadibot) {
    tekss += `*Nomor* : ${i.jid.split('@')[0]}
*Nama* : ${i.name}
*Device* : ${i.phone.device_manufacturer}
*Model* : ${i.phone.device_model}\n\n`
    }
    reply(tekss)
    break
	//======================= AWAL BUTTON ========================\\reak
case 'help':
case 'menu':
if (!isBanchatt) return 
gambur = 'https://telegra.ph/file/e6248540ac9fafde7ea82.jpg'
gambar = await getBuffer(gambur)
textmenu = `
╒════════════════════
├ *Owner  :* ${ownername}
├ *Lib        :* Baileys V.3.5.2
├ *Prefix   :* ${multi ? '[MULTI PREFIX]' : '[NO-PREFIX]'}
├ *Mode   :* ${banChats ? '[SELF-MODE]' : '[PUBLIC-MODE]'}
├════════════════════
├➤ MAIN
├ ➪ ${prefix}help
├ ➪ ${prefix}menu
├ ➪ ${prefix}?
├────────────────────
├➤ MAKER
├❒ ${prefix}sticker
├❒ ${prefix}stickergif
├❒ ${prefix}stickernobg
├❒ ${prefix}sticklink
├❒ ${prefix}stickermeme <text>
├❒ ${prefix}stickerwm <author|packname>
├❒ ${prefix}take <author|packname>
├❒ ${prefix}fdeface
├❒ ${prefix}emoji <emoji>
├❒ ${prefix}ttp <teks>
├❒ ${prefix}ttp2 <teks|colour>
├❒ ${prefix}ttp3 <teks>
├❒ ${prefix}attp <teks>
├────────────────────
├➤ CONVERT
├❒ ${prefix}toimg
├❒ ${prefix}tovid
├❒ ${prefix}getimage
├❒ ${prefix}tomp3
├❒ ${prefix}tomp4
├❒ ${prefix}slow
├❒ ${prefix}fast
├❒ ${prefix}reverse
├❒ ${prefix}tourl
├❒ ${prefix}imgtourl
├────────────────────
├➤ FUN
├❒ ${prefix}apakah
├❒ ${prefix}bisakah
├❒ ${prefix}kapankah
├❒ ${prefix}gay
├❒ ${prefix}jadian
├❒ ${prefix}flip
├❒ ${prefix}dice
├❒ ${prefix}fitnah
├❒ ${prefix}fitnahpc
├❒ ${prefix}kontak
├❒ ${prefix}math
├❒ ${prefix}tebakgambar
├❒ ${prefix}family100
├❒ ${prefix}tictactoe
├────────────────────
├➤ ANIMANGA
├❒ ${prefix}character <query>
├❒ ${prefix}waifu <random>
├❒ ${prefix}loli
├❒ ${prefix}neko
├❒ ${prefix}wallpaperanime
├❒ ${prefix}charimg
├❒ ${prefix}otakudesu
├❒ ${prefix}otakubatch
├❒ ${prefix}otakulast
├❒ ${prefix}anime <anime name>
├❒ ${prefix}manga <manga name>
├❒ ${prefix}quote <random>
├❒ ${prefix}wait  <reply image> (error)
├❒ ${prefix}coupleanime <image/doc>
├────────────────────
├➤ ISLAM
├❒ ${prefix}listsurah 
├❒ ${prefix}alquran
├❒ ${prefix}alquranaudio
├❒ ${prefix}asmaulhusna
├❒ ${prefix}kisahnabi <name>
├❒ ${prefix}jadwalsholat <place name>
├────────────────────
├➤ IMAGE
├❒ ${prefix}image <query>
├❒ ${prefix}goimg <query|number>
├❒ ${prefix}ssweb <url>
├❒ ${prefix}randomimage <random>
├❒ ${prefix}nulis <teks>
├❒ ${prefix}puisi <random>
├❒ ${prefix}pinterest <query>
├❒ ${prefix}pinterest2 <query>
├❒ ${prefix}wallpaper <query>
├❒ ${prefix}wallpaper2 <query>
├────────────────────
├➤ SEARCHING
├❒ ${prefix}ytsearch <query>
├❒ ${prefix}igstalk <query>
├❒ ${prefix}igstalk2 <query>
├❒ ${prefix}brainly <query>
├❒ ${prefix}brainly2 <query>
├❒ ${prefix}github <query>
├❒ ${prefix}lirik <query>
├❒ ${prefix}cuaca  <query>
├❒ ${prefix}cuaca2  <query>
├❒ ${prefix}translate <bahasa> <teks>
├❒ ${prefix}playstore <apk name>
├❒ ${prefix}zodiak
├❒ ${prefix}linkwa
├────────────────────
├➤ DOWNLOAD
├❒ ${prefix}playmp3 <query>
├❒ ${prefix}playmp4 <query>
├❒ ${prefix}ytmp3 <link>
├❒ ${prefix}ytmp4 <link>
├❒ ${prefix}ig <link>
├❒ ${prefix}twitter <link>
├❒ ${prefix}tiktokmp4 <link>
├❒ ${prefix}tiktokmp3 <link>
├❒ ${prefix}fb <link> 
├────────────────────
├➤ OTHER
├❒ ${prefix}shortlink
├❒ ${prefix}readmore <teks|teks>
├❒ ${prefix}inspect <link gc>
├❒ ${prefix}owner
├❒ ${prefix}donasi
├────────────────────
├➤ GROUP
├❒ ${prefix}getpic <@tag>
├❒ ${prefix}getbio <@tag>
├❒ ${prefix}linkgc
├❒ ${prefix}revoke
├❒ ${prefix}profile
├❒ ${prefix}admin
├❒ ${prefix}ping
├❒ ${prefix}ping2
├❒ ${prefix}hidetag
├❒ ${prefix}kontag
├❒ ${prefix}sticktag
├❒ ${prefix}totag
├❒ ${prefix}open <true/false>
├❒ ${prefix}close <true/false>
├❒ ${prefix}group <open/close>
├❒ ${prefix}delete
├❒ ${prefix}tagme
├❒ ${prefix}wame
├❒ ${prefix}closetime
├❒ ${prefix}opentime
├❒ ${prefix}promote
├❒ ${prefix}demote
├❒ ${prefix}register <group/nsfw/simi/welcome>
├❒ ${prefix}unregister <group/nsfw/simi/welcome>
├❒ ${prefix}setname
├❒ ${prefix}setdesc
├❒ ${prefix}join
├❒ ${prefix}leave
├❒ ${prefix}voting
├❒ ${prefix}delvote
├────────────────────
├➤ SPAM
├❒ ${prefix}repeat
├❒ ${prefix}spam
├❒ ${prefix}spamtag
├❒ ${prefix}spamtagme
├❒ ${prefix}spamcall
├❒ ${prefix}spamsms
├────────────────────
├➤ NSFW
├❒ ${prefix}trap
├❒ ${prefix}ero
├❒ ${prefix}yuri
├❒ ${prefix}lewd
├❒ ${prefix}nhentai <code nuclear>
├❒ ${prefix}nhsearch <query>
├────────────────────
├➤ JADIBOT
├❒ ${prefix}jadibot
├❒ ${prefix}stopjadibot
├❒ ${prefix}listjadibot
├────────────────────
├➤ OWNER
├❒ ${prefix}off
├❒ ${prefix}on
├❒ ${prefix}self
├❒ ${prefix}public
├❒ ${prefix}setthumb
├❒ ${prefix}settextimg
├❒ ${prefix}setfakeimg
├❒ ${prefix}setimgmenu
├❒ ${prefix}setreply
├❒ ${prefix}settarget
├❒ ${prefix}setmotivasi
├❒ ${prefix}status
├❒ ${prefix}runtime
├❒ ${prefix}get
├❒ ${prefix}upswteks
├❒ ${prefix}upswimage
├❒ ${prefix}upswvideo
├❒  >
├❒  <
├❒  =>
├❒ $
├────────────────────
╘════════════════════`
mhan = await erik.prepareMessage(from, gambar, image, {thumbnail: gambar})
buttons = [
  {buttonId: `owner`, buttonText: {displayText: ` `}, type: 1},
]
 gbuttonan = {
imageMessage: mhan.message.imageMessage,
    contentText: `*Motivasi Hari Ini:* ${motivasi}`,
    footerText: textmenu,
    buttons: buttons,
    headerType: 4
}
await erik.sendMessage(from, gbuttonan,MessageType.buttonsMessage,{contextInfo :{text: 'hi',
"forwardingScore": 1000000000,
isForwarded: true,
sendEphemeral: false,
"externalAdReply": {
                "title": `${ucapanWaktu} 👋 ${pushname}`,
                "body": "",
                "previewType": "PHOTO",
                "thumbnailUrl": ``,
                "thumbnail": fs.readFileSync('./stik/textimg.jpeg'),
                "sourceUrl": ``
},mentionedJid:[sender]},quoted:mek})
break
        //help = fs.readFileSync('./sound/menu.mp3');
        //erik.sendMessage(from, help, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
               
          case 'group':
          if (!isBanchatt) return
          if (!mek.key.fromMe && !isGroupAdmins && !isOwner) return reply(mess.only.admin)
          buttons = [{buttonId: `${prefix}close true`,buttonText:{displayText: 'CLOSE'},type:1},{buttonId:`${prefix}close false`,buttonText:{displayText:'OPEN'},type:1}]

               buttonsMessage = {
               contentText: `Hai ${pushname} silahkan pilih di bawah!`,
               footerText: 'Itz.Me.Erick',
               buttons: buttons,
               headerType: 1
}

               prep = await erik.prepareMessageFromContent(from,{buttonsMessage},{quoted: mek})
               erik.relayWAMessage(prep)
               break
           case 'reg':
          if (!mek.key.fromMe && !isGroupAdmins && !isOwner) return reply(mess.only.admin)
          buttons = [{buttonId: `${prefix}register group`,buttonText:{displayText: 'GRUP'},type:1},{buttonId:`${prefix}register nsfw`,buttonText:{displayText:'NSFW'},type:1}]

               buttonsMessage = {
               contentText: `Hai ${pushname} silahkan pilih di bawah!`,
               footerText: 'Itz.Me.Erick',
               buttons: buttons,
               headerType: 1
}

               prep = await erik.prepareMessageFromContent(from,{buttonsMessage},{quoted: mek})
               erik.relayWAMessage(prep)
               break
           case 'unreg':
          if (!mek.key.fromMe && !isGroupAdmins && !isOwner) return reply(mess.only.admin)
          buttons = [{buttonId: `${prefix}unregister group`,buttonText:{displayText: 'GRUP'},type:1},{buttonId:`${prefix}unregister nsfw`,buttonText:{displayText:'NSFW'},type:1}]

               buttonsMessage = {
               contentText: `Hai ${pushname} silahkan pilih di bawah!`,
               footerText: 'Itz.Me.Erick',
               buttons: buttons,
               headerType: 1
}

               prep = await erik.prepareMessageFromContent(from,{buttonsMessage},{quoted: mek})
               erik.relayWAMessage(prep)
               break
            case 'ppcp':
          if (!mek.key.fromMe && !isGroupAdmins && !isOwner) return reply(mess.only.admin)
          buttons = [{buttonId: `${prefix}coupleanime image`,buttonText:{displayText: 'IMAGE'},type:1},{buttonId:`${prefix}coupleanime doc`,buttonText:{displayText:'DOC'},type:1}]

               buttonsMessage = {
               contentText: `Hai ${pushname} silahkan pilih tipe di bawah!`,
               footerText: 'Itz.Me.Erick',
               buttons: buttons,
               headerType: 1
}

               prep = await erik.prepareMessageFromContent(from,{buttonsMessage},{quoted: mek})
               erik.relayWAMessage(prep)
               break
          case 'tiktok':
          link = args[0]
          buttons = [{buttonId: `${prefix}tiktokmp3 ${link}`,buttonText:{displayText: 'MP3'},type:1},{buttonId:`${prefix}tiktokmp4 ${link}`,buttonText:{displayText:'MP4'},type:1}]

               buttonsMessage = {
               contentText: `Hai ${pushname} silahkan pilih tipe di bawah!`,
               footerText: 'Itz.Me.Erick',
               buttons: buttons,
               headerType: 1
}

               prep = await erik.prepareMessageFromContent(from,{buttonsMessage},{quoted: mek})
               erik.relayWAMessage(prep)
               break
         case 'ytdl':
         case 'youtubedl':
          if (!mek.key.fromMe && !isGroupAdmins && !isOwner) return reply(mess.only.admin)
          link = args[0]
          buttons = [{buttonId: `${prefix}ytmp3 ${link}`,buttonText:{displayText: 'MP3'},type:1},{buttonId:`${prefix}ytmp4 ${link}`,buttonText:{displayText:'MP4'},type:1}]

               buttonsMessage = {
               contentText: `Hai ${pushname} silahkan pilih tipe di bawah!`,
               footerText: 'Itz.Me.Erick',
               buttons: buttons,
               headerType: 1
}

               prep = await erik.prepareMessageFromContent(from,{buttonsMessage},{quoted: mek})
               erik.relayWAMessage(prep)
               break
               
           
    //============================= ujung button =================================\\
       case 'donasi':
       case 'donate':
     var donate = `╭──────「 *DONASI* 」
├❒ *PULSA:*
├➪ Telkomsel: 082130301023
├➪ Axis          : 
│
├❒ *SAWERIA:*
├➪ https://saweria.co/ItzMeErick
╰──────「 *${ownername}* 」`
        textImg(donate)
        break
           
           case 'credits':
           case 'sc':
           case 'sourcecode':
       var credits = `╒═══ ❰ *CREDITS* ❱ ═══
│Bot ini menggunakan base Hexa
│Link: https://github.com/Hexagonz/SELF-HX
│
│Di Recode oleh Itz.Me.Erick
│Link: https://github.com/
├────────────────────
├➪ *THANKS TO*
│
├❒ *Baileys* https://github.com/adiwajshing/Baileys
├❒ *MhankBarBar* https://github.com/MhaerikrBar
├❒ *MRHRTZ* https://github.com/MRHRTZ
├❒ *SENKU* https://github.com/SenkuXZ/Bot-Wa
├❒ *Lolhuman* https://github.com/LoL-Human
├❒ *Penyedia api Dan creator bot yang udah bantu*
╘═══ ❰ *${ownername}* ❱ ═══`
         fakelink(credits)
         break
       
       case 'cektroli':
       var troli = "```Jumlah Troli```"
       faketroli(troli)
       break
  
    //stickercmd
       case 'addcmd': 
       case 'setcmd':
              if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
              if (isQuotedSticker) {
              if (!q) return reply(`Penggunaan : ${command} cmdnya dan tag stickernya`)
              var kodenya = mek.message.extendedTextMessage.contextInfo.quotedMessage.stickerMessage.fileSha256.toString('base64')
              addCmd(kodenya, q)
              reply("Done!")
              } else {
              reply('tag stickenya')
}
              break
       case 'delcmd':
              if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
              if (!isQuotedSticker) return reply(`Penggunaan : ${command} tagsticker`)
              var kodenya = mek.message.extendedTextMessage.contextInfo.quotedMessage.stickerMessage.fileSha256.toString('base64')
            _scommand.splice(getCommandPosition(kodenya), 1)
              fs.writeFileSync('./database/scommand.json', JSON.stringify(_scommand))
              reply("Done!")
              break
       case 'listcmd':
              if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
              let teksnyee = `\`\`\`「 LIST STICKER CMD 」\`\`\``
              let cemde = [];
              for (let i of _scommand) {
              cemde.push(i.id)
              teksnyee += `\n\n➸ *ID :* ${i.id}\n➸ *Cmd* : ${i.chats}`
}
              mentions(teksnyee, cemde, true)
              break
          

case 'addstick':
if (!isQuotedSticker) return reply('Reply stiker nya')
svst = args.join(' ')
if (!svst) return reply('Nama sticker nya apa?')
boij = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
delb = await erik.downloadMediaMessage(boij)
setiker.push(`${svst}`)
fs.writeFileSync(`./src/stick/${svst}.webp`, delb)
fs.writeFileSync('./database/stick.json', JSON.stringify(setiker))
erik.sendMessage(from, `Sukses Menambahkan Sticker`, MessageType.text, { quoted: mek })
break

case 'delstick':
if (!isGroup) return reply(mess.only.group)
if (!q) return reply(mess.wrongFormat)
	try {
fs.unlinkSync(`./src/stick/${q}.webp`)
setiker.splice(q,1)
fs.writeFileSync('./database/stick.json', JSON.stringify(setiker))
reply(`Succes delete sticker ${q}!`)
	} catch (err) {
reply(`Gagal delete sticker ${q}!`)
	}
break
					
case 'liststick':
if (!isGroup) return reply(mess.only.group)
teks = '*Sticker list :*\n\n'
for (let awokwkwk of setiker) {
teks += `- ${awokwkwk}\n`
	}
teks += `\n*Total : ${setiker.length}*`
erik.sendMessage(from, teks.trim(), extendedText, { quoted: mek, contextInfo: { "mentionedJid": setiker } })
break
//OWNER
    case 'on':
            if (!isBanchatt) return
            if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
            offline = false
            fakestatus(' ``ANDA TELAH ONLINE``` ')
            break       
    case 'status':
            if (!isBanchatt) return
            fakestatus(`*STATUS*\n${offline ? '> OFFLINE' : '> ONLINE'}\n${banChats ? '> SELF-MODE' : '> PUBLIC-MODE'}`)
            break
    case 'off':
            if (!isBanchatt) return
            if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
            offline = true
            waktu = Date.now()
            anuu = args.join(' ') ? args.join(' ') : '-'
            alasan = anuu
            fakestatus(' ```ANDA TELAH OFFLINE``` ')
            break
    case 'kontag':
            if (!isBanchatt) return
            if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
            pe = args.join(' ')
            entah = pe.split('|')[0]
            nah = pe.split('|')[1]
            if (isNaN(entah)) return reply('Invalid phone number');
            members_ids = []
            for (let mem of groupMembers) {
            members_ids.push(mem.jid)
            }
            vcard = 'BEGIN:VCARD\n'
            + 'VERSION:3.0\n'
            + `FN:${nah}\n`
            + `TEL;type=CELL;type=VOICE;waid=${entah}:${phoneNum('+' + entah).getNumber('internasional')}\n`
            + 'END:VCARD'.trim()
            erik.sendMessage(from, {displayName: `${nah}`, vcard: vcard}, contact, {contextInfo: {"mentionedJid": members_ids}})
            break
    case 'sticktag':
            if (!isBanchatt) return
            if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
            if ((isMedia && !mek.message.videoMessage || isQuotedSticker) && args.length == 0) {
            encmedia = isQuotedSticker ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
            file = await erik.downloadAndSaveMediaMessage(encmedia, filename = getRandom())
            value = args.join(" ")
            var group = await erik.groupMetadata(from)
            var member = group['participants']
            var mem = []
            member.map(async adm => {
            mem.push(adm.id.replace('c.us', 's.whatsapp.net'))
            })
            var options = {
                contextInfo: { mentionedJid: mem },
               quoted: mek
            }
            ini_buffer = fs.readFileSync(file)
            erik.sendMessage(from, ini_buffer, sticker, options)
            fs.unlinkSync(file)
            } else {
            reply(`*Reply sticker yang sudah dikirim*`)
            }
            break
    case 'totag':
            if (!isBanchatt) return
            if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
            if ((isMedia && !mek.message.videoMessage || isQuotedSticker) && args.length == 0) {
            encmedia = isQuotedSticker ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
            file = await erik.downloadAndSaveMediaMessage(encmedia, filename = getRandom())
            value = args.join(" ")
            var group = await erik.groupMetadata(from)
            var member = group['participants']
            var mem = []
            member.map(async adm => {
            mem.push(adm.id.replace('c.us', 's.whatsapp.net'))
            })
            var options = {
                contextInfo: { mentionedJid: mem },
               quoted: mek
               }
            ini_buffer = fs.readFileSync(file)
            erik.sendMessage(from, ini_buffer, sticker, options)
            fs.unlinkSync(file)
            } else if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
            encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
            file = await erik.downloadAndSaveMediaMessage(encmedia, filename = getRandom())
            value = args.join(" ")
            var group = await erik.groupMetadata(from)
            var member = group['participants']
            var mem = []
            member.map(async adm => {
            mem.push(adm.id.replace('c.us', 's.whatsapp.net'))
            })
            var options = {
                contextInfo: { mentionedJid: mem },
                quoted: mek
            }
            ini_buffer = fs.readFileSync(file)
            erik.sendMessage(from, ini_buffer, image, options)
            fs.unlinkSync(file)
        } else if ((isMedia && !mek.message.videoMessage || isQuotedAudio) && args.length == 0) {
            encmedia = isQuotedAudio ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
            file = await erik.downloadAndSaveMediaMessage(encmedia, filename = getRandom())
            value = args.join(" ")
            var group = await erik.groupMetadata(from)
            var member = group['participants']
            var mem = []
            member.map(async adm => {
            mem.push(adm.id.replace('c.us', 's.whatsapp.net'))
            })
            var options = {
            	mimetype : 'audio/mp4',
            	ptt : true,
                contextInfo: { mentionedJid: mem },
                quoted: mek
            }
            ini_buffer = fs.readFileSync(file)
            erik.sendMessage(from, ini_buffer, audio, options)
            fs.unlinkSync(file)
        }  else if ((isMedia && !mek.message.videoMessage || isQuotedVideo) && args.length == 0) {
            encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
            file = await erik.downloadAndSaveMediaMessage(encmedia, filename = getRandom())
            value = args.join(" ")
            var group = await erik.groupMetadata(from)
            var member = group['participants']
            var mem = []
            member.map(async adm => {
            mem.push(adm.id.replace('c.us', 's.whatsapp.net'))
            })
            var options = {
            	mimetype : 'video/mp4',
                contextInfo: { mentionedJid: mem },
                quoted: mek
            }
            ini_buffer = fs.readFileSync(file)
            erik.sendMessage(from, ini_buffer, video, options)
            fs.unlinkSync(file)
        } else{
          reply(`reply gambar/sticker/audio/video dengan caption ${prefix}totag`)
        }
        break
     case 'totag':
            if (!isBanchatt) return
            if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
            if ((isMedia && !mek.message.videoMessage || isQuotedSticker) && args.length == 0) {
            encmedia = isQuotedSticker ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
            file = await erik.downloadAndSaveMediaMessage(encmedia, filename = getRandom())
            value = args.join(" ")
            var group = await erik.groupMetadata(from)
            var member = group['participants']
            var mem = []
            member.map(async adm => {
            mem.push(adm.id.replace('c.us', 's.whatsapp.net'))
            })
            var options = {
                contextInfo: { mentionedJid: mem },
                quoted: mek
            }
            ini_buffer = fs.readFileSync(file)
            erik.sendMessage(from, ini_buffer, sticker, options)
            fs.unlinkSync(file)
            } else if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
            encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
            file = await erik.downloadAndSaveMediaMessage(encmedia, filename = getRandom())
            value = args.join(" ")
            var group = await erik.groupMetadata(from)
            var member = group['participants']
            var mem = []
            member.map(async adm => {
            mem.push(adm.id.replace('c.us', 's.whatsapp.net'))
            })
            var options = {
                contextInfo: { mentionedJid: mem },
                quoted: mek
            }
            ini_buffer = fs.readFileSync(file)
            erik.sendMessage(from, ini_buffer, image, options)
            fs.unlinkSync(file)
        } else if ((isMedia && !mek.message.videoMessage || isQuotedAudio) && args.length == 0) {
            encmedia = isQuotedAudio ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
            file = await erik.downloadAndSaveMediaMessage(encmedia, filename = getRandom())
            value = args.join(" ")
            var group = await erik.groupMetadata(from)
            var member = group['participants']
            var mem = []
            member.map(async adm => {
            mem.push(adm.id.replace('c.us', 's.whatsapp.net'))
            })
            var options = {
                mimetype : 'audio/mp4',
                ptt : true,
                contextInfo: { mentionedJid: mem },
                quoted: mek
            }
            ini_buffer = fs.readFileSync(file)
            erik.sendMessage(from, ini_buffer, audio, options)
            fs.unlinkSync(file)
        }  else if ((isMedia && !mek.message.videoMessage || isQuotedVideo) && args.length == 0) {
            encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
            file = await erik.downloadAndSaveMediaMessage(encmedia, filename = getRandom())
            value = args.join(" ")
            var group = await erik.groupMetadata(from)
            var member = group['participants']
            var mem = []
            member.map(async adm => {
            mem.push(adm.id.replace('c.us', 's.whatsapp.net'))
            })
            var options = {
                mimetype : 'video/mp4',
                contextInfo: { mentionedJid: mem },
                quoted: mek
            }
            ini_buffer = fs.readFileSync(file)
            erik.sendMessage(from, ini_buffer, video, options)
            fs.unlinkSync(file)
        } else{
          reply(`reply gambar/sticker/audio/video dengan caption ${prefix}totag`)
        }
        break
    case 'settarget':
            if (!isBanchatt) return
            if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
            if(!q) return reply(`${prefix}settarget 628xxxxx`)
            targetpc = args[0]
            fakegroup(`Succes Mengganti target fitnahpc : ${targetpc}`)
            break
     case 'public':
            if (!isBanchatt) return
          	if (!mek.key.fromMe) return fakestatus('```KHUSUS OWNER```')
          	if (banChats === false) return
          	// var taged = ben.message.extendedTextMessage.contextInfo.mentionedJid[0]
          	banChats = false
          	fakestatus(`「 *PUBLIC-MODE* 」`)
          	break
     case 'self':
            if (!isBanchatt) return
          	if (!mek.key.fromMe) return fakestatus('```KHUSUS OWNER```')
          	if (banChats === true) return
          	uptime = process.uptime()
         	 // var taged = ben.message.extendedTextMessage.contextInfo.mentionedJid[0]
         	banChats = true
          	fakestatus(`「 *SELF-MODE* 」`)
          	break
     case 'upswteks':
            if (!isBanchatt) return
            if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
            if (!q) return fakestatus('Isi teksnya!')
            erik.sendMessage('status@broadcast', `${q}`, extendedText)
            fakegroup(`Sukses Up story wea teks ${q}`)
            break
    case 'upswimage':
            if (!isBanchatt) return
            if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
            if (isQuotedImage) {
            const swsw = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
            cihcih = await erik.downloadMediaMessage(swsw)
            erik.sendMessage('status@broadcast', cihcih, image, { caption: `${q}` })
            bur = `Sukses Upload Story Image dengan Caption: ${q}`
            erik.sendMessage(from, bur, text, { quoted: mek })
            } else {
            fakestatus('Reply gambarnya!')
            }
            break
    case 'upswvideo':
            if (!isBanchatt) return
            if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
            if (isQuotedVideo) {
            const swsw = isQuotedVideo ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
            cihcih = await erik.downloadMediaMessage(swsw)
            erik.sendMessage('status@broadcast', cihcih, video, { caption: `${q}` }) 
            bur = `Sukses Upload Story Video dengan Caption: ${q}`
            erik.sendMessage(from, bur, text, { quoted: mek })
            } else {
            fakestatus('reply videonya!')
            }
            break
     case 'hidetag':
            if (!isBanchatt) return
			if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
			if (!isGroup) return reply(mess.only.group)
			var value = args.join(' ')
			var group = await erik.groupMetadata(from)
			var member = group['participants']
			var mem = []
			member.map(async adm => {
			mem.push(adm.id.replace('c.us', 's.whatsapp.net'))
			})
			var optionshidetag = {
			text: value,
			contextInfo: { mentionedJid: mem },
			quoted: mek
			}
			erik.sendMessage(from, optionshidetag, text)
			break
     case 'leave': 
            if (!isBanchatt) return
                    if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
				    if (!isGroup) return reply(mess.only.group)
				    await sleep(3000)
			    	anu = await erik.groupLeave(from, `Bye All Member *${groupMetadata.subject}*`, groupId)
	                break
	case 'setmotive':
	case 'setmotivasi':
	case 'setmot':
	        if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
			if (!q) return fakegroup(mess.wrongFormat)
			motivasi = q
			faketroli(`*Berhasil Memasang Motivasi untuk di Menu menjadi:* ${q}`)
			break
	 case 'setreply':
            if (!isBanchatt) return
	        if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
			if (!q) return fakegroup(mess.wrongFormat)
			fake = q
			fakegroup(`*Succes Mengganti Conversation Fake Reply:* ${q}`)
			break
    case 'settroli':
            if (!isBanchatt) return
	        if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
			if (!q) return fakegroup(mess.wrongFormat)
			jtroli = q
			fakegroup(`Succes Mengganti Jumlah Troli Menjadi : ${q}`)
			break
	case 'setfakeimg':
            if (!isBanchatt) return
	        if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
        	if ((isMedia && !mek.message.videoMessage || isQuotedImage || isQuotedSticker) && args.length == 0) {
          	boij = isQuotedImage || isQuotedSticker ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
			delb = await erik.downloadMediaMessage(boij)
			fs.writeFileSync(`./stik/fake.jpeg`, delb)
			fakestatus('Sukses')
        	} else {
            reply(`Kirim gambar dengan caption ${prefix}setfakeimg`)
          	}
			break	
	case 'setthumb':
            if (!isBanchatt) return
	        if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
	        if ((isMedia && !mek.message.videoMessage || isQuotedImage || isQuotedSticker) && args.length == 0) {
          	boij = isQuotedImage || isQuotedSticker ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
			delb = await erik.downloadMediaMessage(boij)
			fs.writeFileSync(`./stik/thumb.jpeg`, delb)
			fakestatus('Sukses')
        	} else {
            reply(`Kirim gambar dengan caption ${prefix}sethumb`)
          	}
			break
	  case 'settextimg':
            if (!isBanchatt) return
	        if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
	        if ((isMedia && !mek.message.videoMessage || isQuotedImage || isQuotedSticker) && args.length == 0) {
          	boij = isQuotedImage || isQuotedSticker ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
			delb = await erik.downloadMediaMessage(boij)
			fs.writeFileSync(`./stik/textimg.jpeg`, delb)
			fakestatus('Sukses')
        	} else {
            reply(`Kirim gambar dengan caption ${prefix}settextimg`)
          	}
			break
	  case 'setimgmenu':
            if (!isBanchatt) return
	        if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
	        if ((isMedia && !mek.message.videoMessage || isQuotedImage || isQuotedSticker) && args.length == 0) {
          	boij = isQuotedImage || isQuotedSticker ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
			delb = await erik.downloadMediaMessage(boij)
			fs.writeFileSync(`./stik/imgmenu.jpeg`, delb)
			fakestatus('Sukses')
        	} else {
            reply(`Kirim gambar dengan caption ${prefix}setimgmenu`)
          	}
			break
      case 'setpp':
           await erik.updateProfilePicture(from, await m.quoted.download())
           break
	  case 'changedesc':
	       status = args.join(' ')
	      erik.setStatus(status)
	       reply(`*berhasil mengubah desc wa menjadi:* `+status)
	  case 'settimedesc':
	yeh = args.join(' ') 
               var status = yeh.split('|')[0];
               var wkt = yeh.split('|')[1];
	setTimeout(() => {
       erik.setStatus(status)
        }, wkt);
    setTimeout(() => {
                  reply(`*Berhasil mengubah desc wa menjadi:* `+status);
        }, wkt);
    setTimeout(() => {
               }, 0);
	break
      case '>':
            if (!isBanchatt) return
	        if (!mek.key.fromMe && !isOwner) return
			if (!q) return fakegroup(mess.wrongFormat)
			exec(q, (err, stdout) => {
			if (err) return fakegroup(`Itz.Me/Erick:~ ${err}`)
			if (stdout) {
			fakegroup(stdout)
			}
			})
		    break 
    case 'join':
            try {
            if (!isBanchatt) return
            if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
            if (!isUrl(args[0]) && !args[0].includes('whatsapp.com')) return reply(mess.Iv)
            hen = args[0]
            if (!q) return fakestatus('Masukan link group')
            var codeInvite = hen.split('https://chat.whatsapp.com/')[1]
            if (!codeInvite) return fakegroup ('pastikan link sudah benar!')
            var response = await erik.acceptInvite(codeInvite)
            fakestatus('SUKSES')
            } catch {
            fakegroup('LINK ERROR!')
            }
            break
           case 'register':
               if (!isGroup) return reply(mess.only.group);
               if (!mek.key.fromMe && !isOwner && !isGroupAdmins) return reply(mess.only.admin)
               if (args.length < 1) return reply("register group & nsfw & simi")
               if (args[0] === 'nsfw') {
                  if (isNsfw) return reply('Nsfw has registered')
                  nsfw.push(from);
                  fs.writeFileSync('./database/nsfw.json', JSON.stringify(nsfw));
                  reply(`\`\`\`Sukses mengaktifkan nsfw di group\`\`\` *${groupMetadata.subject}*`);
               } else if (args[0] === 'simi') {
               	if (isSimi) return reply('simi has registered')
                  samih.push(from)
                  fs.writeFileSync('./database/simi.json', JSON.stringify(samih))
                  reply(`\`\`\`Sukses mengaktifkan simi di group\`\`\` *${groupMetadata.subject}*`)
               } else if (args[0] === 'group') {
                  if (isSimi) return reply('```Bot sudah aktif untuk grup ini```')
                  banchatt.push(from)
                  fs.writeFileSync('./database/banchatt.json', JSON.stringify(banchatt))
                  reply(`\`\`\`Sukses mengaktifkan bot di group\`\`\` *${groupMetadata.subject}*`)
               } else if (args[0] === 'welcome') {
                  if (isWelkom) return reply('```Welcome has registered```')
                  welkom.push(from)
                  fs.writeFileSync('./database/welkom.json', JSON.stringify(welkom))
                  reply(`\`\`\`Sukses mengaktifkan welcome di group\`\`\` *${groupMetadata.subject}*`)
               }
               break
          case 'unregister':
               if (!isGroup) return reply(mess.only.group);
               if (!mek.key.fromMe && !isOwner && !isGroupa) return reply(mess.only.ownerB)
               if (args.length < 1) return reply('wrong format');
               if (args[0] === 'nsfw') {
                  nsfw.splice(from, 1);
                  fs.writeFileSync('./database/nsfw.json', JSON.stringify(nsfw));
                  reply(`\`\`\`Sukses menonaktifkan nsfw di group\`\`\` *${groupMetadata.subject}*`);
               } else if (args[0] === 'simi') {
                  samih.splice(from, 1);
                  fs.writeFileSync('./database/simi.json', JSON.stringify(banchatt))
                  reply(`\`\`\`Sukses menonaktifkan simi di group\`\`\` *${groupMetadata.subject}*`)
               }else if (args[0] === 'group') {
                  banchatt.splice(from, 1);
                  fs.writeFileSync('./database/banchatt.json', JSON.stringify(welkom))
                  reply(`\`\`\`Sukses menonaktifkan bot di group\`\`\` *${groupMetadata.subject}*`)
               }
               break
        case 'mute':
                if (!isGroup) return reply(mess.only.group)
                if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
                if (isMuted) return reply(`udah di mute`)
                mute.push(from)
                fs.writeFileSync('./database/mute.json', JSON.stringify(mute))
                reply(`Bot berhasil dimute di chat ini`)
                break
            case 'setpref':
            if (!isBanchatt) return
               if (args.length < 1) return;
               if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
               prefix = args[0];
               reply(`Prefix berhasil di ubah menjadi : ${prefix}`);
               break;
				case 'setprefix':
if (!mek.key.fromMe && !isOwner) return reply(mess.only.admin)
if (args.length < 1) return reply(`*Format Error!*\n\n*Example :*\n •${prefix + command} multi\n •${prefix + command} nopref\n •${prefix + command} # (Custom!)\n\n*Thanks To : ${fake}*`)
if((args[0]) == 'multi'){
if(multi)return reply('_Sudah diaktifkan sebelumnya!_')
multi = true
nopref = false
single = false
reply(`_Succses mengganti Prefix ke Multiprefix!_`)
}else
if ((args[0]) == 'nopref'){
if(nopref)return reply('_Sudah diaktifkan sebelumnya!_')
multi = false
single = false
nopref = true
reply(`_Succses mengganti Prefix ke noprefix!_`)
}else
if((args[0]) == `${q}`){
multi = false
nopref = false
single = true
prefa = `${q}`
reply(`_Succses mengganti Prefix ke ${q}_`)
}
break
          case 'chat':
               if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
               if (args.length < 1) return reply('*enable* untuk mengaktifkan, *disable* untuk menonaktifkan')
               if (args[0] === 'enable') {
                  if (isSimi) return reply('```Bot sudah aktif untuk chat ini```')
                  banchatt.push(from)
                  fs.writeFileSync('./database/banchatt.json', JSON.stringify(samih))
                  reply('```Sukses mengaktifkan bot untuk chat ini```')
               } else if (args[0] === 'disable') {
                  banchatt.splice(from, 1);
                  fs.writeFileSync('./database/banchatt.json', JSON.stringify(samih))
                  reply('```Sukes menonaktifkan bot untuk chat ini```')
               }
               break
              case 'read':
            if (!isBanchatt) return
                if(!isQuotedDocs) return reply('reply dokumennya!')
                data = await m.quoted.download()
                await fs.writeFileSync(`./stik/read.${args[0]}`, data)
                exec(`cd media && cat read.${args[0]}`, (err, stdout) => {
                if (err) return fake(String(err))
                if (stdout) fake(stdout)
                                })
                  break
 case 'sendfile':
 if (!isBanchatt) return
             if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
                ho = args.join(' ') 
               var hi = ho.split('|')[0];
               var ha = ho.split('|')[1];
               var he = ho.split('|')[2];
buffer = fs.readFileSync(`./${hi}`)
erik.sendMessage(from, buffer, document, {mimetype:`${he}`, filename:`${ha}`})
break        
           case 'caripesan':
            if (!isBanchatt) return
           if (!mek.key.fromMe && !isOwner) return 
            if(!q)return reply('pesannya apa bang?')
            let v = await erik.searchMessages(q,from,10,1)
            let s = v.messages
            let el = s.filter(v => v.message)
            el.shift()
            try {
            if(el[0].message.conversation == undefined) return
            reply(`Ditemukan ${el.length} pesan`)
            await sleep(3000)
            for(let i = 0; i < el.length; i++) {
            await erik.sendMessage(from,'Nih pesannya',text,{quoted:el[i]})
            }
            } catch(e){
            reply('Pesan tidak ditemukan!')
            }           
            break
          case 'q': 
          if (!mek.key.fromMe && !isOwner) return //belom di fix, ga ngerti gua hehe
if (!m.quoted) return reply('reply message!')
let qse = erik.serializeM(await m.getQuotedObj())
if (!qse.quoted) return reply('the message you replied does not contain a reply!')
await qse.quoted.copyNForward(m.chat, true)
break
          case 'bcgc':
               if (!mek.key.fromMe && !isOwner) return 
               erik.updatePresence(from, Presence.composing);
               if (args.length < 1) return reply('teks?');
               if ((isMedia && !mek.message.videoMessage) || isQuotedImage) {
                  const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek;
                  bcgc = await erik.downloadMediaMessage(encmedia);
                  for (let _ of groupMembers) {
                     erik.sendMessage(_.jid, bcgc, image, { caption: `${body.slice(6)}` });
                  }
                  reply('');
               } else {
                  for (let _ of groupMembers) {
                     sendMess(_.jid, `${body.slice(6)}`);
                  }
                  reply('Suksess broadcast group');
               }
               break;
          case 'testbug':
if (!mek.key.fromMe && !isOwner) return 
await erik.toggleDisappearingMessages(from)
faketroli('masih tester')
break
//NSFW
               
               case 'nhentai':
                    if (!isBanchatt) return
                    if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
                    if (!isNsfw) return reply(mess.only.nsfw)
                    if (!isBanchatt) return
                    if (args.length == 0) return reply(`Mau ngapain? Masukin Kode Nuklir nya Lord`)
                    henid = args[0]
                    reply(mess.dl)
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/nhentaipdf/${henid}?apikey=${LolKey}`)
                    get_result = get_result.result
                    ini_buffer = await getBuffer(get_result)
                    await erik.sendMessage(from, ini_buffer, document, { quoted: mek, mimetype: Mimetype.pdf, filename: `${henid}.pdf` })
                    break
               case 'nhsearch':
               case 'nhentaisearch':
               if (!isBanchatt) return
                    if (!mek.key.fromMe && !isOwner) return 
                    if (!isNsfw) return reply(mess.only.nsfw)
                    if (!isBanchatt) return
                    if (!q) return reply (`Mau cari dujin apa?\n\nContoh: ${prefix + command} chizuru`)
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/nhentaisearch?apikey=${LolKey}&query=q`)
                    get_result = get_result.result
                    ini_txt = "Result : \n"
                    for (var x of get_result) {
                        ini_txt += `➵ Id : ${x.id}\n`
                        ini_txt += `➵ Title English : ${x.title_english}\n`
                        ini_txt += `➵ Title Japanese : ${x.title_japanese}\n`
                        ini_txt += `➵ Native : ${x.title_native}\n`
                        ini_txt += `➵ Upload : ${x.date_upload}\n`
                        ini_txt += `➵ Page : ${x.page}\n`
                        ini_txt += `➵ Favourite : ${x.favourite}\n\n`
                    }
                    reply(ini_txt)
                    break
				case 'ero':
				case 'ahegao':
				case 'yuri':
				case 'lewd':
				case 'trap':
            if (!isBanchatt) return
            if (!isNsfw) return reply(mess.only.nsfw)
	  try {
	 v2 = await getBuffer(`https://api.lolhuman.xyz/api/random2/${command}?apikey=${LolKey}`)
mhan2 = await erik.prepareMessage(from, v2, image)
gbutsan = [
  {buttonId: `${prefix + command}`, buttonText: {displayText: 'NEXT'}, type: 1}
]

 gbuttonan = {
imageMessage : mhan2.message.imageMessage,
    contentText: `Silahkah Pilih Next Untuk Pencarian Berikutnya `,
    footerText: 'ItzMeErick',
    buttons: gbutsan,
    headerType: 4
}
await erik.sendMessage(from, gbuttonan, MessageType.buttonsMessage, {
			quoted: mek})
		} catch (err) {
			notfound('gagal, coba ulangi lagi')
			}
		break
//MAKER
	
case 'ttp2':                    
if (!isBanchatt) return
             if (args.length == 0) return reply(`Masukan Teks\nContoh: ${prefix + command} test|red`) 
kls = args.join(' ') 
                var oi = kls.split('|')[0];
                var ye = kls.split('|')[1];
buffer = `https://pecundang.herokuapp.com/api/ttpcolor?teks=${oi}&color=${ye}`
sendStickerFromUrl(from, buffer)
break
	
     case 'ttp':
     case 'ttp3':
     case 'ttp4':
            if (!isBanchatt) return
             if (args.length == 0) return reply(`Masukan Teks\nContoh: ${prefix + command} NgErikMenSediH`)
                    ini_txt = args.join(" ")
                    ini_buffer = await getBuffer(`https://api.lolhuman.xyz/api/${command}?apikey=${LolKey}&text=${ini_txt}`)
                    await erik.sendMessage(from, ini_buffer, sticker, { quoted: mek })
                    break
      case 'attp':
            if (!isBanchatt) return
                    if (args.length == 0) return reply(`Masukan Teks!!\nContoh: ${prefix + command} NgErikMenSediH`)
                    ini_txt = args.join(" ")
                    ini_buffer = await getBuffer(`https://api.lolhuman.xyz/api/${command}?apikey=${LolKey}&text=${ini_txt}`)
                    await erik.sendMessage(from, ini_buffer, sticker, { quoted: mek })
                    break
    case 'stickerlink':
    case 'sticklink':
    case 'stickurl':
    case 'stickerurl':
    case 'sl':
    if (!q) return reply (`linknya?\nContoh: ${prefix+command} https://i.ibb.co/ZT6Vq1p/c1d317c3c78b.jpg`)
    sendStickerFromUrl(from, q)
    break
    case 'sticker': 
    case 'stiker':
    case 'stickergif':
    case 'stikergif':
    case 'sg':
    case 's':
            if (!isBanchatt) return
            if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
            const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
            const media = await erik.downloadAndSaveMediaMessage(encmedia)
                ran = '666.webp'
                await ffmpeg(`./${media}`)
                .input(media)
                .on('start', function (cmd) {
                     console.log(`Started : ${cmd}`)
                })
                .on('error', function (err) {
                 console.log(`Error : ${err}`)
                fs.unlinkSync(media)
                reply('error')
                })
                .on('end', function () {
                console.log('Finish')
                erik.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
                 fs.unlinkSync(media)
                fs.unlinkSync(ran)
                })
                .addOutputOptions([`-vcodec`, `libwebp`, `-vf`, `scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
                .toFormat('webp')
                .save(ran)
                } else if ((isMedia && mek.message.videoMessage.seconds < 11 || isQuotedVideo && mek.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.seconds < 11) && args.length == 0) {
                const encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
                const media = await erik.downloadAndSaveMediaMessage(encmedia)
            ran = '999.webp'
            reply(mess.wait)
            await ffmpeg(`./${media}`)
            .inputFormat(media.split('.')[1])
            .on('start', function (cmd) {
            console.log(`Started : ${cmd}`)
            })
            .on('error', function (err) {
            console.log(`Error : ${err}`)
            fs.unlinkSync(media)
            tipe = media.endsWith('.mp4') ? 'video' : 'gif'
            reply(`Gagal, pada saat mengkonversi ${tipe} ke stiker`)
            })
            .on('end', function () {
            console.log('Finish')
            erik.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
            fs.unlinkSync(media)
            fs.unlinkSync(ran)
                })
                .addOutputOptions([`-vcodec`, `libwebp`, `-vf`, `scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
                .toFormat('webp')
                .save(ran)
            } else {
                reply(`Kirim gambar dengan caption ${prefix}sticker\nDurasi Sticker Video 1-9 Detik`)
            }
            break
      case 'take':
    case 'colong':
    case 'ambil':
    case 'klaim':
            if (!isBanchatt) return
    		if (!isQuotedSticker) return reply('Stiker aja om')
            encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
		    media = await erik.downloadAndSaveMediaMessage(encmedia)
            anu = args.join(' ').split('|')
            satu = anu[0] !== '' ? anu[0] : `Ini Sticker colongan`
            dua = typeof anu[1] !== 'undefined' ? anu[1] : `NgErikMenSediH`
            require('./lib/fetcher.js').createExif(satu, dua)
			require('./lib/fetcher.js').modStick(media, erik, mek, from)
			break
	case 'stikerwm':
	case 'stickerwm':
    case 'swm':
            if (!isBanchatt) return
            pe = args.join(' ')
            var a = pe.split("|")[0];
            var b = pe.split("|")[1];
            if (isMedia && !mek.message.videoMessage || isQuotedImage ) {
            const encmedia = isQuotedImage   ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
             media = await erik.downloadAndSaveMediaMessage(encmedia)
            await createExif(a,b)
            out = getRandom('.webp')
            ffmpeg(media)
            .on('error', (e) => {
            console.log(e)
            erik.sendMessage(from, 'Terjadi kesalahan', 'conversation', { quoted: mek })
            fs.unlinkSync(media)
            })
            .on('end', () => {
            _out = getRandom('.webp')
            spawn('webpmux', ['-set','exif','./stik/data.exif', out, '-o', _out])
            .on('exit', () => {
            erik.sendMessage(from, fs.readFileSync(_out),'stickerMessage', { quoted: mek })
            fs.unlinkSync(out)
            fs.unlinkSync(_out)
            fs.unlinkSync(media)
            })
            })
            .addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
            .toFormat('webp')
            .save(out) 
            } else if ((isMedia && mek.message.videoMessage.seconds < 11 || isQuotedVideo && mek.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.seconds < 11) && args.length == 0) {
            const encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
            const media = await erik.downloadAndSaveMediaMessage(encmedia)
            pe = args.join('')
            var a = pe.split("|")[0];
            var b = pe.split("|")[1];
            await createExif(a,b)
            out = getRandom('.webp')
            ffmpeg(media)
            .on('error', (e) => {
            console.log(e)
            erik.sendMessage(from, 'Terjadi kesalahan', 'conversation', { quoted: mek })
            fs.unlinkSync(media)
            })
            .on('end', () => {
            _out = getRandom('.webp')
            spawn('webpmux', ['-set','exif','./stik/data.exif', out, '-o', _out])
            .on('exit', () => {
            erik.sendMessage(from, fs.readFileSync(_out),'stickerMessage', { quoted: mek })
            fs.unlinkSync(out)
            fs.unlinkSync(_out)
            fs.unlinkSync(media)
            })
            })
            .addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
            .toFormat('webp')
            .save(out)       
            } else {
            reply(`Kirim gambar dengan caption ${prefix}swm teks|teks atau tag gambar yang sudah dikirim`)
            }
            break
    case 'emoji':
            if (!isBanchatt) return
			if (!q) return fakegroup('emojinya?')
			qes = args.join(' ')
			emoji.get(`${qes}`).then(emoji => {
			teks = `${emoji.images[4].url}`
    		sendStickerFromUrl(from,`${teks}`)	
    		console.log(teks)
   			})
    		break
    case 'stickernobg':
    case 'snobg':
                    if (!isBanchatt) return
                    if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
                        const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
                        filePath = await erik.downloadAndSaveMediaMessage(encmedia)
                        file_name = getRandom('.png')
                        file_name2 = getRandom('.webp')
                        request({
                            url: `https://api.lolhuman.xyz/api/removebg?apikey=${LolKey}`,
                            method: 'POST',
                            formData: {
                                "img": fs.createReadStream(filePath)
                            },
                            encoding: "binary"
                        }, function(error, response, body) {
                            fs.unlinkSync(filePath)
                            fs.writeFileSync(file_name, body, "binary")
                            ffmpeg(`./${file_name}`)
                                .input(file_name)
                                .on('error', function(err) {
                                    console.log(err)
                                    fs.unlinkSync(file_name)
                                })
                                .on('end', function() {
                                    erik.sendMessage(from, fs.readFileSync(file_name2), sticker, { quoted: mek })
                                    fs.unlinkSync(file_name2)
                                })
                                .addOutputOptions([`-vcodec`, `libwebp`, `-vf`, `scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
                                .toFormat('webp')
                                .save(file_name2)
                        });
                    } else {
                        reply(`Kirim gambar dengan caption ${prefix}sticker atau tag gambar yang sudah dikirim`)
                    }
                    break
              case 'stickmeme':
              case 'smeme':
                if (!isBanchatt) return
									 var ghs = args.join(' ')

									 if (mek.message.extendedTextMessage != undefined || mek.message.extendedTextMessage != null) {

                                          ger = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo

                                        reply(mess.wait)

					owgi = await erik.downloadAndSaveMediaMessage(ger)

					 fs.writeFileSync(`./stickmeme.jpeg`, owgi)

		         var imgbb = require('imgbb-uploader')

					anu = await imgbb("43fb0405619b40dc0a770f56d106c631", owgi)

										buffer = `https://api.memegen.link/images/custom/_/${ghs}.png?background=${anu.display_url}`

										sendStickerFromUrl(from, buffer)

									 }

									break
			case 'shorny':
							  if (!isBanchatt) return
									 if (mek.message.extendedTextMessage != undefined || mek.message.extendedTextMessage != null) {

                                          ger = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo

                                        reply(mess.wait)

					owgi = await erik.downloadAndSaveMediaMessage(ger)

					 fs.writeFileSync(`./stickerhorny.jpeg`, owgi)

		         var imgbb = require('imgbb-uploader')

					anu = await imgbb("43fb0405619b40dc0a770f56d106c631", owgi)

										buffer = `https://some-random-api.ml//canvas/horny?avatar=${anu.display_url}`

										sendStickerFromUrl(from, buffer)

									 } else {
										reply (`kirim/reply gambar dengan caption ${prefix + command}`)
										}

									break
            
//CONVERT
         case 'enhance':
             if (mek.message.extendedTextMessage != undefined || mek.message.extendedTextMessage != null) {

                                         ger = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo

                                        reply(mess.wait)

					owgi = await erik.downloadAndSaveMediaMessage(ger)

					 fs.writeFileSync(`./ngaha.jpeg`, owgi)

		         var imgbb = require('imgbb-uploader')

					anu = await imgbb("43fb0405619b40dc0a770f56d106c631", owgi)

										buffer = `https://api.lolhuman.xyz/api/upscale?apikey=${LolKey}&img=${anu.display_url}`

										await erik.sendMessage(from, buffer, image)

									 }
									break
                 case 'upscale':
                 if (!q) return
                    ini_buffer = await getBuffer(`https://api.lolhuman.xyz/api/upscale?apikey=${LolKey}&img=${q}`)
                    await erik.sendMessage(from, ini_buffer, image, { quoted: mek })
                    break
    case 'toimg':
    case 'getimage':
            if (!isBanchatt) return
			if (!isQuotedSticker) return reply('Reply Sticker nya!')
			reply(mess.wait)
			encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
			media = await erik.downloadAndSaveMediaMessage(encmedia)
			ran = getRandom('.png')
			exec(`ffmpeg -i ${media} ${ran}`, (err) => {
			fs.unlinkSync(media)
			if (err) return reply('Yah gagal, coba ulangi!')
			buffer = fs.readFileSync(ran)
			fakethumb(buffer,'©Itz.Me/Erick')
			fs.unlinkSync(ran)
			})
			break
    case 'tomp4':
    case 'tovid':
            if (!isBanchatt) return
            if ((isMedia && !mek.message.videoMessage || isQuotedSticker) && args.length == 0) {
            ger = isQuotedSticker ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
            owgi = await erik.downloadAndSaveMediaMessage(ger)
            webp2mp4File(owgi).then(res=>{
            sendMediaURL(from,res.result,'©Itz.Me/Erick')
            })
            }else {
            reply('reply sticker gif')
            }
            fs.unlinkSync(owgi)
            break
      case 'tomp3':
            if (!isBanchatt) return
            if (!isQuotedVideo) return fakegroup('Reply videonya!')
            fakegroup(mess.wait)
            encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
            media = await erik.downloadAndSaveMediaMessage(encmedia)
            ran = getRandom('.mp4')
            exec(`ffmpeg -i ${media} ${ran}`, (err) => {
            fs.unlinkSync(media)
            if (err) return fakegroup(`Err: ${err}`)
            buffer453 = fs.readFileSync(ran)
            erik.sendMessage(from, buffer453, audio, { mimetype: 'audio/mp4', quoted: mek })
            fs.unlinkSync(ran)
            })
            break
      case 'slow':
            if (!isBanchatt) return
            if (!isQuotedVideo) return fakegroup('Reply videonya!')
            fakegroup(mess.wait)
            encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
            media = await erik.downloadAndSaveMediaMessage(encmedia)
            ran = getRandom('.mp4')
            exec(`ffmpeg -i ${media} -filter_complex "[0:v]setpts=2*PTS[v];[0:a]atempo=0.5[a]" -map "[v]" -map "[a]" ${ran}`, (err) => {
            fs.unlinkSync(media)
            if (err) return fakegroup(`Err: ${err}`)
            buffer453 = fs.readFileSync(ran)
            erik.sendMessage(from, buffer453, video, { mimetype: 'video/mp4', quoted: mek })
            fs.unlinkSync(ran)
            })
            break
    case 'reverse':
            if (!isBanchatt) return
            if (!isQuotedVideo) return fakegroup('Reply videonya!')
            encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
            media = await erik.downloadAndSaveMediaMessage(encmedia)
            ran = getRandom('.mp4')
            exec(`ffmpeg -i ${media} -vf reverse -af areverse ${ran}`, (err) => {
            fs.unlinkSync(media)
            if (err) return fakegroup(`Err: ${err}`)
            buffer453 = fs.readFileSync(ran)
            erik.sendMessage(from, buffer453, video, { mimetype: 'video/mp4', quoted: mek })
            fs.unlinkSync(ran)
            })
            break
      case 'fast':
            if (!isBanchatt) return
            if (!isQuotedVideo) return fakegroup('Reply videonya!')
            fakegroup(mess.wait)
            encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
            media = await erik.downloadAndSaveMediaMessage(encmedia)
            ran = getRandom('.mp4')
            exec(`ffmpeg -i ${media} -filter_complex "[0:v]setpts=0.5*PTS[v];[0:a]atempo=2[a]" -map "[v]" -map "[a]" ${ran}`, (err) => {
            fs.unlinkSync(media)
            if (err) return fakegroup(`Err: ${err}`)
            buffer453 = fs.readFileSync(ran)
            erik.sendMessage(from, buffer453, video, { mimetype: 'video/mp4', quoted: mek })
            fs.unlinkSync(ran)
            })
            break
      case 'fdeface':
            if (!isBanchatt) return
            ge = args.join('')           
            var pe = ge.split("|")[0];
            var pen = ge.split("|")[1];
            var pn = ge.split("|")[2];
            var be = ge.split("|")[3];
            const fde = `kirim/reply image dengan capion ${prefix}fdeface link|title|desc|teks`
            if (args.length < 1) return reply (fde)
            const dipes = isQuotedSticker || isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
            const tipes = await erik.downloadAndSaveMediaMessage(dipes)        
            const bufer = fs.readFileSync(tipes)
            const desc = `${pn}`
            const title = `${pen}`
            const url = `${pe}`
            const buu = `https://${be}`
    		var anu = {
        	detectLinks: false
    		}
    		var mat = await erik.generateLinkPreview(url)
    		mat.title = title;
    		mat.description = desc;
    		mat.jpegThumbnail = bufer;
   			mat.canonicalUrl = buu; 
    		erik.sendMessage(from, mat, MessageType.extendedText, anu)
            break
     case 'tourl':
            if (!isBanchatt) return
            if ((isMedia && !mek.message.videoMessage || isQuotedImage || isQuotedVideo ) && args.length == 0) {
            boij = isQuotedImage || isQuotedVideo ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
            owgi = await erik.downloadMediaMessage(boij)
            res = await upload(owgi)
            reply(res)
            } else {
            reply('kirim/reply gambar/video')
            }
            break
        case 'imgtourl':
 if (!isBanchatt) return
var encmedia  = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
var media = await  erik.downloadAndSaveMediaMessage(encmedia)
var imgbb = require('imgbb-uploader')
imgbb('e4bb5222011a8521cc60ce61a2aa1f98', media)
.then(data => {
var caps = `➸ *ID :* ${data.id}\n➸ *MimeType :* ${data.image.mime}\n➸ *Extension :* ${data.image.extension}\n➸ *URL :* ${data.display_url}`
			ibb = fs.readFileSync(media)
erik.sendMessage(from, ibb, image, { quoted: mek, caption: caps })
})
.catch(err => {
throw err 
})
break
case 'tts':
if(!q) return reply(`Example : ${prefix}tts id|Teks lu`)
var tt = q.split("|")[0]
var es = q.split("|")[1]
if (es > 10) return reply('Maksimal 10 kata')
reply(mess.wait)
tts = await getBuffer(`http://zekais-api.herokuapp.com/speech?lang=${tt}&text=${es}`)
erik.sendMessage(from, tts, audio, {mimetype: 'audio/mp4', filename: `${tts}.mp3`, quoted: mek,ptt : true})
break
//FUN

    case 'apakah':
            if (!isBanchatt) return
     	   if (!q) return reply(`pertanyaan nya apa?`)
    	    const apa =['Iya','Tidak','Bisa Jadi','Mungkin','Gak Tau Dah','Mohon Di Ulangi']
            const kah = apa[Math.floor(Math.random() * apa.length)]
    	    erik.sendMessage(from, 'Pertanyaan : *'+q+'*\n\nJawaban : '+ kah, text, { quoted: mek })
    	    break
      case 'kapankah':
            if (!isBanchatt) return
        			if (!q) return reply(`pertanyaan nya apa?`)
        		    const kapan =['Ntar Pas Kiamat','Besok','Lusa','Tadi','4 Hari Lagi','5 Hari Lagi','6 Hari Lagi','1 Minggu Lagi','2 Minggu Lagi','3 Minggu Lagi','1 Bulan Lagi','2 Bulan Lagi','3 Bulan Lagi','4 Bulan Lagi','5 Bulan Lagi','6 Bulan Lagi','1 Tahun Lagi','2 Tahun Lagi','3 Tahun Lagi','4 Tahun Lagi','5 Tahun Lagi','6 Tahun Lagi','1 Abad lagi','3 Hari Lagi','gatau dah']
        			const koh = kapan[Math.floor(Math.random() * kapan.length)]
        		    erik.sendMessage(from, 'Pertanyaan : *'+q+'*\n\nJawaban : '+ koh, text, { quoted: mek })
    				break
   	case 'bisakah':
            if (!isBanchatt) return
        			if (!q) return reply(`pertanyaan nya apa?`)
        		    const bisa =['Tentu Saja Bisa! Kamu Adalah Orang Paling Homky','Gak Bisa Ajg Aowkwowk','Hmm Gua Gak Tau Yaa, tanya ama bapakau','Ulangi Tod Gua Ga Paham']
        			const keh = bisa[Math.floor(Math.random() * bisa.length)]
        		    erik.sendMessage(from, 'Pertanyaan : *'+q+'*\n\nJawaban : '+ keh, text, { quoted: mek })
        			break
        case 'gay':
            if (!isBanchatt) return
     	    gay= body.slice(1)
    	    const g =['0%','10%','20%','%30%','40%','50%','60%','70%','100%']
            const ay = g[Math.floor(Math.random() * g.length)]
    	    erik.sendMessage(from, 'Tingkat kecocokannya Adalah : '+ ay, text, { quoted: mek })
    	    break
         case 'flip':
            if (!isBanchatt) return
            flip = body.slice(1)
	        const fl =['Heads','Tails','Heads','Tails']
            const ip = fl[Math.floor(Math.random() * fl.length)]
	        erik.sendMessage(from, ip, text, { quoted: mek })
            break
    case 'dice':
            if (!isBanchatt) return
            dice = body.slice(1)
            const di =['1','2','3','4','5','6']
            const ce = di[Math.floor(Math.random() * di.length)]
            erik.sendMessage(from, ce, text, { quoted: mek })
            break
     case 'fitnah':
     case 'fakechat':
            if (!isBanchatt) return
            if (args.length < 1) return reply(`Contoh :\n${prefix}fitnah @tagmember|hai|hai juga`)
            var gh = args.join(' ')
            mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
            var replace = gh.split("|")[0];
            var target = gh.split("|")[1];
            var bot = gh.split("|")[2];
            erik.sendMessage(from, ` ${bot}`, text, {quoted: { key: { fromMe: false, participant: `${mentioned}`, ...(from ? { remoteJid: from } : {}) }, message: { conversation: `${target}` }}})
            break
     case 'fitnahpc':
            if (!isBanchatt) return
            if(!q) return reply(`${prefix}fitnahpc teks target|teks lu`)
            jids = `${targetpc}@s.whatsapp.net` // nomer target
            var split = args.join(' ').replace(/@|\d/gi, '').split('|')
            var taged = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
            var options = {contextInfo: {quotedMessage: {extendedTextMessage: {text: split[0]}}}}
            const responye = await erik.sendMessage(jids, `${split[1]}`, MessageType.text, options)
            await erik.deleteMessage(jids, { id: responye.messageID, remoteJid: jids, fromMe: true })
            break
       case 'jodohin':
            if (!isBanchatt) return
if (!isGroup) return reply(mess.only.group)
lope = 'https://i.ibb.co/2gXBp4B/9401b0c64ab7.jpg'
jds = []
const jdii = groupMembers
const koss = groupMembers
const akuu = jdii[Math.floor(Math.random() * jdii.length)]
const diaa = koss[Math.floor(Math.random() * koss.length)]
teks = `Cieee yang baru jadian\n@${akuu.jid.split('@')[0]}\n       ❤️       \n@${diaa.jid.split('@')[0]}`
jds.push(akuu.jid)
jds.push(diaa.jid)
y = await getBuffer(lope)
mentions(teks, jds, true)
break

//******************** 》 GAME 《 ********************\\
case  'tictactoe': case 'ttc':
case 'ttt':
if (!isBanchatt) return
if (!isGroup) return reply(mess.only.group)
if (fs.existsSync(`./lib/tictactoe/db/${from}.json`)) {
const boardnow = setGame(`${from}`);
const matrix = boardnow._matrix;
const chatMove = `T i c t a c t o e  G a m e..
     
Sedang ada sesi permainan digrup ini!!

Info : 
  Player ❎ : @${boardnow.X}
  Player ⭕ : @${boardnow.O}
     

${matrix[0][0]}  ${matrix[0][1]}  ${matrix[0][2]}
${matrix[1][0]}  ${matrix[1][1]}  ${matrix[1][2]}
${matrix[2][0]}  ${matrix[2][1]}  ${matrix[2][2]}
     
Giliran @${boardnow.turn == "X" ? boardnow.X : boardnow.O}
          
Ketik nyerah untuk Menyerah..
Ketik ${prefix}delttc untuk menghapus session Game..`;
erik.sendMessage(from, monospace(chatMove), MessageType.text, {
quoted: mek,
contextInfo: {
mentionedJid: [
  boardnow.X + "@s.whatsapp.net",
  boardnow.O + "@s.whatsapp.net",
  ],
  },
 });
return;
  }
if (argss.length === 1)
return reply(`Tag yang ingin jadi lawan anda!\n\nPenggunaan : *${prefix}tictactoe @TagMember*`
                         );
const boardnow = setGame(`${from}`);
console.log(`Start Tictactore ${boardnow.session}`);
boardnow.status = false;
boardnow.X = sender.replace("@s.whatsapp.net", "");
boardnow.O = argss[1].replace("@", "");
fs.writeFileSync(`./lib/tictactoe/db/${from}.json`,JSON.stringify(boardnow, null, 2));
const strChat = `T i c t a c t o e  G a m e..

@${sender.replace("@s.whatsapp.net","")} menantang ${argss[1]} untuk Menjadi lawan Game!!
     
${argss[1]}  Ketik !Y / !N 

Note : 
  • N : menolak tantangan..
  • Y : Terima tantangan..`;
erik.sendMessage(from, monospace(strChat), MessageType.text, {
quoted: mek,
contextInfo: {
mentionedJid: [sender, argss[1].replace("@", "") + "@s.whatsapp.net"],
 },
});
break
                    
case  'delttc':
case 'delttt':
case 'deltictactoe':
if (!isBanchatt) return
if (!isGroup) return reply(mess.only.group)
if (fs.existsSync("./lib/tictactoe/db/" + from + ".json")) {
fs.unlinkSync("./lib/tictactoe/db/" + from + ".json");
reply(`Berhasil menghapus sesi di grup ini!`);
  } else {
reply(`Tidak ada sesi yg berlangsung, mohon ketik ${prefix}tictactoe`);
  }
break
case 'tebakgambar':{
if (!isGroup) return reply(mess.only.group)
if (game.isTebakGambar(from, tebakgambar)) return reply(`Masih ada soal yang belum di selesaikan`)
let tbg = await axios.get(`https://api.zeks.xyz/api/tebakgambar?apikey=${zeks}`)
const petunjuk = tbg.data.result.jawaban.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi, '_')
sendMediaURL(from, tbg.data.result.soal, monospace(`Silahkan jawab soal berikut ini\n\nPetunjuk : ${petunjuk}\nWaktu : ${gamewaktu}s`), mek)
let anih = tbg.data.result.jawaban.toLowerCase()
game.addgambar(from, anih, gamewaktu, tebakgambar)
	}
break
						
case 'math':{
if (!isGroup) return reply(mess.only.group)
if (game.isMtk(from, mtk)) return reply(`Masih ada soal yang belum di selesaikan`)
if (!q) return reply(`*Mode tersedia :*\n1. very_easy\n2. easy\n3. medium\n4. hard\n5. extreme\n6. impossible\n\n_Example : ${prefix + command} hard_`)
let anu = await axios.get(`http://zekais-api.herokuapp.com/math?mode=${q}`)
//	const petunjuk = anu.data.result.jawaban.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi, '_')
reply(`*Soal :*\n_${anu.data.nilai_1} ${anu.data.tanda} ${anu.data.nilai_2} :_\nWaktu : ${gamewaktu}`)
let anih = anu.data.jawaban.toLowerCase()
game.addmtk(from, anih, gamewaktu, mtk)
	}
break

case 'family100':{
if (!isGroup) return reply(mess.only.group)
if (game.isfam(from, family100)) return reply(`Masih ada soal yang belum di selesaikan`)
let anu = await axios.get(`http://api.lolhuman.xyz/api/tebak/family100?apikey=${LolKey}`)
reply(`*JAWABLAH SOAL BERIKUT*\n\n*Soal :* ${anu.data.result.question}\n*Total Jawaban :* ${anu.data.result.aswer.length}\n\nWaktu : ${gamewaktu}s`)
let anoh = anu.data.result.aswer
let rgfds = []
for (let i of anoh){
let fefs = i.split('/') ? i.split('/')[0] : i
let iuhbb = fefs.startsWith(' ') ? fefs.replace(' ','') : fefs
let axsf = iuhbb.endsWith(' ') ? iuhbb.replace(iuhbb.slice(-1), '') : iuhbb
rgfds.push(axsf.toLowerCase())
  }
game.addfam(from, rgfds, gamewaktu, family100)
  }
break
//GROUP

case 'ping':
if (!isBanchatt) return
if (!mek.key.fromMe && !isGroupAdmins && !isOwner) return reply(mess.only.admin)
if (!isGroup) return reply(mess.only.group)
var nom = erik.participant
members_id = []
	teks = '```pesan: '+q+'```\n\n\n'
	for (let mem of groupMembers){
	teks += `➵ *@${mem.jid.split('@')[0]}*\n`
	members_id.push(mem.jid)
	}
mentions(teks, members_id, true)
break
     case 'ping2':
if (!isBanchatt) return
if (!mek.key.fromMe && !isGroupAdmins && !isOwner) return reply(mess.only.admin)
if(!q) return reply('Ingfonya apa?')
if (!isGroup) return reply(mess.only.group)
var nom = erik.participant
members_id = []
	teks = '\n'
	for (let mem of groupMembers) {
	teks += `┃  *@${mem.jid.split('@')[0]}*\n`
	members_id.push(mem.jid)
	}
mentions(`┏━━━━\n┃\n┃ *Nama Group :* ${groupName}\n┃ *Total Member :* ${groupMembers.length}\n┃ *Info :*  ${q}\n┃\n┗━━━━\n\n┏━━━━\n┃`+teks+'┃\n┗━━━━', members_id, true)
break
case 'wameall':
if (!isBanchatt) return
if (!mek.key.fromMe && !isGroupAdmins && !isOwner) return reply(mess.only.admin)
if (!isGroup) return reply(mess.only.group)
var nom = erik.participant
members_id = []
	teks = `*LIST MEMBER DI GROUP ${groupMetadata.Subject}*\n\n`
	for (let mem of groupMembers){
	teks += `➵ wa.me/${mem.jid.split('@')[0]}\n`
	members_id.push(mem.jid)
	}
mentions(teks, members_id, true)
break
case 'wameall2':
if (!isBanchatt) return
if (!mek.key.fromMe && !isGroupAdmins && !isOwner) return reply(mess.only.admin)
no = 0
member = groupMembers
teks = '*LIST MEMBER*\n\n\n'
for (var i of groupMembers)
{
teks += ` wa.me/${i.jid.split('@')[0]}\n`
}
fakestatus(teks)
break
     case 'listadmins':
	 case 'listadmin':
	 case 'adminlist':
	 case 'adminslist':
	 case 'admin':
                    if (!isBanchatt) return
					if (!isGroup) return reply(mess.only.group)
					teks = `Group *${groupMetadata.subject}*\nTotal : ${groupAdmins.length}\nPesan: ${q}\nMention by: ${pushname}\n\n`
					no = 0
					for (let admon of groupAdmins) {
						no += 1
						teks += `[${no.toString()}] @${admon.split('@')[0]}\n`
					}
					mentions(teks, groupAdmins, true)
					break
     case 'linkgc':
     case 'linkgrouo':
     case 'linkgrup':
     case 'grouplink':
            if (!isBanchatt) return
            if (!isGroup) return reply(mess.only.group)
            if (!isBotGroupAdmins) return reply(mess.only.Badmin)
            linkgc = await erik.groupInviteCode (from)
            yeh = `https://chat.whatsapp.com/${linkgc}\n\nlink Group *${groupName}*`
            erik.sendMessage(from, yeh, text, {quoted: mek})
            break
      case 'resetlink': case 'revokelink': case 'revoke':
if (!mek.key.fromMe && !isGroupAdmins && !isOwner) return reply(mess.only.admin)
if (!isBotGroupAdmins) return reply (mess.only.Badmin)
erik.query({ json: ['action', 'inviteReset', from], expect200: true })
linkgc = await erik.groupInviteCode(from)
reply('Succses Revoke!\n\nLink Group new:\nhttps://chat.whatsapp.com/'+linkgc)
break
      case 'getpic':
            if (!isBanchatt) return
                if (args.length == 0) return reply(`Tag Nomornya!!`)
				if (mek.message.extendedTextMessage != undefined){
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					try {
						pic = await erik.getProfilePicture(mentioned[0])
					} catch {
						pic = 'https://i.ibb.co/Tq7d7TZ/age-hananta-495-photo.png'
					}
					thumb = await getBuffer(pic)
					erik.sendMessage(from, thumb, MessageType.image, {quoted: mek })
				    }
				break
		case 'getbio':
                if (!isBanchatt) return
				if (args.length == 0) return reply(`Tag Nomornya!!`)
                var yy = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
                var p = await erik.getStatus(`${yy}`, MessageType.text)
                reply(p.status)
                if (p.status == 401) {
                reply("Status Profile Not Found")
                }
                break
		case 'close':
               if (!isBanchatt) return
               if (!isGroup) return reply(mess.only.group)
               if (!mek.key.fromMe && !isOwner && !isGroupAdmins) return reply(mess.only.admin)
               if (!isBotGroupAdmins) return reply(mess.only.Badmin)
               if (args[0] === 'false') {
                  reply('```Sukses Membuka Group```')
                  erik.groupSettingChange(from, GroupSettingChange.messageSend, false)
               } else if (args[0] === 'true') {
                  reply('```Sukses Menutup Group```')
                  erik.groupSettingChange(from, GroupSettingChange.messageSend, true)
               }
               break
           case 'open':
               if (!isBanchatt) return
               if (!isGroup) return reply(mess.only.group)
              if (!mek.key.fromMe && !isOwner && !isGroupAdmins) return reply(mess.only.admin)
               if (!isBotGroupAdmins) return reply(mess.only.Badmin)
               if (args[0] === 'true') {
                  reply('```Sukses Membuka Group```')
                  erik.groupSettingChange(from, GroupSettingChange.messageSend, false)
               } else if (args[0] === 'false') {
                  reply('```Sukses Menutup Group```')
                  erik.groupSettingChange(from, GroupSettingChange.messageSend, true)
               }
               break
           case 'added':
           if (!mek.key.fromMe && !isOwner && !isGroupAdmins) return reply(mess.only.admin)
           if (isQuotedMsg && args.length < 2) {
                    erik.groupAdd(from, [quotedMsg.sender])
                    .then((res) => {
                        if (res.participants[0][quotedMsg.sender.split("@")[0] + '@c.us'].code === "403"){
                            let au = res.participants[0][quotedMsg.sender.split("@")[0] + '@c.us']
                            erik.sendGroupInvite(from, quotedMsg.sender, au.invite_code, au.invite_code_exp, groupName, `Join bang`)
                            reply(`Mengirimkan groupInvite kepada nomor tersebut`)
                        } else if (res.participants[0][quotedMsg.sender.split("@")[0] + '@c.us'].code === "408"){
                            reply(`Gagal menambah kan doi dengan alasan: *Dia baru keluar group baru-baru ini*`)
                        } else if (res.participants[0][quotedMsg.sender.split("@")[0] + '@c.us'].code === "401"){
                            reply(`Gagal menambah kan doi dengan alasan: *Bot di block oleh yang bersangkutan*`)
                        } else {
                            reply(jsonformat(res))
                        }
                    })
                    .catch((err) => reply(jsonformat(err)))
                } else if (args.length < 3 && !isNaN(args[1])){
					erik.groupAdd(from, [args[1] + '@s.whatsapp.net'])
					.then((res) => {
                        if (res.participants[0][args[1] + '@c.us'].code === "403"){
                            let au = res.participants[0][args[1] + '@c.us']
                            erik.sendGroupInvite(from, args[1] + '@s.whatsapp.net', au.invite_code, au.invite_code_exp, groupName, `Join bang`)
                            reply(`Mengirimkan groupInvite kepada nomor tersebut`)
                        } else if (res.participants[0][args[1] + '@c.us'].code === "408"){
                            reply(`Gagal menambah kan doi dengan alasan: *Dia baru keluar group baru-baru ini*`)
                        } else if (res.participants[0][args[1] + '@c.us'].code === "401"){
                            reply(`Gagal menambah kan doi dengan alasan: *Bot di block oleh yang bersangkutan*`)
                        } else {
                            reply(jsonformat(res))
                        }
                    })
					.catch((err) => reply(jsonformat(err)))
				} else {
                    reply(`Kirim perintah ${prefix}add nomor atau reply pesan orang yang ingin di add`)
                }
                break
            case 'kicked':
            if (!mek.key.fromMe && !isOwner && !isGroupAdmins) return reply(mess.only.admin)
            if (mentioned.length !== 0){
                    if (mentioned.includes(ownerNumber)) return reply(`Tidak bisa kick Owner`)
                    if (mentioned.includes(from.split("-")[0] + '@s.whatsapp.net')) return reply(`Tidak bisa kick owner group`)
                    erik.groupRemove(from, mentioned)
                    .then((res) => reply(jsonformat(res)))
                    .catch((err) => reply(jsonformat(err)))
                } else if (isQuotedMsg) {
                    if (quotedMsg.sender === ownerNumber) return reply(`Tidak bisa kick Owner`)
                    if (quotedMsg.sender.split("@")[0] === from.split("-")[0]) return reply(`Tidak bisa kick owner group`)
                    erik.groupRemove(from, [quotedMsg.sender])
                    .then((res) => reply(jsonformat(res)))
                    .catch((err) => reply(jsonformat(err)))
                } else if (!isNaN(args[1])) {
                    if (args[1] === ownerNumber.split("@")[0]) return reply(`Tidak bisa kick Owner`)
                    if (args[1] === from.split("-")[0]) return reply(`Tidak bisa kick owner group`)
                    erik.groupRemove(from, [args[1] + '@s.whatsapp.net'])
                    .then((res) => reply(jsonformat(res)))
                    .catch((err) => reply(jsonformat(err)))
                } else {
                    reply(`Kirim perintah ${prefix}kick @tag atau nomor atau reply pesan orang yang ingin di kick`)
                }
                break
           case 'promote':
               if (!isBanchatt) return
               if (!isGroup) return reply(mess.only.group);
               if (!mek.key.fromMe && !isOwner && !isGroupAdmins) return reply(mess.only.admin)
               if (!isBotGroupAdmins) return reply(mess.only.Badmin);
               if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('Tag target yang ingin di jadi admin!');
               mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid;
               if (mentioned.length > 1) {
                  teks = 'Perintah di terima, anda menjdi admin :\n';
                  for (let _ of mentioned) {
                     teks += `@${_.split('@')[0]}\n`;
                  }
                  mentions(teks, mentioned, true);
                  erik.groupMakeAdmin(from, mentioned);
               } else {
                  mentions(`Perintah di terima, @${mentioned[0].split('@')[0]} Kamu Menjadi Admin Di Group *${groupMetadata.subject}*`, mentioned, true);
                  erik.groupMakeAdmin(from, mentioned);
               }
               break;
            case 'delete':
            case 'del':
            case 'd':
               if (!isBanchatt) return
               if (!isGroup) return reply(mess.only.group)
               if (!mek.key.fromMe && !isOwner) return
               erik.deleteMessage(from, { id: mek.message.extendedTextMessage.contextInfo.stanzaId, remoteJid: from, fromMe: true })
               break;
               case 'dm':
               if (!mek.key.fromMe && !isOwner && !isGroupAdmins) return reply(mess.only.admin)
             if (mentioned.length !== 0){
                    erik.groupDemoteAdmin(from, mentioned)
                    .then((res) => reply(jsonformat(res)))
                    .catch((err) => reply(jsonformat(err)))
                } else if (isQuotedMsg) {
                    if (quotedMsg.sender === ownerNumber) return reply(`Tidak bisa kick Owner`)
                    erik.groupDemoteAdmin(from, [quotedMsg.sender])
                    .then((res) => reply(jsonformat(res)))
                    .catch((err) => reply(jsonformat(err)))
                } else if (!isNaN(args[1])) {
                    erik.groupDemoteAdmin(from, [args[1] + '@s.whatsapp.net'])
                    .then((res) => reply(jsonformat(res)))
                    .catch((err) => reply(jsonformat(err)))
                } else {
                    reply(`Kirim perintah ${prefix}demote @tag atau nomor atau reply pesan orang yang ingin di demote`)
                }
                break
            case 'demote':
               if (!isBanchatt) return
               if (!isGroup) return reply(mess.only.group)
               if (!mek.key.fromMe && !isOwner && !isGroupAdmins) return reply(mess.only.admin)
               if (!isBotGroupAdmins) return reply(mess.only.Badmin)
               if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('Tag target yang ingin di tidak jadi admin!')
               mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid;
               if (mentioned.length > 1) {
                  teks = 'Perintah di terima, anda tidak menjadi admin :\n'
                  for (let _ of mentioned) {
                     teks += `@${_.split('@')[0]}\n`
                  }
                  mentions(teks, mentioned, true);
                  erik.groupDemoteAdmin(from, mentioned)
               } else {
                  mentions(`Perintah di terima, Menurunkan : @${mentioned[0].split('@')[0]} Menjadi Member`, mentioned, true)
                  erik.groupDemoteAdmin(from, mentioned)
               }
               break
           case 'closetime':
            if (!isBanchatt) return
               if (!isGroup) return reply(mess.only.group);
               if (!mek.key.fromMe && !isOwner && !isGroupAdmins) return reply(mess.only.admin)
               if (!isBotGroupAdmins) return reply(mess.only.Badmin);
               erik.updatePresence(from, Presence.composing);
               if (args[1] == 'detik') {
                  var timer = args[0] + '000';
               } else if (args[1] == 'menit') {
                  var timer = args[0] + '0000';
               } else if (args[1] == 'jam') {
                  var timer = args[0] + '00000';
               } else {
                  return reply('*pilih:*\ndetik\nmenit\njam\n\n*contoh*\n10 detik');
               }
               setTimeout(() => {
                  var nomor = mek.participant;
                  const close = {
                     text: `*Grup telah ditutup, saat ini hanya admin yang dapat mengirim pesan*`,
                     contextInfo: { mentionedJid: [nomor] },
                  };
                  erik.groupSettingChange(from, GroupSettingChange.messageSend, true);
                  reply(close);
               }, timer);
               break;
          case 'opentime':
            if (!isBanchatt) return
               if (!isGroup) return reply(mess.only.group);
               if (!mek.key.fromMe && !isOwner && !isGroupAdmins) return reply(mess.only.admin)
               if (!isBotGroupAdmins) return reply(mess.only.Badmin);
               erik.updatePresence(from, Presence.composing);
               if (args[1] == 'detik') {
                  var timer = args[0] + '000';
               } else if (args[1] == 'menit') {
                  var timer = args[0] + '0000';
               } else if (args[1] == 'jam') {
                  var timer = args[0] + '00000';
               } else {
                  return reply('*pilih:*\ndetik\nmenit\njam\n\n*contoh*\n10 detik');
               }
               setTimeout(() => {
                  var nomor = mek.participant;
                  const open = {
                     text: `*Grup telah dibuka, saat ini semua peserta dapat mengirim pesan*`,
                     contextInfo: { mentionedJid: [nomor] },
                  };
                  erik.groupSettingChange(from, GroupSettingChange.messageSend, false);
                  reply(open);
               }, timer);
               break;
           case 'setname':
            if (!isBanchatt) return
               if (!isGroup) return reply(mess.only.group);
               if (!mek.key.fromMe && !isOwner && !isGroupAdmins) return reply(mess.only.admin)
               if (!isBotGroupAdmins) return reply(mess.only.Badmin);
               erik.groupUpdateSubject(from, `${body.slice(9)}`);
               erik.sendMessage(from, `\`\`\`✔Sukses Mengganti Nama Group Menjadi\`\`\` *${body.slice(9)}*`, text, { quoted: mek });
               break;
            case 'setdesc':
            if (!isBanchatt) return
               if (!isGroup) return reply(mess.only.group);
               if (!mek.key.fromMe && !isOwner && !isGroupAdmins) return reply(mess.only.admin)
               if (!isBotGroupAdmins) return reply(mess.only.Badmin);
               erik.groupUpdateDescription(from, `${body.slice(9)}`);
               erik.sendMessage(from, `\`\`\`✔Sukses Mengganti Deskripsi Group\`\`\` *${groupMetadata.subject}* Menjadi: *${body.slice(9)}*`, text, { quoted: mek });
               break;
           case 'add':
            if (!isBanchatt) return
               if (!isGroup) return reply(mess.only.group);
               if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
               if (!isBotGroupAdmins) return reply(mess.only.Badmin);
               if (args.length < 1) return reply('Yang mau di add siapa??');
               if (args[0].startsWith('08')) return reply('Gunakan kode negara Gan');
               try {
                  num = `${args[0].replace(/ /g, '')}@s.whatsapp.net`;
                  erik.groupAdd(from, [num]);
               } catch (e) {
                  console.log('Error :', e);
                  reply('Gagal menambahkan target, mungkin karena di private');
               }
               break;
            case 'kick':
            if (!isBanchatt) return
               if (!isGroup) return reply(mess.only.group);
               if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
               if (!isBotGroupAdmins) return reply(mess.only.Badmin);
               if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('Tag target yang ingin di tendang!');
               mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid;
               if (mentioned.length > 1) {
                  teks = 'Perintah di terima, mengeluarkan :\n';
                  for (let _ of mentioned) {
                     teks += `@${_.split('@')[0]}\n`;
                  }
                  mentions(teks, mentioned, false);
                  erik.groupRemove(from, mentioned);
               } else {
                  mentions(`Perintah di terima, mengeluarkan : @${mentioned[0].split('@')[0]}`, mentioned, true);
                  erik.groupRemove(from, mentioned);
               }
               break
            case 'kicktime':
            if (!isBanchatt) return
               if (!isGroup) return reply(mess.only.group);
               if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
               if (!isBotGroupAdmins) return reply(mess.only.Badmin);
               if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('Tag target yang ingin di tendang!');
               mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid;
               setTimeout(() => {
                  erik.sendMessage(from, 'Yok Sama Al-fatihah', text);
               }, 8000);
               setTimeout(() => {
                  reply('sukses min:D');
               }, 7000);
               setTimeout(() => {
                  erik.groupRemove(from, mentioned);
               }, 6000);
               setTimeout(() => {
                  erik.sendMessage(from, `Bismilah Kick @${mentioned[0].split('@')[0]}`, text); // ur cods
               }, 5000);
               setTimeout(() => {
                  erik.sendMessage(from, '.', text);
               }, 2500);
               setTimeout(() => {
                  reply('Perintah Diterima');
               }, 0);
               break
        case 'infogc':
            case 'groupinfo':
            case 'infogrup':
            case 'grupinfo':
            case 'info':
            case 'infogroup':
               erik.updatePresence(from, Presence.composing);
               if (!isGroup) return reply(mess.only.group);
               try {
                  ppUrl = await erik.getProfilePicture(from);
               } catch {
                  ppUrl = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg';
               }
               buffer = await getBuffer(ppUrl);
               erik.sendMessage(from, buffer, image, { quoted: mek, caption: `➵ *Nama Group:* ${groupMetadata.subject}\n\n➵ *Total Member* ${groupMembers.length}\n\n➵ *Total Admin:* ${groupAdmins.length}\n\n➵ *Regist*: ${isBanchatt ? 'true' : 'false'}\n\n➵ *Nsfw:* ${isNsfw ? 'true' : 'false'}\n\n➵ *Simi:* ${isSimi ? 'true' : 'false'}\n\n➵ *DESK* :\n ${groupDesc}` });
               break;
           case 'profile':
              erik.updatePresence(from, Presence.composing)
              try {
              profil = await erik.getProfilePicture(`${sender.split('@')[0]}@s.whatsapp.net`)
              } catch {
              profil = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png'
}
              thu = await erik.getStatus(`${sender.split('@')[0]}@s.whatsapp.net`, MessageType.text)
              me = erik.user
              uptime = process.uptime()
              profile = 
`-------[ *USER INFO* ]-------

➸ *Username:* ${pushname}
https://wa.me/${sender.split("@")[0]}

➸ *Status:* ${thu.status}

➸ *Admin*: ${isGroupAdmins ? 'True' : 'False'}

➸ *Owner*: ${isOwner ? 'True' : 'False'}`
              buff = await getBuffer(profil)
              erik.sendMessage(from, buff, image, {caption: profile, contextInfo :{text: 'hi',
"forwardingScore": 1000000000,
isForwarded: true,
sendEphemeral: true,
"externalAdReply": {
                "title": `${ucapanWaktu} 👋 ${pushname}`,
                "body": "",
                "previewType": "image/jpeg",
                "thumbnailUrl": ``,
                "thumbnail": fs.readFileSync('./stik/textimg.jpeg'),
                "sourceUrl": ``
},mentionedJid:[sender]},quoted:mek})
              break
            case 'demoteall':
            case 'da':
            if (!isBanchatt) return
                if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
                if (!isGroup) return reply(mess.only.group);
                members_id = []
		for (let mem of groupMembers) {
	   	members_id.push(mem.jid)
	  	}
                erik.groupDemoteAdmin(from, members_id)
                break
          case 'tagme':
            if (!isBanchatt) return
                mentions(`@${sender.split("@")[0]}`, [sender], true)
                break
           case 'wame':
            if (!isBanchatt) return
                mentions(`https://wa.me/${sender.split("@")[0]}`, [sender], true)
                break
          case 'spamtagme':
              if (!isBanchatt) return
                if (!mek.key.fromMe && !isOwner && !isGroupAdmins) return reply(mess.only.admin)
                ye = args.join(' ') 
             for(let i=0;i<`${ye}`;i++){
             mentions(`@${sender.split("@")[0]}`, [sender], true)
             }
             break
          case 'spamtag':
              if (!isBanchatt) return
                if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
                kls = args.join(' ') 
                var oi = kls.split('|')[0];
                var ye = kls.split('|')[1];
                var nom = erik.participant
                members_id = []
                teks = '```pesan: '+q+'```\n\n\n'
	            for (let mem of groupMembers){
                teks = `${oi}\n\n`
                members_id.push(mem.jid)
	            }
             for(let i=0;i<`${ye}`;i++){
             mentions(teks, members_id, true)
             }
             break
        case 'delvote':
            if (!isBanchatt) return
            if(!mek.key.remoteJid) return
            if(isVote) return reply('Tidak ada sesi Voting')
            delVote(from)
            reply('Sukses Menghapus sesi Voting Di Grup Ini')
            break
    case 'voting':
            if (!isBanchatt) return
            if(!isGroupAdmins && !mek.key.fromMe) return 
            if(!isGroup) return reply(mess.only.group)
            if (isVote) return reply('Sesi Voting Sedang Berlangsung Di Grup Ini')
            if(!q) return reply('*Voting*\n\n'+ prefix+ 'voting @tag target | reason  | 1 (1 = 1 Menit)')
            if (mek.message.extendedTextMessage.contextInfo.mentionedJid.length > 0 || mek.message.extendedTextMessage.contextInfo == null) {
            let id = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
            split = args.join(' ').replace('@', '').split('|')
            if(!Number(split[2])) return reply('masukan angka di baris ke 3\nContoh: 1-9999\n1 = 1 Menit')
            await mentions('Vote ' +'@'+ id.split('@')[0]+' Di Mulai' +'\n\n' + `vote = ✅\ndevote = ❌\n\nAlasan: ${split[1]}`,[id],true)
            addVote(from,split[1],split[0],split[2],reply)
            } 
            break
case 'mention':
            if (!isBanchatt) return
if(!q)return reply('nomernya?')
mentions(`@${q.split("@")[0]}`, [`${q}@s.whatsapp.net`], false)
break

//ANIMANGA
     case 'character':
                case 'char':
                    if (!isBanchatt) return
                    if (args.length == 0) return reply(`Masukan Nama Characternya!\nContoh: ${prefix + command} Oshino Shinobu`)
                    try {
                    query = args.join(" ")
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/character?apikey=${LolKey}&query=${query}`)
                    get_result = get_result.result
                    ini_txt = `➵ Id : ${get_result.id}\n`
                    ini_txt += `➵ Name : ${get_result.name.full}\n`
                    ini_txt += `➵ Native : ${get_result.name.native}\n`
                    ini_txt += `➵ Favorites : ${get_result.favourites}\n`
                    ini_txt += `➵ Media : \n`
                    ini_media = get_result.media.nodes
                    for (var x of ini_media) {
                        ini_txt += `- ${x.title.romaji} (${x.title.native})\n`
                    }
                    ini_txt += `\nDescription : \n${get_result.description.replace(/__/g, "_")}`
                    thumbnail = await getBuffer(get_result.image.large)
                    await erik.sendMessage(from, thumbnail, image, { quoted: mek, caption: ini_txt })
                    } catch (err) {
				notfound(`Maaf *${pushname}*, Character *${query}* tidak ditemukan`)
                    }
                    break
                 case 'anime':
                    try{
                    if (!isBanchatt) return
                    if (args.length == 0) return reply(`Masukan Nama Animenya!\nContoh: ${prefix + command} Gotoubun No Hanayome`)
                    query = args.join(" ")
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/anime?apikey=${LolKey}&query=${query}`)
                    get_result = get_result.result
                    ini_txt = `➵ Id : ${get_result.id}\n`
                    ini_txt += `➵ Id MAL : ${get_result.idMal}\n`
                    ini_txt += `➵ Title : ${get_result.title.romaji}\n`
                    ini_txt += `➵ English : ${get_result.title.english}\n`
                    ini_txt += `➵ Native : ${get_result.title.native}\n`
                    ini_txt += `➵ Format : ${get_result.format}\n`
                    ini_txt += `➵ Episodes : ${get_result.episodes}\n`
                    ini_txt += `➵ Duration : ${get_result.duration} mins.\n`
                    ini_txt += `➵ Status : ${get_result.status}\n`
                    ini_txt += `➵ Season : ${get_result.season}\n`
                    ini_txt += `➵ Season Year : ${get_result.seasonYear}\n`
                    ini_txt += `➵ Source : ${get_result.source}\n`
                    ini_txt += `➵ Start Date : ${get_result.startDate.day} - ${get_result.startDate.month} - ${get_result.startDate.year}\n`
                    ini_txt += `➵ End Date : ${get_result.endDate.day} - ${get_result.endDate.month} - ${get_result.endDate.year}\n`
                    ini_txt += `➵ Genre : ${get_result.genres.join(", ")}\n`
                    ini_txt += `➵ Synonyms : ${get_result.synonyms.join(", ")}\n`
                    ini_txt += `➵ Score : ${get_result.averageScore}%\n`
                    ini_txt += `➵ Characters : \n`
                    ini_character = get_result.characters.nodes
                    for (var x of ini_character) {
                        ini_txt += `- ${x.name.full} (${x.name.native})\n`
                    }
                    ini_txt += `\nDescription : ${get_result.description}`
                    thumbnail = await getBuffer(get_result.coverImage.large)
                    await erik.sendMessage(from, thumbnail, image, { quoted: mek, caption: ini_txt })
                    } catch (err) {
				  notfound(`Maaf ${pushname}, Anime ${query} tidak ditemukan`)
                    }
                    break
           case 'manga':
                    try{
                    if (!isBanchatt) return
                    if (args.length == 0) return reply(`Masukan Nama MangaNya!\nContoh: ${prefix + command} Dororo`)
                    query = args.join(" ")
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/manga?apikey=${LolKey}&query=${query}`)
                    get_result = get_result.result
                    ini_txt = `➵ Id : ${get_result.id}\n`
                    ini_txt += `➵ Id MAL : ${get_result.idMal}\n`
                    ini_txt += `➵ Title : ${get_result.title.romaji}\n`
                    ini_txt += `➵ English : ${get_result.title.english}\n`
                    ini_txt += `➵ Native : ${get_result.title.native}\n`
                    ini_txt += `➵ Format : ${get_result.format}\n`
                    ini_txt += `➵ Chapters : ${get_result.chapters}\n`
                    ini_txt += `➵ Volume : ${get_result.volumes}\n`
                    ini_txt += `➵ Status : ${get_result.status}\n`
                    ini_txt += `➵ Source : ${get_result.source}\n`
                    ini_txt += `➵ Start Date : ${get_result.startDate.day} - ${get_result.startDate.month} - ${get_result.startDate.year}\n`
                    ini_txt += `➵ End Date : ${get_result.endDate.day} - ${get_result.endDate.month} - ${get_result.endDate.year}\n`
                    ini_txt += `➵ Genre : ${get_result.genres.join(", ")}\n`
                    ini_txt += `➵ Synonyms : ${get_result.synonyms.join(", ")}\n`
                    ini_txt += `➵ Score : ${get_result.averageScore}%\n`
                    ini_txt += `➵ Characters : \n`
                    ini_character = get_result.characters.nodes
                    for (var x of ini_character) {
                        ini_txt += `- ${x.name.full} (${x.name.native})\n`
                    }
                    ini_txt += `\nDescription : ${get_result.description}`
                    thumbnail = await getBuffer(get_result.coverImage.large)
                    await erik.sendMessage(from, thumbnail, image, { quoted: mek, caption: ini_txt })
                    } catch (err) {
				notfound(`Maaf *${pushname}*, Manga *${query}* tidak ditemukan`)
                    }
                    break
                case 'otakudesubatch':
                case 'batchotakudesu':
                case 'otakubatch':
                if (!isBanchatt) return
if(!q) return reply(`Nama Anime nya apa?`)
             let anime = await hx.otakudesu(q)
            rem = `*Judul* : ${anime.judul}
*Jepang* : ${anime.jepang}
*Rating* : ${anime.rate}
*Produser* : ${anime.produser}
*Status* : ${anime.status}
*Episode* : ${anime.episode}
*Durasi* : ${anime.durasi}
*Rilis* : ${anime.rilis}
*Studio* : ${anime.studio}
*Genre* : ${anime.genre}\n
*Sinopsis* :
${anime.desc}\n\n*Link Batch* : ${anime.batch}\n*Link Download SD* : ${anime.batchSD}\n*Link Download HD* : ${anime.batchHD}`
            ram = await getBuffer(anime.img)
            erik.sendMessage(from,ram,image,{quoted:mek,caption:rem})
            break
                case 'otakudesu':
                    if (!isBanchatt) return
                    if (args.length == 0) return reply(`Masukan Nama Animenya!\nContoh: ${prefix + command} Sword Art Online`)
                    query = args.join(" ")
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/otakudesusearch?apikey=${LolKey}&query=${query}`)
                    get_result = get_result.result
                    ini_txt = `➵ Title : ${get_result.title}\n`
                    ini_txt += `➵ Japanese : ${get_result.japanese}\n`
                    ini_txt += `➵ Judul : ${get_result.judul}\n`
                    ini_txt += `➵ Type : ${get_result.type}\n`
                    ini_txt += `➵ Episode : ${get_result.episodes}\n`
                    ini_txt += `➵ Aired : ${get_result.aired}\n`
                    ini_txt += `➵ Producers : ${get_result.producers}\n`
                    ini_txt += `➵ Genre : ${get_result.genres}\n`
                    ini_txt += `➵ Duration : ${get_result.duration}\n`
                    ini_txt += `➵ Studios : ${get_result.status}\n`
                    ini_txt += `➵ Rating : ${get_result.rating}\n`
                    ini_txt += `➵ Credit : ${get_result.credit}\n`
                    get_link = get_result.link_dl
                    for (var x in get_link) {
                        ini_txt += `\n\n*${get_link[x].title}*\n`
                        for (var y in get_link[x].link_dl) {
                            ini_info = get_link[x].link_dl[y]
                            ini_txt += `\n\`\`\`Reso : \`\`\`${ini_info.reso}\n`
                            ini_txt += `\`\`\`Size : \`\`\`${ini_info.size}\n`
                            ini_txt += `\`\`\`Link : \`\`\`\n`
                            down_link = ini_info.link_dl
                            for (var z in down_link) {
                                ini_txt += `${z} - ${down_link[z]}\n`
                            }
                        }
                    }
                    fakelink(ini_txt)
                    break
     case 'wait':
                    if (!isBanchatt) return
                    if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
                        const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : mek
                        const filePath = await erik.downloadAndSaveMediaMessage(encmedia, filename = getRandom());
                        const form = new FormData();
                        const stats = fs.statSync(filePath);
                        const fileSizeInBytes = stats.size;
                        const fileStream = fs.createReadStream(filePath);
                        form.append('img', fileStream, { knownLength: fileSizeInBytes });
                        const options = {
                            method: 'POST',
                            credentials: 'include',
                            body: form
                        }
                        get_result = await fetchJson(`https://api.lolhuman.xyz/api/wait?apikey=${LolKey}`, {...options })
                        fs.unlinkSync(filePath)
                        get_result = get_result.result
                        ini_video = await getBuffer(get_result.video)
                        ini_txt = `Anilist id : ${get_result.anilist_id}\n`
                        ini_txt += `MAL id : ${get_result.mal_id}\n`
                        ini_txt += `Title Romaji : ${get_result.title_romaji}\n`
                        ini_txt += `Title Native : ${get_result.title_native}\n`
                        ini_txt += `Title English : ${get_result.title_english}\n`
                        ini_txt += `at : ${get_result.at}\n`
                        ini_txt += `Episode : ${get_result.episode}\n`
                        ini_txt += `Similarity : ${get_result.similarity}`
                        await erik.sendMessage(from, ini_video, video, { quoted: mek, caption: ini_txt })
                    } else {
                        reply(`Kirim gambar dengan caption ${prefix + command} atau tag gambar yang sudah dikirim`)
                    }
                    break
     case 'quotes':
     case 'quote':
                    if (!isBanchatt) return
                    quotes = await fetchJson(`https://api.lolhuman.xyz/api/random/quotesnime?apikey=${LolKey}`)
                    quotes = quotes.result
                    quote = quotes.quote
                    char = quotes.character
                    anime = quotes.anime
                    episode = quotes.episode
                    textImg(`_${quote}_\n\n➵ *Character: ${char}*\n➵ *Anime: ${anime}*\n➵ *${episode}*`)
                    break
              case 'otakulast':
                        if (!isBanchatt) return
						anu = await fetchJson(`https://api.vhtear.com/otakulatest&apikey=${VhKey}`, {method: 'get'})
						if (anu.error) return reply(anu.error)
						teks = '=================\n\n'
						for (let i of anu.result.data) {
							teks += `*Title* : ${i.title}\n*Link* : ${i.link}\n*Published* : ${i.datetime}\n\n=================\n\n`
						}
						fakelink(teks.trim())
						break
			case 'ppcouple':
			case 'coupleanime':
			case 'animecouple':
			        if (!isBanchatt) return
			        if (args.length < 1) return reply(`Pilih tipe doc atau image\n\nContoh:\n${prefix}ppcouple image\n${prefix}ppcouple doc`)
			        if (args[0] === 'image') {
	                anu = await fetchJson(`https://leyscoders-api.herokuapp.com/api/ppcouple?apikey=dappakntlll`)
					cwokk = await getBuffer(anu.result.male)
					cwekk = await getBuffer(anu.result.female)
					erik.sendMessage(from, cwekk, image, { caption: 'ppcp (cewek)', quoted: mek })
					erik.sendMessage(from, cwokk, image, { caption: 'ppcp (cowok)', quoted: mek })
					} else if (args[0] === 'doc') {
                   anu = await fetchJson(`https://leyscoders-api.herokuapp.com/api/ppcouple?apikey=dappakntlll`)
					cwokk = await getBuffer(anu.result.male)
					cwekk = await getBuffer(anu.result.female)
					erik.sendMessage(from, cwekk,  document, {quoted: mek, mimetype:'image/jpeg', filename:`ppcp (cewek).jpeg`})
					erik.sendMessage(from, cwokk, document, {quoted: mek, mimetype:'image/jpeg', filename:`ppcp (cowok).jpeg`})
					}
					break
			case 'loli':
                  if (!isBanchatt) return
                  if (!isGroup) return reply(mess.only.group);
                  try {
                  res = await fetchJson(`https://api.vhtear.com/randomloli&apikey=${VhKey}`, { method: 'get' });
                  buffer = await getBuffer(res.result.result);
                  erik.sendMessage(from, buffer, image, { quoted: mek, caption: 'FBI!!' });
                  } catch (err) {
                   notfound('gagal, coba ulangi lagi')
                   }
               break
         case 'neko':
                  if (!isBanchatt) return
                  if (!isGroup) return reply(mess.only.group);
                  try {
                  res = await fetchJson(`https://api.vhtear.com/randomnekonime&apikey=${VhKey}`, { method: 'get' });
                  buffer = await getBuffer(res.result.result);
                  erik.sendMessage(from, buffer, image, { quoted: mek, caption: 'Nyaa' });
                  } catch (err) {
                   notfound('gagal, coba ulangi lagi')
                   }
               break
               case 'pictnime':
                  if (!isBanchatt) return
                  if (!isGroup) return reply(mess.only.group);
                  try {
                  res = await fetchJson(`https://api.vhtear.com/randomwibu&apikey=${VhKey}`, { method: 'get' });
                  buffer = await getBuffer(res.result.result);
                  erik.sendMessage(from, buffer, image, { quoted: mek, caption: 'Pict Anime nu tuan' });
                  } catch (err) {
                   notfound('gagal, coba ulangi lagi')
                   }
               break
     case 'waifu':
            if (!isBanchatt) return
            reply(mess.dl)
            fetch('https://raw.githubusercontent.com/pajaar/grabbed-results/master/pajaar-2020-gambar-anime.txt')
            .then(res => res.text())
            .then(body => {
            let tod = body.split("\n");
            let pjr = tod[Math.floor(Math.random() * tod.length)];
            imageToBase64(pjr)
            .then((response) => {
            media =  Buffer.from(response, 'base64');
            erik.sendMessage(from,media,image,{quoted:mek,caption:'NIH'})
            }
            )
            .catch((error) => {
            console.log(error); 
            }
            )
            });
            break
	case 'wallpaperanime':
	case 'wallanime':
	case 'wpanime':
            if (!isBanchatt) return
	  try {
	 v2 = await getBuffer(`https://api.lolhuman.xyz/api/random/wallnime?apikey=${LolKey}`)
mhan2 = await erik.prepareMessage(from, v2, image)
gbutsan = [
  {buttonId: `${prefix}wpanime`, buttonText: {displayText: 'NEXT'}, type: 1}
]

 gbuttonan = {
imageMessage : mhan2.message.imageMessage,
    contentText: `Click Next untuk pencarian Wallpaper Anime selanjutnya`,
    footerText: 'ItzMeErick',
    buttons: gbutsan,
    headerType: 4
}
await erik.sendMessage(from, gbuttonan, MessageType.buttonsMessage, {
			quoted: mek})
		} catch (err) {
			notfound('gagal, coba ulangi lagi')
			}
		break
case 'imageanime':
case 'charimg':
if (!isBanchatt) return
if(!q) return reply(`Nama Character nya apa?`)
try{
let im = await hx.chara(q)
            let acak = im[Math.floor(Math.random() * im.length)]
            let li = await getBuffer(acak)
            await erik.sendMessage(from,li,image,{quoted: mek})
} catch (err) {
notfound(`Maaf ${pushname}, Character ${q} Tidak Ditemukan`)
}
break
case 'fetish':
                let request = args.join(' ')
                if (!request) return reply(from, '?? Silakan masukkan tag yang tersedia di *!tutor*!')
    
                if (request === 'armpits') {
                    fetish.armpits()
                        .then(({subreddit, title, url, author}) => {
                            erik.sendFileFromUrl(from, `${url}`, 'fetish.jpg', `${title}\nTag: r/${subreddit}\nAuthor: u/${author}`, null, null, true)
                        }, id)
                        .catch((err) => console.error(err))
                } else if (request === 'feets') {
                    fetish.feets()
                        .then(({subreddit, title, url, author}) => {
                            erik.sendFileFromUrl(from, `${url}`, 'fetish.jpg', `${title}\nTag: r/${subreddit}\nAuthor: u/${author}`, null, null, true)
                        }, id)
                        .catch((err) => console.error(err))
                } else if (request === 'thighs') {
                    fetish.thighs()
                        .then(({subreddit, title, url, author}) => {
                            erik.sendFileFromUrl(from, `${url}`, 'fetish.jpg', `${title}\nTag: r/${subreddit}\nAuthor: u/${author}`, null, null, true)
                        }, id)
                        .catch((err) => console.error(err))
                } else if (request === 'booty') {
                    fetish.booty()
                        .then(({subreddit, title, url, author}) => {
                            erik.sendFileFromUrl(from, `${url}`, 'fetish.jpg', `${title}\nTag: r/${subreddit}\nAuthor: u/${author}`, null, null, true)
                        }, id)
                        .catch((err) => console.error(err))
                } else if (request === 'boobs') {
                    fetish.boobs()
                        .then(({subreddit, title, url, author}) => {
                            erik.sendFileFromUrl(from, `${url}`, 'fetish.jpg', `${title}\nTag: r/${subreddit}\nAuthor: u/${author}`, null, null, true)
                        }, id)
                        .catch((err) => console.error(err))
                } else if (request === 'necks') {
                    fetish.necks()
                        .then(({subreddit, title, url, author}) => {
                            erik.sendFileFromUrl(from, `${url}`, 'fetish.jpg', `${title}\nTag: r/${subreddit}\nAuthor: u/${author}`, null, null, true)
                        }, id)
                        .catch((err) => console.error(err))
                } else if (request === 'belly') {
                    fetish.belly()
                        .then(({subreddit, title, url, author}) => {
                            erik.sendFileFromUrl(from, `${url}`, 'fetish.jpg', `${title}\nTag: r/${subreddit}\nAuthor: u/${author}`, null, null, true)
                        }, id)
                        .catch((err) => console.error(err))
                } else if (request === 'sideboobs') {
                    fetish.sideboobs()
                        .then(({subreddit, title, url, author}) => {
                            erik.sendFileFromUrl(from, `${url}`, 'fetish.jpg', `${title}\nTag: r/${subreddit}\nAuthor: u/${author}`, null, null, true)
                        }, id)
                        .catch((err) => console.error(err))
                } else if (request === 'ahegao') {
                    fetish.ahegao()
                        .then(({subreddit, title, url, author}) => {
                            erik.sendFileFromUrl(from, `${url}`, 'fetish.jpg', `${title}\nTag: r/${subreddit}\nAuthor: u/${author}`, null, null, true)
                        }, id)
                        .catch((err) => console.error(err))
                } else {
                    reply(from, '?? Maaf tag belum tersedia. Silakan lihat tag yang tersedia di *!tutor*')
                }
            break
//ISLAM

            case 'listsurah':
            if (!isBanchatt) return
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/quran?apikey=${LolKey}`)
                    get_result = get_result.result
                    ini_txt = 'List Surah:\n'
                    for (var x in get_result) {
                        ini_txt += `${x}. ${get_result[x]}\n`
                    }
                    fakelink(ini_txt)
                    break
                case 'alquran':
            if (!isBanchatt) return
                    if (args.length < 1) return reply(`Contoh: ${prefix + command} 18 or ${prefix + command} 18/10 or ${prefix + command} 18/1-10`)
                    urls = `https://api.lolhuman.xyz/api/quran/${args[0]}?apikey=${LolKey}`
                    quran = await fetchJson(urls)
                    result = quran.result
                    ayat = result.ayat
                    ini_txt = `QS. ${result.surah} : 1-${ayat.length}\n\n`
                    for (var x of ayat) {
                        arab = x.arab
                        nomor = x.ayat
                        latin = x.latin
                        indo = x.indonesia
                        ini_txt += `${arab}\n${nomor}. ${latin}\n${indo}\n\n`
                    }
                    ini_txt = ini_txt.replace(/<u>/g, "").replace(/<\/u>/g, "")
                    ini_txt = ini_txt.replace(/<strong>/g, "").replace(/<\/strong>/g, "")
                    ini_txt = ini_txt.replace(/<u>/g, "").replace(/<\/u>/g, "")
                    fakelink(ini_txt)
                    break
                case 'alquranaudio':
            if (!isBanchatt) return
                    if (args.length == 0) return reply(`Contoh: ${prefix + command} 18 \nAtau\n ${prefix + command} 18/10`)
                    surah = args[0]
                    ini_buffer = await getBuffer(`https://api.lolhuman.xyz/api/quran/audio/${surah}?apikey=${LolKey}`)
                    await erik.sendMessage(from, ini_buffer, audio, { quoted: mek, mimetype: Mimetype.mp4Audio })
                    break
                case 'asmaulhusna':
            if (!isBanchatt) return
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/asmaulhusna?apikey=${LolKey}`)
                    get_result = get_result.result
                    ini_txt = `➵ No : ${get_result.index}\n`
                    ini_txt += `➵ Latin: ${get_result.latin}\n`
                    ini_txt += `➵ Arab : ${get_result.ar}\n`
                    ini_txt += `➵ Indonesia : ${get_result.id}\n`
                    ini_txt += `➵ English : ${get_result.en}`
                    fakelink(ini_txt)
                    break
                case 'kisahnabi':
            if (!isBanchatt) return
                    if (args.length == 0) return reply(`Contoh: ${prefix + command} Adam`)
                    query = args.join(" ")
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/kisahnabi/${query}?apikey=${LolKey}`)
                    get_result = get_result.result
                    ini_txt = `➵ Name : ${get_result.name}\n`
                    ini_txt += `➵ Lahir : ${get_result.thn_kelahiran}\n`
                    ini_txt += `➵ Umur : ${get_result.age}\n`
                    ini_txt += `➵ Tempat : ${get_result.place}\n`
                    ini_txt += `➵ Story : \n${get_result.story}`
                    fakelink(ini_txt)
                    break
                   case 'jadwalsholat':
            if (!isBanchatt) return
                    if (args.length == 0) return reply(`Nama Tempatnya?\nContoh: ${prefix + command} Yogyakarta`)
                    daerah = args.join(" ")
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/sholat/${daerah}?apikey=${LolKey}`)
                    get_result = get_result.result
                    ini_txt = `➵ Wilayah : ${get_result.wilayah}\n`
                    ini_txt += `➵ Tanggal : ${get_result.tanggal}\n`
                    ini_txt += `➵ Sahur : ${get_result.sahur}\n`
                    ini_txt += `➵ Imsak : ${get_result.imsak}\n`
                    ini_txt += `➵ Subuh : ${get_result.subuh}\n`
                    ini_txt += `➵ Terbit : ${get_result.terbit}\n`
                    ini_txt += `➵ Dhuha : ${get_result.dhuha}\n`
                    ini_txt += `➵ Dzuhur : ${get_result.dzuhur}\n`
                    ini_txt += `➵ Ashar : ${get_result.ashar}\n`
                    ini_txt += `➵ Maghrib : ${get_result.imsak}\n`
                    ini_txt += `I➵ sya : ${get_result.isya}`
                    fakelink(ini_txt)
                    break
 
//IMAGE
     
     case 'image':
            if (!isBanchatt) return
            if (args.length < 1) return reply('Masukan Query!')
            const gimg = args.join(' ');
            reply(mess.dl)
            gis(gimg, async (error, result) => {
            n = result
            images = n[Math.floor(Math.random() * n.length)].url
            erik.sendMessage(from,{url:images},image,{quoted:mek})
            });
            break
     case 'goimg':
       if (!isBanchatt) return
       if (!q) return reply(`Masukan Query!\nContoh: ${prefix + command} burung|3`)
            reply(mess.dl)
               var oi = q.split('|')[0];
               var ye = q.split('|')[1];
             for(let i=0;i<`${ye}`;i++){
             	try {
            let pin = await hx.pinterest(`${oi}`)
            let ac = pin[Math.floor(Math.random() * pin.length)]
            let di = await getBuffer(ac)
            await erik.sendMessage(from,di,image,{quoted: mek})
            } catch (err) {
            notfound(`Maaf *${pushname}*, Terjadi Kesalahan`)
            }
            }
            break
     case 'randomimage':
				case 'randomimg':
				case 'rimg':
				case'rimage':
            if (!isBanchatt) return
				     reply(mess.wait)
					anu = await fetchJson(`https://fdciabdul.tech/api/pinterest?keyword=gambarnya`, {method: 'get'})
					lo = JSON.parse(JSON.stringify(anu));
					li =  lo[Math.floor(Math.random() * lo.length)];
					nye = await getBuffer(li)
					erik.sendMessage(from, nye, image, { caption: 'NIH', quoted: mek })
					break
	 case 'ssweb':
            if (!isBanchatt) return
            reply(mess.dl)
            lah = args.join(" ")
            jir = await getBuffer(`https://shot.screenshotapi.net/screenshot?&url=${lah}&output=image&file_type=png&wait_for_event=load`)
            erik.sendMessage(from, jir, image,{quoted: mek,caption:'©Itz.Me/Erick'})
            break
     case 'pinterest':
            if (!isBanchatt) return
                    try {
                    if (args.length == 0) return reply(`Masukan Query!\nContoh: ${prefix + command} sunrise anime`)
                    query = args.join(" ")
                    reply(mess.dl)
                    ini_url = await fetchJson(`https://api.lolhuman.xyz/api/pinterest?apikey=${LolKey}&query=${query}`)
                    ini_url = ini_url.result
                    ini_buffer = await getBuffer(ini_url)
                    await erik.sendMessage(from, ini_buffer, image, { quoted: mek })
                    } catch (err) {
                    notfound("```ERROR```")
                    }
                    break
        case 'pinterest2':
            if (!isBanchatt) return 
                    if (args.length == 0) return reply(`Masukan Query!\nContoh: ${prefix + command} sunset anime`)
                    query = args.join(" ")
                    reply(mess.dl)
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/pinterest2?apikey=${LolKey}&query=${query}`)
                    get_result = get_result.result
                    for (var x = 0; x <= 5; x++) {
                        var ini_buffer = await getBuffer(get_result[x])
                        await erik.sendMessage(from, ini_buffer, image)
                    }
                    break
         case 'wallpaper':
            if (!isBanchatt) return
                    try {
                    if (args.length == 0) return reply(`Example: ${prefix + command} loli kawaii`)
                    query = args.join(" ")
                    reply (mess.dl)
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/wallpaper?apikey=${LolKey}&query=${query}`)
                    ini_buffer = await getBuffer(get_result.result)
                    await erik.sendMessage(from, ini_buffer, image, { quoted: mek })
                    } catch (err) {
                    notfound("```ERROR```")
                    }
                    break
         case 'wallpaper2':
            if (!isBanchatt) return
                    try {
                    if (args.length == 0) return reply(`Example: ${prefix + command} loli kawaii`)
                    query = args.join(" ")
                    reply (mess.dl)
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/wallpaper2?apikey=${LolKey}&query=${query}`)
                    ini_buffer = await getBuffer(get_result.result)
                    await erik.sendMessage(from, ini_buffer, image, { quoted: mek })
                    } catch (err) {
                    notfound("```ERROR```")
                    }
                    break
     case 'nulis':
            if (!isBanchatt) return
            reply (mess.wait)
			anuf = args.join(' ').split('|')
			let nulisdls = await getBuffer(`https://xteam.xyz/magernulis?nama=${anuf[0]}&kelas=${anuf[1]}&text=${anuf[2]}&APIKEY=${XKey}`,{ method: 'get'})
	        erik.sendMessage(from,nulisdls,image,{mimetype:'image/jpeg',quoted:mek,caption:'©Itz.Me/Erick'})
			break
	 case 'puisi':
            if (!isBanchatt) return
	           reply (mess.wait)
               pus = await getBuffer(`https://api.vhtear.com/puisi_image&apikey=${VhKey}`, { method: 'get' })
               erik.sendMessage(from, pus, image, { quoted: mek })
               break
            
//SEARCHING

         case 'lyric':
         case 'lyrics':
         case 'lirik':
         if (!isBanchatt) return
          if(!q) return reply('mau cari lirik lagu apa?')
          try {
           let song = await hx.lirik(q)
            sendMediaURL(from,song.thumb,song.lirik)
            } catch (err) {
              notfound(`Maaf *${pushname}*, Lirik Lagu *${q}* Tidak Ditemukan, pastikan judul lagu sudah benar`)
              }
              break
        case 'linkwa':
        case 'linkgc':
        case 'linkwangsap':
        case 'grupwangsap':
        if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
         if (!isBanchatt) return
            if(!q) return reply('cari group apa?')
            hx.linkwa(q)
            .then(result => {
            let res = `-----------[ *Link Grup Wangsap* ]-----------\n\n`
            for (let i of result) {
            res += `➸ *Nama*: *${i.nama}\n➸ *Link*: ${i.link}\n\n`
            }
            fakelink(res)
            });
            break
         case 'google':
            if (!isBanchatt) return
                    if (args.length == 0) return reply(`Apanya Yang mau di cari bujank??\nContoh: ${prefix + command} Cara biar ga jadi beban keluarga`)
                    query = args.join(" ")
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/gsearch?apikey=${LolKey}&query=${query}`)
                    get_result = get_result.result
                    ini_txt = 'Google Search : \n'
                    for (var x of get_result) {
                        ini_txt += `Title : ${x.title}\n`
                        ini_txt += `Link : ${x.link}\n`
                        ini_txt += `Desc : ${x.desc}\n\n`
                    }
                    fakelink(ini_txt)
                    break
         case 'brainly':
            if (!isBanchatt) return
			if (args.length < 1) return reply('Pertanyaan apa')
          	brien = args.join(' ')
			brainly(`${brien}`).then(res => {
			teks = '❉───────────────────────❉\n'
			for (let Y of res.data) {
			teks += `\n*「 _BRAINLY_ 」*\n\n*➸ Pertanyaan:* ${Y.pertanyaan}\n\n*➸ Jawaban:* ${Y.jawaban[0].text}\n❉──────────────────❉\n`
			}
			erik.sendMessage(from, teks, text,{quoted:mek,detectLinks: false})                        
            })              
			break
	case 'brainly2':
                    if (!isBanchatt) return
                    if (args.length == 0) return reply(`Example: ${prefix + command} siapakah sukarno`)
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/brainly2?apikey=${LolKey}&query=${args.join(" ")}`)
                    lala = get_result.result
                    ini_txt = "Beberapa Pembahasan Dari Brainly :\n\n"
                    for (var x of lala) {
                        ini_txt += `==============================\n`
                        ini_txt += `\`\`\`Pertanyaan :\`\`\`\n${x.question.content}\n\n`
                        ini_txt += `\`\`\`Jawaban :\`\`\`\n${x.answer[0].content}\n`
                        ini_txt += `==============================\n\n`
                    }
                    fakelink(ini_txt)
                    break
    case 'igstalk':
            if (!isBanchatt) return
            try {
            if (!q) return fakegroup('Usernamenya?')
            ig.fetchUser(`${args.join(' ')}`).then(Y => {
            console.log(`${args.join(' ')}`)
            ten = `${Y.profile_pic_url_hd}`
            teks = `*ID* : ${Y.profile_id}\n*Username* : ${args.join('')}\n*Full Name* : ${Y.full_name}\n*Bio* : ${Y.biography}\n*Followers* : ${Y.followers}\n*Following* : ${Y.following}\n*Private* : ${Y.is_private}\n*Verified* : ${Y.is_verified}\n\n*Link* : https://instagram.com/${args.join('')}`
            sendMediaURL(from,ten,teks) 
            })
              } catch (err) {
              notfound("```USERNAME TIDAK DITEMUKAN!```")
              }
            break
         case 'igstalk2':
            if (!isBanchatt) return
                    try {
                    if (args.length == 0) return reply(`Contoh: ${prefix + command} shuichi_126`)
                    username = args[0]
                    ini_result = await fetchJson(`https://api.lolhuman.xyz/api/stalkig/${username}?apikey=${LolKey}`)
                    ini_result = ini_result.result
                    ini_buffer = await getBuffer(ini_result.photo_profile)
                    ini_txt = `➵ Username : ${ini_result.username}\n`
                    ini_txt += `➵ Full Name : ${ini_result.fullname}\n`
                    ini_txt += `➵ Posts : ${ini_result.posts}\n`
                    ini_txt += `➵ Followers : ${ini_result.followers}\n`
                    ini_txt += `➵ Following : ${ini_result.following}\n`
                    ini_txt += `➵ Bio : ${ini_result.bio}`
                    erik.sendMessage(from, ini_buffer, image, { caption: ini_txt })
                    } catch (err) {
                    notfound("```USERNAME TIDAK DITEMUKAN!```")
                    }
                    break
              case 'github':
            if (!isBanchatt) return
                    if (args.length == 0) return reply(`Contoh: ${prefix + command} HexagonZ`)
                    username = args[0]
                    ini_result = await fetchJson(`https://api.lolhuman.xyz/api/github/${username}?apikey=${LolKey}`)
                    ini_result = ini_result.result
                    ini_buffer = await getBuffer(ini_result.avatar)
                    ini_txt = `➵ Name : ${ini_result.name}\n`
                    ini_txt += `➵ Link : ${ini_result.url}\n`
                    ini_txt += `➵ Public Repo : ${ini_result.public_repos}\n`
                    ini_txt += `➵ Public Gists : ${ini_result.public_gists}\n`
                    ini_txt += `➵ Followers : ${ini_result.followers}\n`
                    ini_txt += `➵ Following : ${ini_result.following}\n`
                    ini_txt += `➵ Bio : ${ini_result.bio}`
                    erik.sendMessage(from, ini_buffer, image, { caption: ini_txt })
                    break
		      case 'translate':
            if (!isBanchatt) return
                    if (args.length == 0) return reply(`Contoh: ${prefix + command} en rebahan`)
                    trsl = args.join(' ') 
                var kode = trsl.split('|')[0];
               var hasil = trsl.split('|')[1];
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/translate/auto/${kode}?apikey=${LolKey}&text=${hasil}`)
                    get_result = get_result.result
                    hasil = `➵ From : ${get_result.from}\n`
                    hasil += `➵ To : ${get_result.to}\n`
                    hasil += `➵ Original : ${get_result.original}\n`
                    hasil += `➵ Translated : ${get_result.translated}\n`
                    hasil += `➵ Pronunciation : ${get_result.pronunciation}\n`
                    reply(hasil)
                    break
                    case 'tr':
            if (!isBanchatt) return
if(!q) return reply(`Cara Penggunaan ${prefix}tr [kodebahasa teks]/reply pesan dengan ${prefix}tr kodebahasa\nExample : ${prefix}tr id I Love you`)
if(!args[0]) return reply(`Masukkan kode bahasanya om`)
try{
if(!args[1]){
   if(mek.message.conversation) return reply(`Cara Penggunaan ${prefix}tr [kodebahasa teks]/reply pesan dengan ${prefix}tr kodebahasa\nExample : ${prefix}tr id I Love you`)
   tra = await translate(mek.message.extendedTextMessage.contextInfo.quotedMessage.conversation, {to:args[0]})
   console.log(tra)
   reply(tra.text)
}
else{
   codelang = args[0]
   tra = await translate(body.slice(4+codelang.length), {to:codelang})
   console.log(tra)
   reply(tra.text)
}
}catch(e){
   reply('Error')
}
break
    case 'ytsearch':
	case 'youtube':
	case 'youtubesearch':
	case 'yts':
            if (!isBanchatt) return
			if (args.length < 1) return reply('Tolong masukan query!')
			var srch = args.join('');
			try {
        	var aramas = await yts(srch);
   			} catch {
        	return await erik.sendMessage(from, 'Error!', MessageType.text, dload)
    		}
    		aramat = aramas.all 
    		var tbuff = await getBuffer(aramat[0].image)
    		var ytresult = '';
    		ytresult += '「 *YOUTUBE SEARCH* 」'
    		ytresult += '\n________________________\n\n'
   			aramas.all.map((video) => {
        	ytresult += '❏ Title: ' + video.title + '\n'
            ytresult += '❏ Link: ' + video.url + '\n'
            ytresult += '❏ Durasi: ' + video.timestamp + '\n'
            ytresult += '❏ Upload: ' + video.ago + '\n________________________\n\n'
    		});
    		ytresult += '◩ *©Itz.Me/Erick*'
    		await fakethumb(tbuff,ytresult)
			break
	 case 'cuaca2':
            if (!isBanchatt) return
			if (args.length < 1) return reply('Masukan Nama Kota nya!\nContoh: ${prefix + command} Jakarta')
			weathers = args.join(' ')	
		    let wearesult = await fetchJson(`https://xteam.xyz/cuaca?kota=${weathers}&APIKEY=${XKey}`,{ method: 'get'})
		    me = `*「 _CUACA_ 」*\n\n*➸ Kota:* ${wearesult.message.kota}\n*➸ Hari:* ${wearesult.message.hari}\n*➸ Cuaca:* ${wearesult.message.cuaca}\n*➸ Desk:* ${wearesult.message.deskripsi}\n*➸ Suhu:* ${wearesult.message.suhu}\n*➸ Pressure:* ${wearesult.message.pressure}\n*➸ Kelembapan:* ${wearesult.message.kelembapan}\n*➸ Angin:* ${wearesult.message.angin}`
    	    erik.sendMessage(from, me, text,{quoted:mek,detectLinks: false}) 
			break
	 case 'cuaca':
	case 'cuacaxloc':
	if (!isBanchatt) return
	if (args.length < 1) return reply(`Masukan Nama Kota nya!\nContoh: ${prefix + command} Jakarta`)
			lokasi = args.join(' ')
v2 = await fetchJson(`https://lolhuman.herokuapp.com/api/cuaca/${lokasi}?apikey=${LolKey}`)
v2 = v2.result
teks = `*「 _CUACA_ 」*\n\n*➸ Kota:* ${v2.tempat}\n*➸ Latitude:* ${v2.latitude}\n*➸ Longitude:* ${v2.longitude}\n*➸ Cuaca:* ${v2.cuaca}\n*➸ Angin:* ${v2.angin}\n*➸ Deskripsi:* ${v2.description}\n*➸ Kelembapan:* ${v2.kelembapan}\n*➸ Suhu:* ${v2.suhu}\n*➸ Udara:* ${v2.udara}\n*➸ Permukaan Laut:* ${v2.permukaan_laut}`
erik.sendMessage(from, { degreesLatitude: v2.latitude, degreesLongitude: v2.longitude }, location, { quoted: mek, caption: teks })

erik.sendMessage(from, teks, text, {quoted:mek})
break
case 'jarak':
case 'jaraktempuh':
            if (!isBanchatt) return
if (args.length < 1) return reply('kota nya?');
               kota = args.join(' ') 
               var kota1 = kota.split('|')[0];
               var kota2 = kota.split('|')[1]; 
rik = await fetchJson(`https://lolhuman.herokuapp.com/api/jaraktempuh?apikey=${LolKey}&kota1=${kota1}&kota2=${kota2}`)
teks = `*Jarak Tempuh*\n\nDari : ${rik.result.from.name}\nKe : ${rik.result.to.name}\nPerkiraan Jarak : ${rik.result.jarak}\n\nBerikut Perkiraan Waktu Sampai Berdasarkan Kendaraan :\n\nKereta Api : ${rik.result.kereta_api}\nPesawat : ${rik.result.pesawat}\nMobil : ${rik.result.mobil}\nMotor : ${rik.result.motor}\nJalan Kaki : ${rik.result.jalan_kaki}`
erik.sendMessage(from, { degreesLatitude: rik.result.from.latitude, degreesLongitude: rik.result.from.longitude }, location, { quoted: mek })
erik.sendMessage(from, { degreesLatitude: rik.result.to.latitude, degreesLongitude: rik.result.to.longitude }, location, { quoted: mek })
erik.sendMessage(from, teks, text,{quoted:mek})
break
	 case 'playstore':
            if (!isBanchatt) return
               ps = `${body.slice(11)}`
               anu = await fetchJson(`https://api.vhtear.com/playstore?query=${ps}&apikey=${VhKey}`, { method: 'get' })
               store = '======================\n'
               for (let ply of anu.result) {
                  store += `• *Nama Apk:* ${ply.title}\n• *ID:* ${ply.app_id}\n• *Developer:* ${ply.developer}\n• *Deskripsi:* ${ply.description}\n• *Link Apk:* ${ply.url}\n=====================\n`
               }
               reply(store.trim())
               break
          case 'wikipedia':
          case 'wiki':
                    if (!isBanchatt) return
                    if (args.length == 0) return reply(`Example: ${prefix + command} Tahu`)
                    query = args.join(" ")
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/wiki?apikey=${LolKey}&query=${query}`)
                    get_result = get_result.result
                    fakelink(get_result)
                    break
			case 'newsinfo':
                    if (!isBanchatt) return
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/newsinfo?apikey=${LolKey}`)
                    get_result = get_result.result
                    ini_txt = "Result :\n"
                    for (var x of get_result) {
                        ini_txt += `Title : ${x.title}\n`
                        ini_txt += `Author : ${x.author}\n`
                        ini_txt += `Source : ${x.source.name}\n`
                        ini_txt += `Url : ${x.url}\n`
                        ini_txt += `Published : ${x.publishedAt}\n`
                        ini_txt += `Description : ${x.description}\n\n`
                    }
                    fakelink(ini_txt)
                    break
                case 'cnnindonesia':
                    if (!isBanchatt) return
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/cnnindonesia?apikey=${LolKey}`)
                    get_result = get_result.result
                    ini_txt = "Result :\n"
                    for (var x of get_result) {
                        ini_txt += `Judul : ${x.judul}\n`
                        ini_txt += `Link : ${x.link}\n`
                        ini_txt += `Tipe : ${x.tipe}\n`
                        ini_txt += `Published : ${x.waktu}\n\n`
                    }
                    fakelink(ini_txt)
                    break
                case 'cnnnasional':
                    if (!isBanchatt) return
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/cnnindonesia/nasional?apikey=${LolKey}`)
                    get_result = get_result.result
                    ini_txt = "Result :\n"
                    for (var x of get_result) {
                        ini_txt += `Judul : ${x.judul}\n`
                        ini_txt += `Link : ${x.link}\n`
                        ini_txt += `Tipe : ${x.tipe}\n`
                        ini_txt += `Published : ${x.waktu}\n\n`
                    }
                    fakelink(ini_txt)
                    break
                case 'cnninternasional':
                    if (!isBanchatt) return
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/cnnindonesia/internasional?apikey=${LolKey}`)
                    get_result = get_result.result
                    ini_txt = "Result :\n"
                    for (var x of get_result) {
                        ini_txt += `Judul : ${x.judul}\n`
                        ini_txt += `Link : ${x.link}\n`
                        ini_txt += `Tipe : ${x.tipe}\n`
                        ini_txt += `Published : ${x.waktu}\n\n`
                    }
                    fakelink(ini_txt)
                    break
//DOWNLOAD

     case 'playmp3':
            if (!isBanchatt) return
			if (args.length === 0) return reply(`Kirim perintah *${prefix}play* _Judul lagu yang akan dicari_`)
            var srch = args.join('')
    		aramas = await yts(srch);
    		aramat = aramas.all 
   			var mulaikah = aramat[0].url							
                  try {
                    yta(mulaikah)
                    .then((res) => {
                        const { dl_link, thumb, title, filesizeF, filesize } = res
                        axios.get(`https://tinyurl.com/api-create.php?url=${dl_link}`)
                        .then(async (a) => {
                        if (Number(filesize) >= 100000) return sendMediaURL(from, thumb, `*PLAY MUSIC*\n\n*Title* : ${title}\n*Ext* : MP3\n*Filesize* : ${filesizeF}\n*Link* : ${a.data}\n\n_Untuk durasi lebih dari batas disajikan dalam mektuk link_`)
                        const captions = `*PLAY MUSIC*\n\n*Title* : ${title}\n*Ext* : MP3\n*Size* : ${filesizeF}\n*Link* : ${a.data}\n\n_Silahkan tunggu file media sedang dikirim mungkin butuh beberapa menit_`
                        sendMediaURL(from, thumb, captions)
                        await sendMediaURL(from, dl_link).catch(() => reply('error'))
                        })                
                        })
                        } catch (err) {
                        reply(mess.error.api)
                        }
                   break
        case 'ig':
            if (!isBanchatt) return
                    if (args.length == 0) return reply(`Example: ${prefix + command} https://www.instagram.com/p/CJ8XKFmJ4al/?igshid=1acpcqo44kgkn`)
                    ini_url = args[0]
                    ini_url = await fetchJson(`https://api.lolhuman.xyz/api/instagram?apikey=${LolKey}&url=${ini_url}`)
                    ini_url = ini_url.result
                    ini_type = image
                    if (ini_url.includes(".mp4")) ini_type = video
                    ini_buffer = await getBuffer(ini_url)
                    await erik.sendMessage(from, ini_buffer, ini_type, { quoted: mek })
                    break
        case 'igstory': 
            if(!q) return reply('Usernamenya?')
            try {
            hx.igstory(q)
            .then(async result => {
            for(let i of result.medias){
                if(i.url.includes('mp4')){
                    let link = await getBuffer(i.url)
                    erik.sendMessage(from,link,video,{quoted: mek,caption: `Type : ${i.type}`})
                } else {
                    let link = await getBuffer(i.url)
                    erik.sendMessage(from,link,image,{quoted: mek,caption: `Type : ${i.type}`})                  
                }
            }
            });
            } catch (err) {
             notfound('Username Tidak Ditemukan!')
             }
            break
        case 'playmp4':
            if (!isBanchatt) return
            if (args.length === 0) return reply(`Contoh: *${prefix}video* _Judul lagu yang akan dicari_`)
            var srch = args.join('')
            aramas = await yts(srch);
            aramat = aramas.all 
            var mulaikah = aramat[0].url                            
                  try {
                    ytv(mulaikah)
                    .then((res) => {
                        const { dl_link, thumb, title, filesizeF, filesize } = res
                        axios.get(`https://tinyurl.com/api-create.php?url=${dl_link}`)
                        .then(async (a) => {
                        if (Number(filesize) >= 100000) return sendMediaURL(from, thumb, `*PLAY VIDEO*\n\n*Title* : ${title}\n*Ext* : MP3\n*Filesize* : ${filesizeF}\n*Link* : ${a.data}\n\n_Untuk durasi lebih dari batas disajikan dalam mektuk link_`)
                        const captions = `*PLAY VIDEO*\n\n*Title* : ${title}\n*Ext* : MP4\n*Size* : ${filesizeF}\n*Link* : ${a.data}\n\n_Silahkan tunggu file media sedang dikirim mungkin butuh beberapa menit_`
                        sendMediaURL(from, thumb, captions)
                        await sendMediaURL(from, dl_link).catch(() => reply('error'))
                        })                
                        })
                        } catch (err) {
                        reply(mess.error.api)
                        }
                   break
	case 'ytmp4':
            if (!isBanchatt) return
			if (args.length === 0) return reply(`Kirim perintah *${prefix}ytmp4 [linkYt]*`)
			let isLinks2 = args[0].match(/(?:https?:\/{2})?(?:w{3}\.)?youtu(?:be)?\.(?:com|be)(?:\/watch\?v=|\/)([^\s&]+)/)
			if (!isLinks2) return reply(mess.error.Iv)
				try {
				reply(mess.dl)
				ytv(args[0])
				.then((res) => {
				const { dl_link, thumb, title, filesizeF, filesize } = res
				axios.get(`https://tinyurl.com/api-create.php?url=${dl_link}`)
				.then((a) => {
				if (Number(filesize) >= 40000) return sendMediaURL(from, thumb, `*YTMP 4!*\n\n*Title* : ${title}\n*Ext* : MP3\n*Filesize* : ${filesizeF}\n*Link* : ${a.data}\n\n_Untuk durasi lebih dari batas disajikan dalam mektuk link_`)
				const captionsYtmp4 = `*Data Berhasil Didapatkan!*\n\n*Title* : ${title}\n*Ext* : MP4\n*Size* : ${filesizeF}\n\n_Silahkan tunggu file media sedang dikirim mungkin butuh beberapa menit_`
				sendMediaURL(from, thumb, captionsYtmp4)
				sendMediaURL(from, dl_link).catch(() => reply(mess.error.api))
				})		
				})
				} catch (err) {
			    reply(mess.error.api)
				}
				break
	case 'ytmp3':
            if (!isBanchatt) return
			if (args.length === 0) return reply(`Kirim perintah *${prefix}ytmp3 [linkYt]*`)
			let isLinks = args[0].match(/(?:https?:\/{2})?(?:w{3}\.)?youtu(?:be)?\.(?:com|be)(?:\/watch\?v=|\/)([^\s&]+)/)
			if (!isLinks) return reply(mess.error.Iv)
				try {
				reply(mess.dl)
				yta(args[0])
				.then((res) => {
				const { dl_link, thumb, title, filesizeF, filesize } = res
				axios.get(`https://tinyurl.com/api-create.php?url=${dl_link}`)
				.then((a) => {
			    if (Number(filesize) >= 30000) return sendMediaURL(from, thumb, `*Data Berhasil Didapatkan!*\n\n*Title* : ${title}\n*Ext* : MP3\n*Filesize* : ${filesizeF}\n*Link* : ${a.data}\n\n_Untuk durasi lebih dari batas disajikan dalam mektuk link_`)
				const captions = `*YTMP3*\n\n*Title* : ${title}\n*Ext* : MP3\n*Size* : ${filesizeF}\n\n_Silahkan tunggu file media sedang dikirim mungkin butuh beberapa menit_`
				sendMediaURL(from, thumb, captions)
				sendMediaURL(from, dl_link).catch(() => reply(mess.error.api))
				})
				})
				} catch (err) {
				reply(mess.error.api)
				}
				break
	case 'tiktokmp4':
            if (!isBanchatt) return
 		if (!isUrl(args[0]) && !args[0].includes('tiktok.com')) return reply(mess.Iv)
 		if (!q) return fakegroup('Linknya?')
 		reply(mess.dl)
	    let result = await fetchJson(`http://lolhuman.herokuapp.com/api/tiktok?apikey=${LolKey}&url=${args[0]}`,{ method: 'get'})
    		me = `*「 TIKTOK DL 」*\n\n*Title* : ${result.result.title}\n*Desc* : ${result.result.description}\n*Duration* : ${result.result.duration} detik\n*Like* : ${result.result.statistic.diggCount}\n*Play* : ${result.result.statistic.playCount}\n*Komentar* : ${result.result.statistic.commentCount}\n*Share* : ${result.result.shareCount}`
		    me2 = `*「 CREATOR 」*\n\n*Username* : ${result.result.author.username}\n*Nickname*: ${result.result.author.nickname}`
        erik.sendMessage(from,{url:`${result.result.author.avatar}`},image,{mimetype:'image/jpeg',quoted:mek,caption:me2})
        erik.sendMessage(from,{url:`${result.result.link}`},video,{mimetype:'video/mp4',quoted:mek,caption:me})
     	break
      case 'tiktokmp3':
            if (!isBanchatt) return
            if (!isUrl(args[0]) && !args[0].includes('tiktok.com')) return reply(mess.Iv)
            if (!q) return fakegroup('Linknya?')
            reply(mess.dl)
            let resulttoks = await getBuffer(`http://lolhuman.herokuapp.com/api/tiktokmusic?apikey=${LolKey}&url=${args[0]}`,{ method: 'get'})	
            erik.sendMessage(from,resulttoks,audio,{mimetype:'audio/mp4',filename : `tiktodaudio`,quoted:mek})
                break
    case 'fb':
            if (!isBanchatt) return
                    if (args.length == 0) return reply(`Example: ${prefix + command} https://id-id.facebook.com/SamsungGulf/videos/video-bokeh/561108457758458/`)
                    ini_url = args[0]
                    ini_url = await fetchJson(`https://api.lolhuman.xyz/api/facebook?apikey=${LolKey}&url=${ini_url}`)
                    ini_url = ini_url.result[0].link
                    ini_buffer = await getBuffer(ini_url)
                    await erik.sendMessage(from, ini_buffer, video, { quoted: mek })
                    break
    case'twitter':
            if (!isBanchatt) return
            if (!isUrl(args[0]) && !args[0].includes('twitter.com')) return reply(mess.Iv)
            if (!q) return fakegroup('Linknya?')
            ten = args[0]
            var res = await twitterGetUrl(`${ten}`)
            .then(g => {
            ren = `${g.download[2].url}`
            sendMediaURL(from,ren,'DONE')
            })
            break
    case 'get':
            if (!isBanchatt) return
            if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
            if(!q) return reply('linknya?')
            fetch(`${args[0]}`).then(res => res.text())  
            .then(bu =>{
            fakelink(bu)
            })   
            break
     case 'zippyshare':
            if (!isBanchatt) return
                    if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
                    if (args.length == 0) return reply(`Example: ${prefix + command} https://www51.zippyshare.com/v/5W0TOBz1/file.html`)
                    ini_url = args[0]
                    ini_url = await fetchJson(`https://api.lolhuman.xyz/api/zippyshare?apikey=${LolKey}&url=${ini_url}`)
                    ini_url = ini_url.result
                    ini_txt = `File Name : ${ini_url.name_file}\n`
                    ini_txt += `Size : ${ini_url.size}\n`
                    ini_txt += `Date Upload : ${ini_url.date_upload}\n`
                    ini_txt += `Download Url : ${ini_url.download_url}`
                    fakelink(ini_txt)
                    break
                   
//OTHER
case 'ceritaseram':
const cheerio = require('cheerio')
const ceritahorror = async(link) => {
        return new Promise((resolve,reject) => {
                axios.get(link)
                .then(({ data }) => {
                        const $ = cheerio.load(data)
                        const judul = $('header > h1').text();
                        const desc = $('header > div > span').text(); + $('header > div > span > span').text(); + $('header > div > span > time').text();
                        const cerita = $('div.entry-content').text();
                        const result = judul + '\n' + desc + '\n\n' + cerita
                  resolve(result)
                })
                .catch(reject)
        })
}
let data = await axios.get('https://raw.githubusercontent.com/fajar55/txt/main/ceritahorror.json')
let rand = await data.data[Math.floor(Math.random() * data.data.length)]
y = await ceritahorror(rand)
reply( y)
break
case 'report':
                    if (!q) return textImg('mau lapor apa pak')
                    if (!isGroup) {
                        sendMess(ownerNumber, `*── 「 REPORT 」 ──*\n\n*From*: ${pushname}\n*ID*: ${sender}\n*Group*: ${groupName}\n*Message*: ${q}`)
                        reply(`Laporan Diterima`)
                    } else {
                        sendMess(ownerNumber, `*── 「 REPORT 」 ──*\n\n*From*: ${pushname}\n*ID*: ${sender}\n*Message*: ${q}`)
                        reply(`Laporan Diterima`)
                    }
                    break
     case 'shortlink':
     case 'shorturl':
            if (!isBanchatt) return
                    if (args.length == 0) return reply(`Example: ${prefix + command} https://api.lolhuman.xyz`)
                    ini_link = args[0]
                    ini_buffer = await fetchJson(`https://api.lolhuman.xyz/api/shortlink?apikey=${LolKey}&url=${ini_link}`)
                    reply(ini_buffer.result)
                    break
     case 'spam':
              if (!isBanchatt) return
             if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
                kls = args.join(' ') 
               var oi = kls.split('|')[0];
               var ye = kls.split('|')[1];
             for(let i=0;i<`${ye}`;i++){
             reply(`${oi}`)
             }
             break
     case 'repeat':
               if (!isBanchatt) return
               if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
               pe = args.join(' ') 
               var teks = pe.split('|')[0];
               var jum = pe.split('|')[1];
               reply(`${teks}\n`.repeat(`${jum}`))
         break
     case 'spamsms':
            if (!isBanchatt) return
             if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
                    if (args.length == 0) return reply(`Masukan nomor dengan awalan 08\nContoh: ${prefix + command} 08××××××××`)
                    nomor = args[0]
                    await fetchJson(`https://api.lolhuman.xyz/api/sms/spam1?apikey=${LolKey}&nomor=${nomor}`)
                    await fetchJson(`https://api.lolhuman.xyz/api/sms/spam2?apikey=${LolKey}&nomor=${nomor}`)
                    await fetchJson(`https://api.lolhuman.xyz/api/sms/spam3?apikey=${LolKey}&nomor=${nomor}`)
                    await fetchJson(`https://api.lolhuman.xyz/api/sms/spam4?apikey=${LolKey}&nomor=${nomor}`)
                    await fetchJson(`https://api.lolhuman.xyz/api/sms/spam5?apikey=${LolKey}&nomor=${nomor}`)
                    await fetchJson(`https://api.lolhuman.xyz/api/sms/spam6?apikey=${LolKey}&nomor=${nomor}`)
                    await fetchJson(`https://api.lolhuman.xyz/api/sms/spam7?apikey=${LolKey}&nomor=${nomor}`)
                    await fetchJson(`https://api.lolhuman.xyz/api/sms/spam8?apikey=${LolKey}&nomor=${nomor}`)
                    reply("Berhasil!")
                    break
     case 'spamtelp':
                    if (!isBanchatt) return
                    if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
                    if (args.length == 0) return reply(`Masukan nomor dengan awalan 8\nContoh: ${prefix + command} 8××××××××`)
                    target = args[0]
                    await fetchJson(`https://alfians-api.herokuapp.com/api/spamcall?no=${target}`)
                    await fetchJson(`https://alfians-api.herokuapp.com/api/spamcall?no=${target}`)
                    await fetchJson(`https://alfians-api.herokuapp.com/api/spamcall?no=${target}`)
                    await fetchJson(`https://alfians-api.herokuapp.com/api/spamcall?no=${target}`)
                    await fetchJson(`https://alfians-api.herokuapp.com/api/spamcall?no=${target}`)
                    await fetchJson(`https://alfians-api.herokuapp.com/api/spamcall?no=${target}`)
                    await fetchJson(`https://alfians-api.herokuapp.com/api/spamcall?no=${target}`)
                    await fetchJson(`https://alfians-api.herokuapp.com/api/spamcall?no=${target}`)
                    break
    case 'readmore':
            if (!isBanchatt) return
               if (args.length < 1) return reply('teks nya mana om?');
               var kls = body.slice(9);
               var has = kls.split('|')[0];
               var kas = kls.split('|')[1];
               if (args.length < 1) return reply(mess.blank);
               erik.sendMessage(
                  from,
                  `${has}‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎${kas}`,
                  text,
                  { quoted: mek }
               );
               break
    case 'say':
    case 'mention':
            if (!isBanchatt) return
    if (!mek.key.fromMe && !isOwner && !isGroupAdmins) return reply(mess.only.admin)
    if (args.includes(cmnd)) return
    kls = args.join(' ')
    var has = kls.split('|')[0];
    var kas = kls.split('|')[1];
    erik.sendMessage(from, `${kas}`, text, {
                quoted: {
                    key: {
                        fromMe: false,
                        participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "6289523258649-1604595598@g.us" } : {})
                    },
                    message: {
                        "imageMessage": {
                            "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc",
                            "mimetype": "image/jpeg",
                            "caption": `${has}`,
                            "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=",
                            "fileLength": "28777",
                            "height": 1080,
                            "width": 1079,
                            "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=",
                            "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=",
                            "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69",
                            "mediaKeyTimestamp": "1610993486",
                            "jpegThumbnail": fs.readFileSync('./stik/thumb.jpeg'),
                            "scansSidecar": "1W0XhfaAcDwc7xh1R8lca6Qg/1bB4naFCSngM2LKO2NoP5RI7K+zLw=="
                        }
                    }
                }
            })
    break
    case 'owner':
               erik.sendMessage(from, { displayname: 'jeff', vcard: vcard }, MessageType.contact, { quoted: mek });
               erik.sendMessage(from, { displayname: 'jeff', vcard: vcard1 }, MessageType.contact, { quoted: mek });
               erik.sendMessage(from, '*_Kalo mau save, pc dlu ye tod_*', text, { quoted: mek });
               break
    case 'kontak':
            if (!isBanchatt) return
            pe = args.join(' ') 
            entah = pe.split('|')[0]
            nah = pe.split('|')[1]
            if (isNaN(entah)) return reply('Invalid phone number');
            vcard = 'BEGIN:VCARD\n'
            + 'VERSION:3.0\n'
            + `FN:${nah}\n`
            + `TEL;type=CELL;type=VOICE;waid=${entah}:${phoneNum('+' + entah).getNumber('internasional')}\n`
            + 'END:VCARD'.trim()
            erik.sendMessage(from, {displayName: `${nah}`, vcard: vcard}, contact)
            break
     case 'shutdown':
             if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB) 
             reply("```off```")
             await sleep(3000)
             process.exit()
             break
      case 'restart':
             if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB) 
             exec(`cd /sdcard && cp -r self-rik /$HOME && cd && cd self-rik && npm start`)
             await sleep(3000)
             reply("```sukses restart bot```")
             break
     case 'logout':
             if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB) 
             reply("```menutup session linux```")
             await sleep(3000)
             process.logout()
             break
    case 'runtime':
            if (!isBanchatt) return
            if (!mek.key.fromMe && !isOwner) return
            run = process.uptime() 
            teks = `${kyun(run)}`
            fakegroup(teks)
            break  
    case 'botinfo':
	case 'infobot':
	case 'speed':
            if (!isBanchatt) return
            if (!mek.key.fromMe && !isOwner) return
			const timestamp = speed();
			const latensi = speed() - timestamp
			exec(`neofetch --stdout`, (error, stdout, stderr) => {
			const child = stdout.toString('utf-8')
			const teks = child.replace(/Memory:/, "Ram:")
			const run = process.uptime() 
			const pingnya = `*INFO BOT:*\n\n${teks}*Speed: ${latensi.toFixed(4)} Second*\n*Runtime:* ${kyun(run)}`
			testing(pingnya)
			})
			break  
    case 'inspect':
            try {
            if (!mek.key.fromMe && !isOwner) return reply(mess.only.ownerB)
            if (!isBanchatt) return
            if (!isUrl(args[0]) && !args[0].includes('whatsapp.com')) return reply(mess.Iv)
            if (!q) return reply('masukan link wa')
            cos = args[0]
            var net = cos.split('https://chat.whatsapp.com/')[1]
            if (!net) return reply('pastikan itu link https://whatsapp.com/')
            jids = []
            let { id, owner, subject, subjectOwner, desc, descId, participants, size, descOwner, descTime, creation} = await erik.query({ 
            json: ["query", "invite",net],
            expect200:true })
            let par = `*Id* : ${id}
${owner ? `*Owner* : @${owner.split('@')[0]}` : '*Owner* : -'}
*Nama Gc* : ${subject}
*Gc dibuat Tanggal* : ${formatDate(creation * 1000)}
*Jumlah Member* : ${size}
${desc ? `*Desc* : ${desc}` : '*Desc* : tidak ada'}
*Id desc* : ${descId}
${descOwner ? `*Desc diubah oleh* : @${descOwner.split('@')[0]}` : '*Desc diubah oleh* : -'}\n*Tanggal* : ${descTime ? `${formatDate(descTime * 1000)}` : '-'}\n\n*Kontak yang tersimpan*\n`
           for ( let y of participants) {
             par += `> @${y.id.split('@')[0]}\n*Admin* : ${y.isAdmin ? 'Ya' : 'Tidak'}\n`
             jids.push(`${y.id.replace(/@c.us/g,'@s.whatsapp.net')}`)
             }
             jids.push(`${owner ? `${owner.replace(/@c.us/g,'@s.whatsapp.net')}` : '-'}`)
             jids.push(`${descOwner ? `${descOwner.replace(/@c.us/g,'@s.whatsapp.net')}` : '-'}`)
             erik.sendMessage(from,par,text,{quoted:mek,contextInfo:{mentionedJid:jids}})
             } catch {
             reply('Link error')
             }
             break
default:
if (budy.includes('@6s287870899272')) {
            erik.updatePresence(from, Presence.composing)
            const rik = fs.readFileSync('./sound/help.mp3')
            erik.sendMessage(from, rik, MessageType.audio, { quoted: mek, mimetype: 'audio/mp4', ptt: true })
         }
if (budy.includes(' ara')) {
            erik.updatePresence(from, Presence.composing)
            const rik = fs.readFileSync('./sound/ara.mp3')
            erik.sendMessage(from, rik, MessageType.audio, { quoted: mek, mimetype: 'audio/mp4', ptt: true, duration: 99999999999999999999999 })
         }
if (budy.includes('@6282130301023') && !mek.key.fromMe){
            erik.updatePresence(from, Presence.composing)
            const rik = fs.readFileSync('./sound/OnceUpon.mp3')
            erik.sendMessage(from, rik, MessageType.audio, { quoted: mek, mimetype: 'audio/mp4', ptt: true, duration: 999999999999999999999 })
         }
if (budy.includes('ohayo')) {
            erik.updatePresence(from, Presence.composing)
            const rik = fs.readFileSync('./sound/ohayou.mp3')
            erik.sendMessage(from, rik, MessageType.audio, { quoted: mek, mimetype: 'audio/mp4', ptt: true })
         }
if (budy.includes('Ohayo')) {
            erik.updatePresence(from, Presence.composing)
            const rik = fs.readFileSync('./sound/ohayou.mp3')
            erik.sendMessage(from, rik, MessageType.audio, { quoted: mek, mimetype: 'audio/mp4', ptt: true })
         }
if(budy === 'P'){
	        if (!mek.key.fromMe) return
            erik.updatePresence(from, Presence.composing)
            const rik = fs.readFileSync('./sound/thtyd.mp3')
            erik.sendMessage(from, rik, MessageType.audio, { quoted: mek, mimetype: 'audio/mp4', ptt: true, duration: 9999999999999999999999999999 })
         }
if(budy === 'P'){
if (!mek.key.fromMe) return
faketroli('```ACTIVE```')
}
if(budy.includes('@6282130301023') && !mek.key.fromMe){
otomatis("```Ya ada perlu apa?```\n```Kalo penting pc aja.```")
}
if(budy.includes('@s6282130301023')){
 await erik.sendMessage(m.chat, {
                contentText: `ya?`,
                footerText: `ItzMeErick`,
                buttons: [
                    { buttonId: `${prefix}help`, buttonText: { displayText: 'COMMAND' }, type: 1 }
                ],
                headerType: 1
            }, 'buttonsMessage', {contextInfo :{text: 'hi',
"forwardingScore": 1000000000,
isForwarded: true,
sendEphemeral: false,
"externalAdReply": {
                "title": `${ucapanWaktu} 👋 ${pushname}`,
                "body": "",
                "previewType": "image/jpeg",
                "thumbnailUrl": ``,
                "thumbnail": fs.readFileSync('./stik/textimg.jpeg'),
                "sourceUrl": ``
},mentionedJid:[sender]},quoted:mek})
}
if(budy.includes('Hai erick')){
otomatis(`Hai juga ${pushname} s`)
}
if(budy.includes('Assalamualaikum')){
reply('Waalaikumsalam')
}
if(budy.includes('yntkts')){
reply('yo ndak tau kok tanya saya?')
}
if(budy.includes('YNTKTS')){
reply('yo ndak tau kok tanya saya?')
}
if(budy.includes('Yntkts')){
reply('yo ndak tau kok tanya saya?')
}
if (budy.startsWith('$')){
if (!mek.key.fromMe && !isOwner) return  
console.log(color('[EXEC]'), color(moment(mek.messageTimestamp * 3000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`EXEC broo`))
var babi = budy.slice(1)
exec(babi, (err, asuu) => {
if(err) return reply(`${err}`)
if (asuu) {
faketroli(`───────────────\n${asuu}\n════ ❰ *${ownername}* ❱ ════`)
}
})
erik.sendMessage(from, '```executing...```', text, { quoted: mek });
}
if (budy.startsWith('>')){
if (!mek.key.fromMe && !isOwner) return
console.log(color('[EVAL]'), color(moment(mek.messageTimestamp * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`Eval V1 brooo`))
ras = budy.slice(1)
function _(rem) {
ren = JSON.stringify(rem,null,2)
pes = util.format(ren)
reply(pes)
}
try{q
reply(require('util').format(eval(`(async () => { ${ras} })()`)))
} catch(err) {
e = String(err)
reply(e)
}
}
if (budy.startsWith('<')){
try {
if (!mek.key.fromMe) return 
return erik.sendMessage(from, JSON.stringify(eval(budy.slice(2)),null,'\t'),text, {quoted: mek})
} catch(err) {
e = String(err)
reply(e)
}
}  

	}
if (isGroup && budy != undefined) {
	} else {
	console.log(color('[TEXT]', 'red'), 'SELF-MODE', color(sender.split('@')[0]))
	}		
	} catch (e) {
    e = String(e)
    if (!e.includes("this.isZero")) {
	console.log('Message : %s', color(e, 'green'))
        }
	// console.log(e)
	}
}


	
    
