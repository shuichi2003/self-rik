<div align="center">
<img src="https://i.ibb.co/qCHNd0j/36fa310d84b9844bbea4eaf9d6462eed5d6127c6.jpg" alt="SELF-HX" width="300" />

# NTAHLAH KAWAND

>
>
>
</div>
<p align="center">
  <a href="https://github.com/Hexagonz"><img title="Author" src="https://img.shields.io/badge/Author-Hexagonz-red.svg?style=for-the-badge&logo=github" /></a>
  <h4 align="center">
  <a href="https://wa.me/6285751056816">KYAAA ONI CHAN >//< </a>
</h4>
</p>

## CARA INSTALL DI TERMUX
```bash
> pkg install nodejs && pkg install git
> git clone https://github.com/Hexagonz/SELF-HX
> cd SELF-HX
> bash install.sh
> npm start/node main.js
```
## CARA INSTALL DI LAPTOP
```bash
> git clone https://github.com/Hexagonz/SELF-HX 
> cd SELF-HX
> npm i
> npm start/node main.js
```

# INSTALL
* [Node.js](https://nodejs.org/en/)
* [Git](https://git-scm.com/downloads)
* [FFmpeg](https://github.com/BtbN/FFmpeg-Builds/releases/download/autobuild-2020-12-08-13-03/ffmpeg-n4.3.1-26-gca55240b8c-win64-gpl-4.3.zip)
* [Libwebp](https://developers.google.com/speed/webp/download)

# FITUR

╒════════════════════
├➤ MAKER
├❒  sticker
├❒  stickergif
├❒  stickernobg
├❒  stickerwm 
├❒  take 
├❒  fdeface
├❒  emoji 
├❒  ttp 
├❒  attp 
├────────────────────
├➤ CONVERT
├❒  toimg
├❒  tovid
├❒  getimage
├❒  tomp3
├❒  tomp4
├❒  slow
├❒  fast
├❒  reverse
├❒  tourl
├────────────────────
├➤ FUN
├❒  apakah
├❒  bisakah
├❒  kapankah
├❒  gay
├❒  flip
├❒  dice
├❒  fitnah
├❒  fitnahpc
├❒  kontak
├────────────────────
├➤ ANIMANGA
├❒  character 
├❒  waifu 
├❒  anime 
├❒  manga 
├❒  quote 
├❒  wait  
├────────────────────
├➤ ISLAM
├❒  listsurah 
├❒  alquran
├❒  alquranaudio
├❒  asmaulhusna
├❒  kisahnabi
├❒  jadwalsholat 
├────────────────────
├➤ IMAGE
├❒  image 
├❒  ssweb <url>
├❒  randomimage 
├❒  nulis 
├❒  puisi 
├❒  pinterest 
├❒  pinterest2 
├❒  wallpaper 
├❒  wallpaper2 
├────────────────────
├➤ SEARCHING
├❒  ytsearch 
├❒  igstalk 
├❒  igstalk2 
├❒  brainly 
├❒  github 
├❒  lirik 
├❒  cuaca  
├❒  translate 
├❒  playstore 
├────────────────────
├➤ DOWNLOAD
├❒  playmp3 
├❒  playmp4 
├❒  ytmp3 
├❒  ytmp4 
├❒  ig 
├❒  twitter  (error)
├❒  tiktok 
├❒  tiktokaudio 
├❒  fb  
├────────────────────
├➤ OTHER
├❒  readmore 
├❒  inspect 
├❒  ping
├❒  status
├❒  runtime
├❒  get
├❒  owner
├❒  bot
├❒  security
├────────────────────
├➤ GROUP
├❒  getpic 
├❒  getbio 
├❒  linkgc
├❒  admin
├❒  tagall
├❒  tagall2
├❒  hidetag
├❒  kontag
├❒  sticktag
├❒  totag
├❒  open 
├❒  close 
├❒  group 
├❒  delete
├❒  closetime
├❒  opentime
├❒  promote
├❒  demote
├❒  register
├❒  unregister
├❒  setname
├❒  setdesc
├────────────────────
├➤ NSFW
├❒  trap
├❒  neko
├❒  loli
├❒  waifu
├❒  randomhentai
├❒  nhentai 
├────────────────────
├➤ OWNER
├❒  off
├❒  on
├❒  self
├❒  public
├❒  setthumb
├❒  settarget
├❒  settextimg
├❒  setfakeimg
├❒  setreply
├❒  join
├❒  leave
├❒  upswteks
├❒  upswimage
├❒  upswvideo
├❒  >
├❒  =>
├❒  $
├────────────────────
╘════════════════════

  # THANKS TO LORD
* [`Baileys`](https://github.com/adiwajshing/Baileys)
* [`MhankBarBar`](https://github.com/MhankBarBar)
* [`MRHRTZ`](https://github.com/MRHRTZ)
* [`HEXAGONZ`](https://github.com/Hexagonz/SELF-HX)
  
  
